"""Host-independent explicit targeting and stale-header replacement tests."""
import importlib.util
from pathlib import Path
import sys
import tempfile
import types
import unittest

CONTROL=Path(__file__).resolve().parent/'control/.github/dx11-opt'
# Command construction tests don't require an Apple compiler or the parser.
spec=importlib.util.spec_from_file_location('shader_policy_test',CONTROL/'shader_compat.py')
module=importlib.util.module_from_spec(spec)
stub=types.ModuleType('verify_metallib')
stub.verify=lambda data: None
old=sys.modules.get('verify_metallib')
sys.modules['verify_metallib']=stub
spec.loader.exec_module(module)
if old is None: del sys.modules['verify_metallib']
else: sys.modules['verify_metallib']=old

class ShaderCompatibilityTests(unittest.TestCase):
    def test_explicit_ios_baseline(self):
        commands=module.commands('/source/dxmt_command.metal','/output')
        compile=commands[0]
        self.assertEqual(compile[:4],['xcrun','--sdk','iphoneos','metal'])
        self.assertIn('-std=metal3.1',compile)
        self.assertEqual(compile[compile.index('-target')+1],'air64-apple-ios17.0')
        self.assertNotIn('macosx',compile)
        self.assertEqual(commands[1][:4],['xcrun','--sdk','iphoneos','metallib'])

    def test_replace_every_cached_output(self):
        with tempfile.TemporaryDirectory(prefix='madeira-shader-test-') as directory:
            root=Path(directory)
            destination=root/'generated'
            destination.mkdir()
            stage=root/'stage'
            target=stage/'src/dxmt/libdxmt.a.p'
            target.mkdir(parents=True)
            names=('dxmt_command.air','dxmt_command.metallib','dxmt_command.h')
            for name in names:
                (destination/name).write_bytes(('new-'+name).encode())
                (target/name).write_bytes(b'old-incompatible-cache')
            module.install_header(destination,stage)
            for name in names:
                self.assertEqual((target/name).read_bytes(),(destination/name).read_bytes())

if __name__=='__main__': unittest.main()
