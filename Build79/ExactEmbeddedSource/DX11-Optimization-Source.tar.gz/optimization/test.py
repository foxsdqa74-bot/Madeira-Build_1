"""Compile the real original/candidate allocate bodies with a mocked GPU owner."""
from pathlib import Path
import hashlib
import os
import subprocess

HERE=Path(__file__).resolve().parent
baseline=subprocess.check_output(['git','-C','/tmp/madeira-release-dxmt','show','b4b89f0a5a1752da3982a7b6c5575506024bf253:src/dxmt/dxmt_dynamic.cpp']).decode()
assert hashlib.sha256(baseline.encode()).hexdigest()=='7c5601bad68b01aa26001179aeb9b7a0c851ef7ab64ed7c0a614e84aee3be62b'
candidate=(HERE/'source/src/dxmt/dxmt_dynamic.cpp').read_text()
start='Rc<BufferAllocation>\nDynamicBuffer::allocate('
end='\nvoid\nDynamicBuffer::updateImmediateName('
for name,body,klass in [('original',baseline,'Original'),('candidate',candidate,'Candidate')]:
    method=start+body.split(start,1)[1].split(end,1)[0]
    (HERE/f'{name}-allocate.inc').write_text(method.replace('DynamicBuffer::allocate(',klass+'::allocate(',1))
header=(HERE/'source/src/dxmt/dxmt_mem_census.hpp').read_text()
header=header.replace('#include "winemetal.h"','').replace('#include "Metal.hpp"','')
metal=(HERE/'source/src/winemetal/winemetal.h').read_text()
pixel='enum WMTPixelFormat : uint32_t {'+metal.split('enum WMTPixelFormat : uint32_t {',1)[1].split('};',1)[0]+'};\n'
header=pixel+header.split('/* Physical bytes a texture',1)[0]+'}\n'
(HERE/'census-host.inc').write_text(header)
code=(HERE/'source/src/dxmt/dxmt_mem_census.cpp').read_text()
for include in ('dxmt_mem_census.hpp','log/log.hpp','util_env.hpp'):
    code=code.replace(f'#include "{include}"','')
(HERE/'census-code-host.inc').write_text(code)
for sanitizer in (False,True):
    out=HERE/('test-dynamic-sanitized' if sanitizer else 'test-dynamic')
    flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer'] if sanitizer else []
    subprocess.run(['clang++','-std=c++20','-O2','-Wall','-Wextra','-Werror',*flags,str(HERE/'test_dynamic.cpp'),'-o',str(out)],check=True)
    # LSan cannot run inside this sandbox's ptrace; the harness also verifies
    # every mocked allocation's destructor via an exact live-object count.
    subprocess.run([str(out)],check=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
    census_out=HERE/('test-census-sanitized' if sanitizer else 'test-census')
    subprocess.run(['clang++','-std=c++20','-O2','-Wall','-Wextra','-Werror',*flags,str(HERE/'test_census.cpp'),'-o',str(census_out)],check=True)
    for value in (None,'0','1','true'):
        environment={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'}
        environment.pop('DXMT_DIAGNOSTICS',None)
        if value is not None:environment['DXMT_DIAGNOSTICS']=value
        subprocess.run([str(census_out),'1' if value=='1' else '0'],check=True,env=environment)
