# PE-only initial Metal argument-buffer binding batch

## Result and recommendation

One narrow semantics-preserving candidate exported: **five consecutive PE→native provider calls become one linked-command provider call**, with exactly the same five Metal buffer-binding selectors, order, stages, slots, buffer and zero offsets. This is a bridge-call reduction, **not** five-to-one native Metal selectors, submission reduction, rendering-pass merge, or measured FPS improvement. No opt-in configuration is necessary for the proposed semantics-preserving change; main should review and target-build before integration/deployment.

Patch: `initial-bindings-batch.patch`, only `src/dxmt/dxmt_context.cpp`. Shared source was not modified. Allocator/census, integrated upload-watermark, binary archives, provider/compiler ABI, fences/barriers/hazards, in-flight retention, game files, quality and memory protections are untouched.

## Provenance

Inspected source: `/home/_ali/Documents/Codex/2026-09-15/y/work/dx11-opt/source`, containing main's first-batch changes elsewhere. Target file matches pinned Git object `b4b89f0a5a1752da3982a7b6c5575506024bf253:src/dxmt/dxmt_context.cpp` byte-for-byte: SHA-256 `f4f9372b08d8c89d8d2a95c72d534f37464ca2fb1263ae99c0249b38a2b9c299`. Git object repository `/tmp/madeira-release-dxmt` has that HEAD and was clean during verification. The patch applies to the pinned checkout and reverses against the sparse candidate. Copied text snapshots normalize missing final newlines; exported patch explicitly includes the target CPP's final-newline normalization. Git object bytes, not the own normalized baseline copy or supplied edited tree, are authority. Manifest contains exact hashes.

## Public provider/compiler contract reviewed

- `src/winemetal/winemetal.h`: stable `obj_handle_t`, `WMTMemoryPointer`, common `wmtcmd_base` prefix, existing vertex/fragment set-buffer opcodes and `wmtcmd_render_setbuffer` fields. No new symbol or opcode.
- `src/winemetal/Metal.hpp:316–340`: existing per-binding methods synchronously pass stack-resident commands to `MTLRenderCommandEncoder_encodeCommands`. `WMT::Object` already converts to the public handle type.
- `src/winemetal/winemetal_thunks.c:420–423`: existing synchronous `UNIX_CALL` carries the linked-list pointer. Candidate calls that same imported entry point once with five initialized nodes.
- `src/winemetal/unix/winemetal_unix.c:1609–1713,1978`: current native provider walks the list, dispatches each existing opcode to the same Metal selector, then follows `next`. The optional remote branch serializes the list before returning; its packer supports both binding opcodes. No provider rebuild or selector addition is required by this PE patch. Remote runtime compatibility remains untested; its external wire-header dependency is absent from this unpacked source.
- `src/airconv/airconv_public.h:95–114` exposes reflection binding indices; `src/airconv/dxbc_converter.cpp:1252–1255` assigns constant-buffer table 29 and argument table 30. `dxmt_context.cpp:88–95` uses input-assembler slot 16 and existing per-draw offset commands. All remain unchanged.

Original encoder creation around `dxmt_context.cpp:805–810` binds the allocated argument buffer to vertex slots 16,29,30 and fragment slots 29,30. Candidate builds a zero-initialized five-node stack array, links it in precisely that order, terminates it with null, and passes the common-prefix pointer to the unchanged public entry point. Mesh/object setup immediately afterward remains byte-for-byte unchanged.

## Correctness risks and boundaries

The provider must consume/copy command metadata synchronously, exactly as the existing single-node stack wrappers require. GPU resource lifetime is unrelated to stack-command metadata: native buffer binding/retention and the translator's existing owners remain unchanged. The candidate neither releases resources nor stores metadata for later execution. No cross-encoder state cache or deduplication is introduced; every fresh encoder receives all five bindings, including null-buffer clears.

Host ABI checks validate common-prefix offsets and opcode width using real copied public headers. The provider already uses this common-prefix list convention; no new layout assumption is introduced. Metadata is 200 bytes on the tested 64-bit host; no heap allocation. 32-bit PE layout and real ARM64/PE transitions are not runtime-tested here. Zero-initialized reserved/padding fields are benign; only defined fields are compared against baseline wrappers, whose reserved fields are not initialized.

Diagnostics now see one batch with five commands rather than five one-command batches. Semantic command counters remain five, while batch/crossing counts legitimately drop. Under optional remote transport, grouping makes failure atomic for these five commands rather than independently failing five calls; no successful-execution semantic difference, but real remote fault/protocol testing is pending. Do not claim trace-equality of timestamps or diagnostic batch counts.

## Host evidence and build status

Actual original/candidate blocks are in `baseline_bindings.inc` and `candidate_bindings.inc`, directly included by `test_bindings.cpp`; tests use real `provider/Metal.hpp` and `provider/winemetal.h` wrapper bodies and public structs. The C entry point is a counting driver mock, not a Metal implementation.

**80,000 actual-body cases passed**: edge/random 64-bit buffer handles including null, poisoned slots, repeated/fresh encoder handles, ordinary/geometry/tessellation/no-mesh combinations, and subsequent vertex/fragment offset changes. Native binding traces and complete modeled slot state are equal after setup and follow-up operations; 320,000 bridge calls removed across tests, and all five initial native bindings preserved. Terminator/walk bounds and public layout assertions pass.

GCC and Clang C++20 `-O2 -Wall -Wextra -Werror` builds/tests pass. GCC ASan+UBSan pass with `ASAN_OPTIONS=detect_leaks=0` (host LeakSanitizer tracing limitation). These are CPU mock/lifetime checks, **not GPU concurrency, Objective-C provider compilation, shader execution, remote transport or performance evidence**. Apple renderer target build and device tests are pending with main; Linux has no Apple SDK build in this sidecar.

Reproduce in this directory:

```sh
g++ -std=c++20 -O2 -Wall -Wextra -Werror test_bindings.cpp -o test-bindings
./test-bindings
clang++ -std=c++20 -O2 -Wall -Wextra -Werror test_bindings.cpp -o test-bindings-clang
./test-bindings-clang
g++ -std=c++20 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer test_bindings.cpp -o test-bindings-sanitized
ASAN_OPTIONS=detect_leaks=0 ./test-bindings-sanitized
bash verify.sh /absolute/path/to/main/renderer/source /absolute/path/to/git-object-repository
```

Verifier is read-only, checks pinned Git-object and patch hashes, accepts either pristine or exported-patched target bytes, performs the appropriate apply/reverse check, and confirms actual test snippets match sparse copied source. It is re-runnable after main applies the patch; no requirement that supplied source remain pristine.

## Apple guidance and ranked follow-ups

1. **Implemented candidate above:** reduce bridge crossings without changing Metal work. Apple's binding guidance favors persistent buffers and offset-only updates; this source already has per-draw offset commands. Do not replace those with full rebinds or `setBytes`. [Apple Buffer Bindings](https://developer.apple.com/library/archive/documentation/3DDrawing/Conceptual/MTLBestPracticesGuide/BufferBindings.html).
2. **Conditional theory:** batch immediately consecutive object/mesh initial bindings through the same existing ABI. This is not included: transport capability gating/no-mesh paths make the fixed five ordinary bindings the cleaner independent test unit. First profile crossing cost and mesh-path usage; avoid broadening an unmeasured optimization.
3. **Higher-impact but higher-risk theory:** reduce render-encoder boundaries only after proving identical attachments/subresources, load/store behavior, sampling dependencies and ordering. TBDR can benefit from avoiding tile-memory spills, but game-driven D3D visibility, UAV, copies and queries make arbitrary pass merging unsafe. No render-pass or action change exported. [Apple Render Command Encoders](https://developer.apple.com/library/archive/documentation/3DDrawing/Conceptual/MTLBestPracticesGuide/RenderCommandEncoders.html), [Apple TBDR guidance](https://developer.apple.com/documentation/metal/tailor-your-apps-for-apple-gpus-and-tile-based-deferred-rendering?changes=la__1&language=objc).
4. **Submission theory only:** measure command buffers/frame, encoding CPU time, queue gaps and flush reasons before considering coalescing. Fewer submissions can reduce CPU overhead but starve the GPU or delay visibility/latency fences; existing chunk limits are not frame counts. No submission/fence change exported. [Apple Command Buffers](https://developer.apple.com/library/archive/documentation/3DDrawing/Conceptual/MTLBestPracticesGuide/CommandBuffers.html).

Before promotion: main target-compiles renderer-only against current native provider/compiler, runs Metal API validation and capture with unchanged game configuration, and compares initial binding order/handles/slots and subsequent offsets. Then at least three matched baseline/candidate runs, identical diagnostics, comparing provider-call count, encoder CPU time, frame p95/p99, GPU gaps and errors. Native selectors, draw count, submission count, attachments, hazards and retention should remain unchanged. Benefits may be below noise; no FPS promise. Roll back by reversing this single-file patch and rebuilding the PE renderer; no native-provider update or game changes needed.

## Changed paths and integration status

Only within `/home/_ali/Documents/Codex/2026-09-15/y/work/dx11-metal-encoder-research`: report, manifest, patch, verifier, test source/snippets, sparse baseline/candidate `dxmt_context.cpp`, two public provider header snapshots, and three host-test binaries. No shared source/pipeline/earlier-research/other-project edits. **Exported only; main integration and target compilation pending.**
