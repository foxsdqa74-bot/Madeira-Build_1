#!/usr/bin/env bash
set -euo pipefail
# Read-only. Accept an already-patched supplied source; Git objects are authority.
research_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
supplied_source="${1:-$research_dir/candidate}"
object_repository="${2:-/tmp/madeira-release-dxmt}"
manifest="$research_dir/patch-manifest.json"
revision="$(jq -er '.base_commit' "$manifest")"
relative='src/dxmt/dxmt_context.cpp'
before="$(jq -er --arg f "$relative" '.files[$f].before_pinned_git_bytes' "$manifest")"
after="$(jq -er --arg f "$relative" '.files[$f].after' "$manifest")"
object_hash="$(git -C "$object_repository" show "$revision:$relative" | sha256sum | awk '{print $1}')"
[[ "$object_hash" == "$before" ]] || { echo 'FAIL: pinned Git object'; exit 1; }
expected_patch="$(jq -er '.patch_sha256' "$manifest")"
actual_patch="$(sha256sum "$research_dir/initial-bindings-batch.patch" | awk '{print $1}')"
[[ "$actual_patch" == "$expected_patch" ]] || { echo 'FAIL: patch checksum'; exit 1; }
for snapshot in baseline_bindings.inc candidate_bindings.inc provider/Metal.hpp provider/winemetal.h; do
  expected="$(jq -er --arg f "$snapshot" '.test_snapshots_sha256[$f]' "$manifest")"
  actual="$(sha256sum "$research_dir/$snapshot" | awk '{print $1}')"
  [[ "$expected" == "$actual" ]] || { echo "FAIL: test snapshot $snapshot"; exit 1; }
done
cmp -s "$research_dir/baseline_bindings.inc" <(awk '
  /encoder.setVertexBuffer\(gpu_buffer_, 0, 16\);/ { remaining=5 }
  remaining { print; remaining-- }
' "$research_dir/baseline/$relative") || { echo 'FAIL: original test body/source mismatch'; exit 1; }
cmp -s "$research_dir/candidate_bindings.inc" <(awk '
  /\/\/ Batch the same five bindings/ { copying=1 }
  copying { print }
  /encoder, reinterpret_cast<const wmtcmd_base \*>\(initial_bindings\)\);/ { copying=0 }
' "$research_dir/candidate/$relative") || { echo 'FAIL: candidate test body/source mismatch'; exit 1; }
supplied_hash="$(sha256sum "$supplied_source/$relative" | awk '{print $1}')"
if [[ "$supplied_hash" == "$before" ]]; then
  git -C "$supplied_source" apply --check "$research_dir/initial-bindings-batch.patch"
  echo 'PASS: pinned provenance, test snapshots/bodies, pristine supplied target and patch applicability.'
elif [[ "$supplied_hash" == "$after" ]]; then
  git -C "$supplied_source" apply --reverse --check "$research_dir/initial-bindings-batch.patch"
  echo 'PASS: pinned provenance, test snapshots/bodies, already-patched supplied target and reversibility.'
else
  echo 'FAIL: supplied target differs from both pinned baseline and exported candidate; regenerate manifest after reviewed target edits.'
  exit 1
fi
