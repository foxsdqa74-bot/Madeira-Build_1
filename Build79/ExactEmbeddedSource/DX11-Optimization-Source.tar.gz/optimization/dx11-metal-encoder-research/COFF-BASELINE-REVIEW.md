# ARM64EC baseline: resolved verifier mismatch

The supplied build74 ARM64EC DLLs already have raw COFF Machine **0x8664**, not 0xA641. `llvm-readobj --file-headers` labels these same files semantically as `COFF-ARM64EC` / `IMAGE_FILE_MACHINE_ARM64EC (0xA641)`. These observations are compatible: the diagnostic classification is not a literal dump of the raw Machine bytes. The previous raw-A641 assertion was incorrect. **No binary tag rewriting or loader workaround is warranted.** Loader research stopped following this resolution.

## Read-only verification

Baseline directory: `/home/_ali/Documents/Codex/2026-09-15/y/work/r6-resolution/audio-build74-signed-app`.

Raw Machine was read as little-endian uint16 at `uint32LE(file[0x3c:0x40]) + 4`. The new shared verifier, `/home/_ali/Documents/Codex/2026-09-15/y/work/dx11-opt/control/.github/dx11-opt/verify_pe.py`, was inspected and executed read-only with Python bytecode writes disabled. Observed verifier SHA256: `e4315888b8ce4c73386fa4652046e9c32afaa898c74b1e31f25b5e8b90ee4609`.

| Relative baseline DLL | Raw Machine | New verifier result |
| --- | --- | --- |
| aarch64-windows/d3d11.dll | 0xaa64 | PASS |
| aarch64-windows/dxgi.dll | 0xaa64 | PASS |
| arm64ec-windows/d3d11.dll | 0x8664 | PASS; CHPE version 1; one native EC code range |
| arm64ec-windows/dxgi.dll | 0x8664 | PASS; CHPE version 1; one native EC code range |

Baseline SHA256 values, in table order:

```
97ae63c6df8e8ceb720f4ae3049e0c54c24f98ba1d7ff8c8bfee87ac465c8550
553bd631fb7e38a2cdb001e389c0477275c6cafb143593ff564d34c4bd35c195
590941b9feb0f97235993b435eb29c3d10684191736224eade221ba3b3d3bdd4
fcec0fb9856027c694de5f116fbfa9c63a1a2f4e4b41e1ace1f962bdef279b43
```

The verifier checks PE32+ structure, file-backed load configuration/CHPE metadata and code-map bounds, and requires a nonempty EC-tagged code range contained in an executable section. An ordinary AMD64 DLL without that metadata cannot pass the EC check. It also accepts raw A641 as a compatibility policy; that acceptance does not establish that any supplied baseline has raw A641. Structural checks do not disassemble code or prove successful loading/execution. These baseline results are not evidence about an unavailable fresh CI ARM64EC artifact.

## Primary corroboration and integration status

[Microsoft ARM64EC documentation](https://learn.microsoft.com/en-us/windows/arm/arm64ec) distinguishes final PE machine identifiers from the ARM64EC identifier used for intermediate objects/libraries. [LLVM LLD COFF Writer.cpp](https://github.com/llvm/llvm-project/blob/main/lld/COFF/Writer.cpp) writes AMD64 for the EC symbol table in the final COFF header. Upstream source corroborates the format; it is not proof of the CI toolchain's exact revision.

Recommendation: use the corrected metadata-aware verifier; do not normalize or rewrite either baseline DLL. Shared source, controls, loaders, and binaries were not modified. This review adds only this report. The separately exported encoder binding-batch patch remains host-tested, with target compilation/integration owned by main; this PE review adds no optimization or binary patch and no runtime/GPU validation claim.
