// Real public provider types and wrapper bodies; Metal selectors are mocked.
// This does not compile the Objective-C provider or exercise a GPU.
#define DXMT_NATIVE 1
#include "provider/Metal.hpp"
#include <array>
#include <cassert>
#include <cstdio>
#include <map>
#include <random>
#include <tuple>

struct Binding {
  uint16_t type;
  uint64_t encoder, buffer, offset;
  uint8_t index;
  bool operator==(const Binding &) const = default;
};
struct Driver {
  uint64_t bridge_calls = 0, native_binding_calls = 0;
  std::vector<Binding> trace;
  std::map<std::tuple<uint64_t, unsigned, uint8_t>, std::pair<uint64_t, uint64_t>> state;
};
static Driver *active;

extern "C" void MTLRenderCommandEncoder_encodeCommands(obj_handle_t encoder, const wmtcmd_base *head) {
  assert(active && encoder);
  ++active->bridge_calls;
  unsigned walked = 0;
  for (auto next = head; next; next = static_cast<const wmtcmd_base *>(next->next.ptr)) {
    assert(++walked <= 16); // catches a missing terminator or cyclic candidate.
    unsigned stage;
    switch (next->type) {
    case WMTRenderCommandSetVertexBuffer: stage = 0; break;
    case WMTRenderCommandSetFragmentBuffer: stage = 1; break;
    case WMTRenderCommandSetObjectBuffer: stage = 2; break;
    case WMTRenderCommandSetMeshBuffer: stage = 3; break;
    case WMTRenderCommandSetVertexBufferOffset:
    case WMTRenderCommandSetFragmentBufferOffset: {
      auto body = reinterpret_cast<const wmtcmd_render_setbufferoffset *>(next);
      stage = next->type == WMTRenderCommandSetVertexBufferOffset ? 0 : 1;
      auto &value = active->state[{encoder, stage, body->index}];
      active->trace.push_back({next->type, encoder, value.first, body->offset, body->index});
      value.second = body->offset;
      continue;
    }
    default: assert(false); return;
    }
    auto body = reinterpret_cast<const wmtcmd_render_setbuffer *>(next);
    ++active->native_binding_calls;
    active->trace.push_back({next->type, encoder, body->buffer, body->offset, body->index});
    active->state[{encoder, stage, body->index}] = {body->buffer, body->offset};
  }
}

static void baseline(WMT::RenderCommandEncoder encoder, WMT::Buffer gpu_buffer_) {
#include "baseline_bindings.inc"
}
static void candidate(WMT::RenderCommandEncoder encoder, WMT::Buffer gpu_buffer_) {
#include "candidate_bindings.inc"
}

// Unchanged mesh/object setup following the optimized block, with explicit flags.
static void mesh_setup(WMT::RenderCommandEncoder encoder, WMT::Buffer gpu_buffer_, bool geometry, bool tessellation, bool no_mesh) {
  if (no_mesh || !(geometry || tessellation)) return;
  encoder.setObjectBuffer(gpu_buffer_, 0, 16);
  encoder.setObjectBuffer(gpu_buffer_, 0, 21);
  if (tessellation) {
    encoder.setObjectBuffer(gpu_buffer_, 0, 27);
    encoder.setObjectBuffer(gpu_buffer_, 0, 28);
  }
  encoder.setObjectBuffer(gpu_buffer_, 0, 29);
  encoder.setObjectBuffer(gpu_buffer_, 0, 30);
  encoder.setMeshBuffer(gpu_buffer_, 0, 29);
  encoder.setMeshBuffer(gpu_buffer_, 0, 30);
}

static void offsets(WMT::RenderCommandEncoder encoder, uint64_t value) {
  // Simulates the subsequent existing offset commands in the same encoder.
  wmtcmd_render_setbufferoffset commands[2]{};
  commands[0].type = WMTRenderCommandSetVertexBufferOffset;
  commands[0].offset = value;
  commands[0].index = 29;
  commands[0].next.set(&commands[1]);
  commands[1].type = WMTRenderCommandSetFragmentBufferOffset;
  commands[1].offset = value + 256;
  commands[1].index = 30;
  commands[1].next.set(nullptr);
  MTLRenderCommandEncoder_encodeCommands(encoder, reinterpret_cast<const wmtcmd_base *>(commands));
}

int main() {
  static_assert(offsetof(wmtcmd_render_setbuffer, next) == offsetof(wmtcmd_base, next));
  static_assert(offsetof(wmtcmd_render_setbuffer, type) == offsetof(wmtcmd_base, type));
  static_assert(sizeof(WMTRenderCommandType) == sizeof(uint16_t));
  std::mt19937_64 rng(0xf4f9372b);
  uint64_t cases = 0, saved = 0;
  const std::array<uint64_t, 5> edge_handles = {0, 1, 0xffffffffULL, 0x100000001ULL, UINT64_MAX};
  for (unsigned trial = 0; trial < 10000; ++trial) {
    Driver a, b;
    // Poison all slots, including unused slots, to detect unintended mutation.
    for (unsigned stage = 0; stage < 4; ++stage)
      for (uint8_t slot = 0; slot < 32; ++slot)
        a.state[{1, stage, slot}] = {rng(), rng()};
    b.state = a.state;
    for (unsigned pass = 0; pass < 8; ++pass) {
      WMT::RenderCommandEncoder encoder{1 + pass % 3};
      const uint64_t handle = trial < edge_handles.size() ? edge_handles[trial] : rng();
      WMT::Buffer buffer{handle};
      active = &a;
      baseline(encoder, buffer);
      active = &b;
      candidate(encoder, buffer);
      assert(a.trace == b.trace && a.state == b.state);
      assert(a.native_binding_calls == b.native_binding_calls);
      assert(a.bridge_calls == b.bridge_calls + 4 * (pass + 1));
      const bool geometry = pass & 1, tessellation = pass & 2, no_mesh = pass & 4;
      active = &a;
      mesh_setup(encoder, buffer, geometry, tessellation, no_mesh);
      offsets(encoder, uint64_t(pass) * 512);
      active = &b;
      mesh_setup(encoder, buffer, geometry, tessellation, no_mesh);
      offsets(encoder, uint64_t(pass) * 512);
      assert(a.trace == b.trace && a.state == b.state);
      assert(a.native_binding_calls == b.native_binding_calls);
      ++cases;
      saved += 4;
    }
  }
  // Exercise long linked initial-binding batches repeatedly with fresh encoders.
  // Source call sites use synchronous consumption just as the existing wrappers.
  std::printf("PASS: %llu actual-body cases; %llu bridge calls removed; identical native binding traces/state; five native bindings preserved; command bytes=%zu. Not GPU evidence.\n",
              (unsigned long long)cases, (unsigned long long)saved,
              sizeof(wmtcmd_render_setbuffer) * 5);
}
