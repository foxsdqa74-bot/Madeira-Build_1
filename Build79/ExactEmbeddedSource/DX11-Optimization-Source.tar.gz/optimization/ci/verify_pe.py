"""Validate ARM64EC code metadata, not just a final DLL's COFF machine tag.

LLVM emits canonical AMD64+CHPE final DLLs; supplied Wine DLLs may use A641.
Never rewrite that tag or accept an ordinary x64 binary as native EC code.
"""
import struct

def verify(data,arch):
    def read(fmt,offset):
        size=struct.calcsize(fmt)
        assert 0<=offset<=len(data)-size,'Truncated PE field'
        return struct.unpack_from(fmt,data,offset)
    assert data[:2]==b'MZ'
    pe,=read('<I',0x3c)
    assert data[pe:pe+4]==b'PE\0\0'
    machine,sections=read('<HH',pe+4)
    optional_size,=read('<H',pe+20)
    optional=pe+24
    magic,=read('<H',optional)
    assert optional_size>=240 and magic==0x20b
    image_base,=read('<Q',optional+24)
    image_size,=read('<I',optional+56)
    section_table=optional+optional_size
    ranges=[]
    for index in range(sections):
        header=section_table+40*index
        virtual_size,rva,raw_size,raw_offset=read('<IIII',header+8)
        flags,=read('<I',header+36)
        assert raw_offset+raw_size<=len(data),'Truncated PE section'
        ranges.append((rva,virtual_size,raw_offset,raw_size,flags))
    def offset(rva,size):
        for base,_,raw,raw_size,_ in ranges:
            if base<=rva and rva+size<=base+raw_size:return raw+rva-base
        raise AssertionError('RVA has no complete file-backed section')
    if arch=='aarch64':
        assert machine==0xaa64,f'Expected ARM64; got {machine:#x}'
        return {'machine':hex(machine)}
    assert arch=='arm64ec' and machine in (0xa641,0x8664),f'Expected ARM64EC; got {machine:#x}'
    config_rva,config_size=read('<II',optional+112+10*8)
    assert config_rva and config_size>=0xd0,'Missing EC load config'
    config=offset(config_rva,0xd0)
    declared_size,=read('<I',config)
    assert declared_size>=0xd0
    metadata_va,=read('<Q',config+0xc8)
    assert image_base<=metadata_va<image_base+image_size,'Missing CHPE metadata'
    metadata=offset(metadata_va-image_base,80)
    version,map_rva,count=read('<III',metadata)
    assert version in (1,2) and 0<count<=1000000,'Invalid EC metadata/code map'
    code_map=offset(map_rva,count*8)
    ec_ranges=0
    for index in range(count):
        start,length=read('<II',code_map+8*index)
        if start&3!=1:continue
        start&=~3
        assert length and start+length<=image_size,'Invalid EC code range'
        assert any(base<=start and start+length<=base+max(virtual,raw_size) and flags&0x20000000
                   for base,virtual,_,raw_size,flags in ranges),'EC range is not executable'
        ec_ranges+=1
    assert ec_ranges,'No native ARM64EC code ranges (ordinary x64 DLL rejected)'
    return {'machine':hex(machine),'metadata_version':version,'ec_code_ranges':ec_ranges}
