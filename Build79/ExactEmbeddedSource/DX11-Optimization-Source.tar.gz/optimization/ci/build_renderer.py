"""Rebuild only guest DX11/DXGI; preserve the installed native/WineMetal ABI.

Use cached, expanded Ninja recipes rather than rerunning Meson/native LLVM.
Compile every guest object in the selected link graph for each architecture.
Import libs are regenerated from the exact preserved WineMetal export tables.
"""
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from checkpoint import Checkpoint, key
from verify_pe import verify
from shader_compat import compile_helpers, install_header

ROOT=Path.cwd().resolve()
CONTROL=ROOT/'control/.github/dx11-opt'
DXMT=ROOT/'source/research/dxmt'
BASE=DXMT/'build-pe'
TC=ROOT/'source/toolchains/llvm-mingw-20260421-ucrt-macos-universal/bin'
OUT=ROOT/'dx11-output'
OUT.mkdir(exist_ok=True)
def run(args,cwd=None):
    subprocess.run([str(x) for x in args],cwd=cwd,check=True)
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((CONTROL/'patch-manifest.json').read_text())
providers=json.loads((CONTROL/'providers.json').read_text())
assert digest(CONTROL/'dx11-hotpath.patch')==manifest['patch_sha256']
for name,hashes in manifest['files'].items():assert digest(DXMT/name)==hashes['before'],name
run(['git','apply','--check',CONTROL/'dx11-hotpath.patch'],DXMT)
run(['git','apply',CONTROL/'dx11-hotpath.patch'],DXMT)
for name,hashes in manifest['files'].items():assert digest(DXMT/name)==hashes['after'],name
run(['ninja','--version'])
recipes=json.loads(subprocess.check_output(['ninja','-C',str(BASE),'-t','compdb','-x'],text=True))
(OUT/'cached-recipes.json').write_text(json.dumps(recipes,indent=2))
environment={**os.environ,'PATH':str(TC)+':'+os.environ['PATH']}
os.environ.update(environment)
targets=('src/dxgi/dxgi.dll','src/d3d11/d3d11.dll')
def tokens(recipe):
    result=shlex.split(recipe['command'])
    assert not any(x in (';','|','||','>','<','`') for x in result),'Unexpected shell recipe'
    return result
links={r['output']:tokens(r) for r in recipes if r['output'] in targets}
assert set(links)==set(targets),'Missing expanded link recipes'
helper_source=DXMT/'src/dxmt/dxmt_command.metal'
helper_bytes,helper_report=compile_helpers(helper_source,OUT/'shaders')
report={'patch':manifest,'shaders':helper_report,'architectures':{},'started':time.time(),'status':'building'}
(OUT/'report.json').write_text(json.dumps(report,indent=2))
for arch,machine in [('aarch64',0xaa64),('arm64ec',0xa641)]:
    stage=DXMT/('build-dx11-'+arch)
    identity=key({'patch':manifest,'providers':providers,'architecture':arch,
                  'recipes':digest(OUT/'cached-recipes.json'),
                  'builder':digest(Path(__file__)),
                  'checkpoint_policy':digest(CONTROL/'checkpoint.py'),
                  'pe_validation':digest(CONTROL/'verify_pe.py'),
                  'shader_policy':digest(CONTROL/'shader_compat.py'),
                  'shader_validation':digest(CONTROL/'verify_metallib.py'),
                  'shader_artifact':helper_report['metallib_sha256'],
                  'compiler_cache':'mingw-20260421-1-d6f4784cd7777d51b3f6c547a8fa6b067fdfc32642eed67e0d74e9c8f60297ea',
                  'optimization':'-O2; no fast-math/LTO'})
    if stage.exists():
        assert (stage/'compile-checkpoints.json').is_file(),'Refuse unidentified stale stage'
    else:shutil.copytree(BASE,stage,symlinks=True)
    install_header(OUT/'shaders',stage)
    checkpoint=Checkpoint(stage,identity)
    checkpoint.initialize()
    dest=OUT/arch
    dest.mkdir()
    # A sidecar import library only: WineMetal itself is never rebuilt/replaced.
    definition=CONTROL/(arch+'-winemetal.def')
    assert digest(definition)==providers[arch]['def_sha256']
    run([TC/(arch+'-w64-mingw32-dlltool'),'-d',definition,'-l',stage/'src/winemetal/winemetal.dll.a'],stage)
    changed_commands=[]
    def translate(args):
        translated=[a.replace('aarch64-w64-mingw32-',arch+'-w64-mingw32-') for a in args]
        # Cached Meson recipes point to DXMT/toolchains, whereas the restored
        # compiler cache lives at the Madeira checkout's top-level toolchains.
        compiler=Path(translated[0])
        if compiler.is_absolute() and 'llvm-mingw-20260421-ucrt-macos-universal' in compiler.parts:
            translated[0]=str(TC/compiler.name)
            assert Path(translated[0]).is_file(),translated[0]
        # The original cache was a debug (-O0) guest build. Optimize only guest
        # code; retain debug information/assertions and IEEE floating-point.
        translated=['-O2' if a=='-O0' else a for a in translated]
        # Resource compiler produces COFF for the same target as guest code.
        return translated
    # Compile guest objects only; skip cached host AIR/LLVM and WineMetal shim.
    compilations=[]
    guest_prefixes=('src/util/','libs/DXBCParser/','src/dxmt/','src/dxgi/','src/d3d11/')
    for r in recipes:
        output=r['output']
        if not output.endswith(('.o','.obj')):continue
        if 'aarch64-w64-mingw32-' not in r['command']:continue
        if not output.startswith(guest_prefixes):continue
        args=tokens(r)
        assert not Path(output).is_absolute() and '..' not in Path(output).parts
        compilations.append((output,args))
    assert len(compilations)>40,'Incomplete guest compilation graph'
    def compile_one(item):
        output,args=item
        translated=translate(args)
        if checkpoint.done(output,translated):
            print('Checkpoint hit',arch,output,flush=True)
            return translated
        print('Compile',arch,output,flush=True)
        run(translated,stage)
        if arch=='arm64ec' and output.endswith('.obj'):
            assert int.from_bytes((stage/output).read_bytes()[:2],'little')==0xa641,'Not an EC code object'
        checkpoint.record(output,translated)
        return translated
    # Limit parallel clang processes to bound runner memory usage; all archive
    # and DLL links occur only after every guest compilation has succeeded.
    with ThreadPoolExecutor(max_workers=2) as workers:
        changed_commands=list(workers.map(compile_one,compilations))
    # Rebuild every guest static archive from newly compiled objects. Handle
    # Ninja's exact "rm -f archive && llvm-ar ..." without executing a shell.
    for r in recipes:
        if not r['output'].endswith('.a'):continue
        if not r['output'].startswith(guest_prefixes):continue
        args=tokens(r)
        if 'aarch64-w64-mingw32-ar' not in r['command']:continue
        if args[:2]==['rm','-f']:
            assert len(args)>5 and args[3]=='&&' and args[2]==r['output']
            args=args[4:]
        assert not any(x=='&&' for x in args)
        assert not Path(r['output']).is_absolute() and '..' not in Path(r['output']).parts
        archive=stage/r['output']
        archive.unlink(missing_ok=True)
        run(translate(args),stage)
    for target in targets:
        args=translate(links[target])
        assert not any(a.startswith('@') for a in args),'Unexpanded linker response file'
        run(args,stage)
        binary=stage/target
        data=binary.read_bytes()
        validation=verify(data,arch)
        if binary.name=='d3d11.dll':
            assert data.count(helper_bytes)==1,'Compatible helper missing/duplicated in guest DLL'
        print('Verified DLL',arch,binary.name,validation,flush=True)
        shutil.copy2(binary,dest/binary.name)
        inspection=subprocess.check_output([str(TC/'llvm-readobj'),'--file-headers','--coff-imports','--coff-exports',str(binary)],text=True)
        (dest/(binary.name+'.inspection.txt')).write_text(inspection)
    (dest/'commands.json').write_text(json.dumps(changed_commands,indent=2))
    (stage/'completed-architecture.json').write_text(json.dumps({
        'identity':identity,'files':{p.name:digest(p) for p in dest.glob('*.dll')}},indent=2))
    report['architectures'][arch]={p.name:digest(p) for p in dest.glob('*.dll')}
    (OUT/'report.json').write_text(json.dumps(report,indent=2))
report.update(status='success',finished=time.time())
(OUT/'report.json').write_text(json.dumps(report,indent=2))
print('PASS: both guest renderer architectures built; native runtime and WineMetal unchanged')
