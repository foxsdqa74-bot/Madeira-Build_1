"""Resumable guest object checkpoints; never trust cached output by name alone."""
from pathlib import Path
import hashlib
import json
import threading

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def key(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

class Checkpoint:
    def __init__(self,stage,identity):
        self.stage=Path(stage)
        self.identity=identity
        self.path=self.stage/'compile-checkpoints.json'
        self.lock=threading.Lock()
        self.entries={}
        if self.path.exists():
            state=json.loads(self.path.read_text())
            if state['identity']!=identity:
                raise RuntimeError('Cached guest stage identity differs; refuse reuse')
            self.entries=state['entries']

    def output(self,name):
        path=Path(name)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError('Checkpoint target must stay inside guest stage')
        resolved=(self.stage/path).resolve()
        if not resolved.is_relative_to(self.stage.resolve()):
            raise ValueError('Checkpoint symlink escapes guest stage')
        return resolved

    def done(self,name,command):
        path=self.output(name)
        with self.lock:
            record=self.entries.get(name)
        return bool(record and record['command']==key(command) and path.is_file()
                    and record['sha256']==sha(path))

    def record(self,name,command):
        record={'command':key(command),'sha256':sha(self.output(name))}
        with self.lock:
            self.entries[name]=record
            self.save_locked()

    def save_locked(self):
        temporary=self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps({'identity':self.identity,'entries':self.entries},sort_keys=True))
        temporary.replace(self.path)

    def initialize(self):
        with self.lock:self.save_locked()
