"""Compile internal helpers for the app's iOS17/MSL3.1 baseline, never defaults."""
import hashlib
import json
from pathlib import Path
import subprocess
from verify_metallib import verify

POLICY = {'sdk':'iphoneos','language':'metal3.1','target':'air64-apple-ios17.0'}

def commands(source, destination):
    source, destination = Path(source), Path(destination)
    air = destination/'dxmt_command.air'
    library = destination/'dxmt_command.metallib'
    header = destination/'dxmt_command.h'
    return [
        ['xcrun','--sdk',POLICY['sdk'],'metal','-std='+POLICY['language'],
         '-target',POLICY['target'],'-c',str(source),'-o',str(air)],
        ['xcrun','--sdk',POLICY['sdk'],'metallib',str(air),'-o',str(library)],
        ['xxd','-n','dxmt_command','-i',str(library),str(header)],
    ]

def compile_helpers(source, destination):
    source, destination = Path(source).resolve(), Path(destination).resolve()
    destination.mkdir(parents=True,exist_ok=True)
    recipes = commands(source,destination)
    for recipe in recipes:
        subprocess.run(recipe,check=True)
    data = (destination/'dxmt_command.metallib').read_bytes()
    inspection = verify(data)
    report = {'policy':POLICY,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'metallib_sha256':hashlib.sha256(data).hexdigest(),
              'metallib_bytes':len(data),'commands':recipes,'inspection':inspection}
    (destination/'compatibility.json').write_text(json.dumps(report,indent=2))
    return data,report

def install_header(destination, stage):
    directory = Path(stage)/'src/dxmt/libdxmt.a.p'
    directory.mkdir(parents=True,exist_ok=True)
    # All three outputs replace the unverified cache before object compilation.
    for name in ('dxmt_command.air','dxmt_command.metallib','dxmt_command.h'):
        (directory/name).write_bytes((Path(destination)/name).read_bytes())
