"""Bounded MTLB structural/language gate for the renderer's helper library.

Layouts: DXMT's packed 88-byte 2.7 header/writer and observed Apple 2.9
container. Unknown container versions fail closed. This is NOT a Metal loader,
LLVM validator, GPU compatibility proof, or an iOS target-triple validator.
"""
import argparse
import json
import struct
from pathlib import Path

MAX_BYTES = 64 * 1024 * 1024
MAX_FUNCTIONS = 4096
MAX_TAGS = 256
MAX_LANGUAGE = (3, 1)
KNOWN_HEADERS = {(2, 7), (2, 9)}
HEADER_SIZE = 88
REQUIRED = {b'NAME', b'TYPE', b'HASH', b'MDSZ', b'OFFT', b'VERS'}
FUNCTION_TAGS = REQUIRED | {b'LAYR', b'TESS'}
METADATA_TAGS = {b'VATT', b'VATY', b'CNST'}
SIZES = {b'TYPE': 1, b'HASH': 32, b'MDSZ': 8, b'OFFT': 24, b'VERS': 8,
         b'LAYR': 1, b'TESS': 1}


def _require(condition, message):
    if not condition:
        raise ValueError('metallib: ' + message)


def _tags(data, start, end):
    """Yield one ENDT-delimited TLV list; ENDT has no length field."""
    tags = {}
    while True:
        _require(start + 4 <= end, 'missing/truncated ENDT')
        tag = data[start:start + 4]
        start += 4
        if tag == b'ENDT':
            return tags, start
        _require(all(48 <= c <= 57 or 65 <= c <= 90 for c in tag), 'invalid tag FourCC')
        _require(start + 2 <= end, 'truncated tag length')
        size, = struct.unpack_from('<H', data, start)
        start += 2
        _require(size <= end - start, 'tag payload exceeds record bounds')
        _require(tag not in tags, 'duplicate tag ' + tag.decode('ascii'))
        _require(len(tags) < MAX_TAGS, 'too many tags in one record')
        tags[tag] = data[start:start + size]
        start += size


def _metadata(data, start, size):
    end, blocks = start + size, {}
    while start < end:
        _require(len(blocks) < MAX_FUNCTIONS, 'too many metadata blocks')
        _require(start + 4 <= end, 'truncated metadata length')
        length, = struct.unpack_from('<I', data, start)
        _require(length >= 4 and length <= end - start - 4, 'invalid metadata block length')
        tags, consumed = _tags(data, start + 4, start + 4 + length)
        _require(tags.keys() <= METADATA_TAGS, 'unsupported metadata tag')
        _require(consumed == start + 4 + length, 'bytes after metadata ENDT')
        blocks[start] = length
        start += 4 + length
    return blocks


def inspect(data):
    """Validate known structure and return versions, without language ceiling.

    Raises ValueError for malformed/unsupported input. Input must be the EXACT
    library slice, not a PE containing it; appended bytes are rejected.
    """
    _require(isinstance(data, (bytes, bytearray, memoryview)), 'expected bytes-like data')
    byte_count = data.nbytes if isinstance(data, memoryview) else len(data)
    _require(HEADER_SIZE <= byte_count <= MAX_BYTES, 'invalid/excessive library size')
    data = bytes(data)
    _require(data[:4] == b'MTLB', 'bad magic')
    platform, major, minor, file_type, os_kind, os_major, os_minor = struct.unpack_from('<HHHBBHH', data, 4)
    _require((major, minor) in KNOWN_HEADERS, f'unsupported header version {major}.{minor}')
    _require(file_type == 0, 'unsupported non-executable library type')
    file_size, fn_start, fn_size, pub_start, pub_size, priv_start, priv_size, bc_start, bc_size = struct.unpack_from('<9Q', data, 16)
    _require(file_size == len(data), 'declared file size differs from exact input size')
    # Known layouts exclude the count and extended ENDT from FunctionListSize.
    _require(fn_start == HEADER_SIZE, 'unsupported function-list/header boundary')
    _require(fn_size >= 8 and fn_size <= len(data) - fn_start - 8, 'invalid function-list size')
    fn_end = fn_start + 4 + fn_size
    _require(data[fn_end:fn_end + 4] == b'ENDT', 'missing extended-header ENDT')
    _require(pub_start == fn_end + 4 and priv_start == pub_start + pub_size
             and bc_start == priv_start + priv_size and bc_start + bc_size == file_size,
             'overlapping/gapped/out-of-order sections')
    for start, size in ((pub_start, pub_size), (priv_start, priv_size), (bc_start, bc_size)):
        _require(HEADER_SIZE <= start <= file_size and size <= file_size - start,
                 'section outside file bounds')
    _require(bc_size > 0, 'empty bitcode section')
    count, = struct.unpack_from('<I', data, fn_start)
    _require(0 < count <= MAX_FUNCTIONS, 'invalid/excessive function count')
    public = _metadata(data, pub_start, pub_size)
    private = _metadata(data, priv_start, priv_size)
    functions, names = [], set()
    pos = fn_start + 4
    # Apple uses one sized block per function; DXMT writes all functions in one
    # sized block. Both are bounded explicitly, never scanned by tag substring.
    while pos < fn_end:
        _require(pos + 4 <= fn_end, 'truncated function record length')
        length, = struct.unpack_from('<I', data, pos)
        _require(8 <= length <= fn_end - pos, 'invalid function record length')
        record_end, cursor = pos + length, pos + 4
        while cursor < record_end:
            _require(len(functions) < count, 'more function records than declared')
            tags, cursor = _tags(data, cursor, record_end)
            _require(REQUIRED <= tags.keys(), 'function missing required tag(s)')
            _require(tags.keys() <= FUNCTION_TAGS, 'unsupported function tag')
            for tag, size in SIZES.items():
                if tag in tags:
                    _require(len(tags[tag]) == size, 'invalid ' + tag.decode() + ' length')
            encoded_name = tags[b'NAME']
            _require(len(encoded_name) > 1 and encoded_name[-1:] == b'\0'
                     and b'\0' not in encoded_name[:-1], 'invalid function NAME')
            try:
                name = encoded_name[:-1].decode('utf-8')
            except UnicodeDecodeError as exc:
                raise ValueError('metallib: invalid UTF-8 function NAME') from exc
            _require(name not in names, 'duplicate function NAME')
            names.add(name)
            kind = tags[b'TYPE'][0]
            _require(kind in (0, 1, 2, 7, 8), 'unsupported function TYPE')
            air_major, air_minor, lang_major, lang_minor = struct.unpack('<4H', tags[b'VERS'])
            _require(air_major > 0 and lang_major > 0, 'invalid zero VERS major')
            pub_off, priv_off, bc_off = struct.unpack('<3Q', tags[b'OFFT'])
            code_size, = struct.unpack('<Q', tags[b'MDSZ'])
            _require(pub_start + pub_off in public and priv_start + priv_off in private,
                     'OFFT does not identify metadata block starts')
            _require(code_size > 0 and bc_off <= bc_size and code_size <= bc_size - bc_off,
                     'function bitcode range outside section')
            functions.append({'name': name, 'type': kind, 'air_version': [air_major, air_minor],
                              'language_version': [lang_major, lang_minor],
                              'bitcode_offset': bc_off, 'bitcode_size': code_size})
        _require(cursor == record_end, 'function record boundary mismatch')
        pos = record_end
    _require(len(functions) == count, 'function count mismatch')
    language = max(tuple(f['language_version']) for f in functions)
    return {'language': f'{language[0]}.{language[1]}', 'function_count': count,
            'functions': functions, 'header_version': [major, minor],
            'platform': platform, 'os': os_kind, 'os_version': [os_major, os_minor],
            'file_size': file_size}


def verify(data):
    """Validate exact structure and EVERY function's Metal language <=3.1."""
    info = inspect(data)
    for function in info['functions']:
        version = tuple(function['language_version'])
        _require(version <= MAX_LANGUAGE,
                 f"function {function['name']} requires Metal {version[0]}.{version[1]} (>3.1)")
    return info


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('metallib', type=Path)
    parser.add_argument('--inspect', action='store_true', help='structure only; does not enforce language ceiling')
    args = parser.parse_args()
    _require(args.metallib.stat().st_size <= MAX_BYTES, 'file exceeds size bound')
    info = (inspect if args.inspect else verify)(args.metallib.read_bytes())
    print(json.dumps(info, separators=(',', ':')))
