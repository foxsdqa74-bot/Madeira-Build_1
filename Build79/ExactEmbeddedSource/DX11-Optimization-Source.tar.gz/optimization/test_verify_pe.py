"""Read-only baseline checks plus corrupted-PE rejection; no header rewriting."""
from pathlib import Path
import struct
import sys
sys.path.insert(0,str(Path(__file__).parent/'control/.github/dx11-opt'))
from verify_pe import verify
base=Path(__file__).parent.parent/'r6-resolution/audio-build74-signed-app'
for arch in ('aarch64','arm64ec'):
    for name in ('d3d11.dll','dxgi.dll'):
        data=(base/(arch+'-windows')/name).read_bytes()
        verify(data,arch)
data=(base/'arm64ec-windows/dxgi.dll').read_bytes()
pe=struct.unpack_from('<I',data,0x3c)[0]
optional=pe+24
sections=struct.unpack_from('<H',data,pe+6)[0]
table=optional+struct.unpack_from('<H',data,pe+20)[0]
def offset(rva):
    for i in range(sections):
        header=table+i*40
        virtual,base_rva,raw_size,raw=struct.unpack_from('<IIII',data,header+8)
        if base_rva<=rva<base_rva+raw_size:return raw+rva-base_rva
    raise AssertionError('RVA not file-backed')
config=offset(struct.unpack_from('<I',data,optional+112+80)[0])
image_base=struct.unpack_from('<Q',data,optional+24)[0]
metadata=offset(struct.unpack_from('<Q',data,config+0xc8)[0]-image_base)
code_map=offset(struct.unpack_from('<I',data,metadata+4)[0])
def reject(candidate):
    try:verify(candidate,'arm64ec')
    except AssertionError:return
    raise AssertionError('Corrupted or non-EC PE accepted')
mutations=[(0,b'XX'),(pe,b'XX\0\0'),(pe+4,b'\x64\xaa'),
           (optional,b'\x0b\x01'),(config+0xc8,b'\0'*8),
           (metadata,b'\xff'*4),(metadata+8,b'\0'*4)]
for position,value in mutations:
    candidate=bytearray(data)
    candidate[position:position+len(value)]=value
    reject(candidate)
candidate=bytearray(data)
count=struct.unpack_from('<I',data,metadata+8)[0]
for index in range(count):
    start=struct.unpack_from('<I',data,code_map+8*index)[0]
    struct.pack_into('<I',candidate,code_map+8*index,start&~3)
reject(candidate)
reject(data[:64])
print('PASS: original ARM64/EC DLLs; nine corrupt/non-EC/truncated cases rejected without rewriting headers')
