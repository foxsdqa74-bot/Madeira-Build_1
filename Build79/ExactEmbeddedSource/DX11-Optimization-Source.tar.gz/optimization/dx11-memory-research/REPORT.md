# DXMT iPhone memory/upload/lifetime sidecar

## Decision and integration status

Research complete; **one default-off experimental patch exported, host-tested only; not integrated and not GPU-validated**. It implements the bounded watermark experiment described below, not the main-agent dynamic allocator/census optimization. Only research-directory copies were changed; shared renderer, game, fence, memory-protection, IPA, pipeline, and CI files remain untouched. Linux has no `xcrun`; no Apple renderer build, Metal validation, device benchmark, or crash reproduction was performed.

Source root: `/home/_ali/Documents/Codex/2026-09-15/y/work/dx11-opt/source`. Requested baseline: `b4b89f0a5a1752da3982a7b6c5575506024bf253`, also named in adjacent `patch-manifest.json`. This source is an unpacked tree; main-agent dynamic/census files differ. Subsequently located clean Git repository `/tmp/madeira-release-dxmt`: HEAD is the requested revision, status is clean, and both initializer files' SHA-256 values match the inspected tree and pinned Git objects. Exported patch applies to that clean pinned tree and reverses against candidate copies. Own baseline CPP copy normalizes a missing final newline; exact exported patch explicitly includes that harmless newline normalization. Full-tree provenance beyond these two patch targets was not asserted. Relevant hashes are in `EVIDENCE.json` and `patch-manifest.json`.

## Selected opt-in experiment: bounded upload-watermark refresh

Artifact: `upload-watermark-experiment.patch`; affects only `src/dxmt/dxmt_resource_initializer.cpp` and `src/dxmt/dxmt_resource_initializer.hpp`. Read-only process environment flag `DXMT_EXPERIMENT_UPLOAD_WATERMARK=1`, sampled once at initializer construction, enables it; absent, empty, `0`, and every other value keep it off. No game files or launch configuration were changed. Unset the flag and restart to roll back behavior without replacing the cached renderer build; reverse the patch and rebuild for complete code rollback.

When enabled, query the **existing initializer upload event** before allocation call 1 and then every 64 allocation calls. Clamp observed completion to the last committed upload sequence (`current_seq_id_ - 1`), and do not regress cached completion. No signal, GPU wait, fence, release, ring size, TTL, reuse inequality, or command ordering changes. All calls are already under initializer `mutex_`; countdown/cached updates remain there. Main-queue coherence is never substituted. Event signal is encoded after upload commands, so observing it establishes preceding upload completion; the original ring's strict `last_used_seq_id < coherent_id` remains conservative. [Apple GPU event-signal ordering](https://developer.apple.com/documentation/metal/mtlcommandbuffer/encodesignalevent%28_%3Avalue%3A%29).

Hypothesis, not GPU evidence: less stale completion knowledge might avoid an unnecessary new upload block during streaming. At most one extra Metal/remote query per 64 upload allocations, but a remote query can still incur RPC latency. It cannot eliminate decoded-image overlap or explain the multi-GB process footprint. The interval 64 is a polling-cost bound, not a memory/queue cap or measured optimum.

Host validation: C++20 (matching project standard), GCC `-O2 -Wall -Wextra -Werror`; **356,002 cases**, including 100,000 original-versus-default-off differential cases and randomized tests using the copied, unchanged ring template with modeled 32-byte blocks. **61,146 completed-only reuse events** checked; equality remains non-reusable, current uncommitted sequence is excluded, offsets do not overlap live bytes, stale query cannot regress cached value, and polling frequency is bounded. ASan+UBSan pass with `ASAN_OPTIONS=detect_leaks=0`; LeakSanitizer itself is unavailable under this host's tracing environment. Tests model serialized callers, not a real Metal driver, remote protocol or GPU concurrency. The test source embeds the actual candidate allocation method and ring-template logic; block size/alignment and device objects are host substitutes. There is no measured memory/frame-time benefit yet.

Reproduce from this directory:

```sh
g++ -std=c++20 -O2 -Wall -Wextra -Werror test_upload_watermark.cpp -o test-upload-watermark
./test-upload-watermark
g++ -std=c++20 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer test_upload_watermark.cpp -o test-upload-watermark-sanitized
ASAN_OPTIONS=detect_leaks=0 ./test-upload-watermark-sanitized
```

Renderer-only cached CI handoff: apply this exact patch to the pinned renderer source, rebuild all affected renderer translation units (private class layout changes), retain default-off behavior in the artifact, and do not alter game/IPA/pipeline files in this sidecar. Main-agent patch has no overlapping file targets. Before opt-in deployment, target build and on-device Metal validation are required. Then compare identical launch/game conditions with flag off/on, same diagnostic sampling, at least three runs; inspect upload blocks/bytes, event progress, process footprint, command-buffer errors, lock/query latency and p95/p99 pacing. Roll back on new errors, content changes, query stalls or worse pacing; do not promote if there is no measured benefit.

Log: `/home/_ali/Documents/Codex/2026-09-15/y/work/r6-resolution/build74-framedip-crash-20260916T233039Z/madeira-log.txt`.

## Evidence and theory

Log lines 52232–52264 show physical-footprint peak 6110 MB and final sampled footprint 6096 MB, compressed 2780 MB. Lines 52355–52381 report LIVE requested capacity 3707 MB, Metal `currentAllocatedSize` 1567 MB, requested texture-private capacity 3264 MB, buffers 317 MB, staging rings 104 MB (peak 136), and init-upload 21 MB. Units are the logger's MB. These are different accounting domains and adjacent, not atomic, samples.

`currentAllocatedSize` is the device's resource-allocation total, not whole-process footprint or a per-resource residency census. Apple recommends correlating CPU allocations, VM accounting, and Metal resources. Do not subtract these counters to assign the remainder to a leak, or add compressed memory to footprint again. [Apple device allocation counter](https://developer.apple.com/documentation/metal/mtldevice/currentallocatedsize?language=objc), [Apple game-memory profiling, WWDC22](https://developer.apple.com/videos/play/wwdc2022/10106/).

Reuse is already 99% (1,879,344 hits / 1,896,312 calls), current FIFO depth 15, historical maximum 210, sequence-lag maximum 9. The reported census spans a bounded diagnostic table; it is not complete ownership coverage. Creation-site attribution reports 296 MB original buffers versus 17 MB dynamic fresh allocations and 2 MB staging pool. This does not support a speculative larger dynamic cache or treating repeated rename count as newly resident memory. Crash cause remains unproven; no OS termination-report search was performed in this sidecar.

On unified-memory iPhone, shared and private both consume system memory; private removes CPU accessibility and permits driver optimizations, not a separate free VRAM budget. `winemetal.h:125–130` already remaps managed to shared under `DXMT_IOS`; `winemetal_unix.c:3720–3725` already excludes managed synchronization on iOS. A “managed → shared” patch would duplicate existing behavior. [Apple resource storage guidance](https://developer.apple.com/library/archive/documentation/3DDrawing/Conceptual/MTLBestPracticesGuide/ResourceOptions.html).

CPU writes must finish before GPU reads; memory reuse requires GPU last-use completion. A chunk is not a frame: DXMT has 32 command-chunk slots, an upload queue capacity of 2, and potentially multiple chunks per frame. Apple's triple-buffering example is an application pattern, not a justification for replacing DXMT sequence ownership with modulo-three reuse. [Apple dynamic-buffer guidance](https://developer.apple.com/library/archive/documentation/3DDrawing/Conceptual/MTLBestPracticesGuide/TripleBuffering.html).

## Ranked proposals

Ranking considers distinctness, source evidence, semantic risk, and measurable benefit. “Actionable” means a bounded next investigation/prototype, **not approved for integration**.

### 1. Actionable conditional prototype: decode BC directly into reserved upload storage

Evidence: creation uploads in `dxmt_resource_initializer.cpp:485–575` allocate a complete decoded heap image, then reserve staging and copy it through `updateContents`. Streamed uploads in `d3d11_context_impl.cpp:4067–4115` repeat that pattern; staging-to-texture BC copies around 3760–3793 also decode to a temporary image then stage it. Thus an extra decoded-image allocation and full-image copy exist in these paths. The log reports 173 BC updates and 86,678 BC copy-region operations cumulatively; the latter includes other copy routes and does **not** quantify decode-path hits.

Proposal: reserve the exact physical-format extent, decode synchronously into a writable reservation, then publish the initialized blit. This could remove one temporary decoded image and one copy for each qualifying operation. A 4096×4096 RGBA8 temporary is 64 MiB by arithmetic; this is not measured workload savings or sustained-footprint reduction. Keep all logical descriptors, mip translation, quality, formats, and game data unchanged.

Why not patched: `WMT::Buffer` exposes `updateContents`, not a writable mapping. Staging allocators configured with `placed_buffer=false` receive a CPU pointer in `WMTBufferInfo` but do not expose it in their reservation result. A correct change needs an explicit writable-reservation/publish contract, not casting a Metal handle. Remote buffer updates maintain a CPU shadow and upload ranges (`winemetal_unix.c:301–334,3705–3715`); direct local-pointer writes must not bypass publication. Remote mode's participation in this phone run is not established.

Risks/gates: retain reservation and destination through their own last GPU use; keep CPU decoder synchronous so callers can recycle input on return; preserve alignment and physical pitch, partial boxes, tiny/odd BC dimensions, signed BC formats, sRGB handling, mip bias and array slices; no new BC6H claim or 3D decode support. Decoder destination reads must be checked before targeting write-combined memory. Creation decode currently precedes `mutex_`; moving it inside extends contention, while unlocking before publish needs a reservation lifetime proof. Retry macros can flush/reset command storage: reserve and fully initialize without allowing an incomplete blit to be encoded. Preserve failure behavior and never fall back to raw BC bytes on OOM. [Microsoft update-source lifetime and snapshot semantics](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-updatesubresource), [Microsoft write-combined map cautions](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-map).

Tests: byte-compare existing decode output against reservation output for supported BC kinds, pitches and sizes; canaries around exact reservation ranges; OOM/flush fault injection; immediate/deferred command lists and replay; local and remote backend tests; actual-device API validation and capture. Observe decode bytes/time, peak overlapping temporary bytes, copy bytes, lock wait, upload publish calls, footprint and p95/p99 frame times. Require identical contents and no new stalls or lifetime violations before export/build.

### 2. Selected bounded experiment: stale upload completion watermark

Evidence: `ResourceInitializer::allocateGpuHeap` uses cached completion at 649–653; `flushInternal` refreshes it after commit at 595; idle `flushToWait` frees blocks using the old value before refreshing at 605–608. Uploads completing between observations may temporarily remain unavailable to reuse. This is a conservative observation delay, not evidence of broken fences. Ring reuse uses strict `< coherent_id`; freeing uses `<=`. Their difference is not sufficient proof to change the boundary.

Measure cached-versus-actual upload-event lag and allocation misses attributable specifically to stale knowledge. The exported default-off experiment uses one refresh per 64 allocation calls under the initializer mutex, preserving queue-specific sequence identity and all synchronization. An allocation-miss boundary hook would require an allocator API change; it was deliberately not implemented. No query occurs with the flag off.

Risks/tests: upload and main-queue sequence numbers are different domains; never substitute main `cpu_coherent`. The ring can keep references after its own lock releases; audit caller synchronization. Model exact-boundary completion, mid-block appends, oversized blocks, flush retries and delayed GPU completion; stress simultaneous initializer callers. Observe blocks/bytes in flight versus completed, upload watermark age, query cost, reuse misses and allocation bursts. Current 104 MB staging capacity does not explain multi-GB footprint growth by itself; no cap/TTL adjustment proposed.

### 3. Theoretical, lower priority: private backing for immutable initialized buffers

Evidence: `d3d11_buffer.cpp:80–101` chooses managed (shared on iOS) when non-dynamic buffers have initial data, then directly writes contents. Private currently applies to certain output-bound resources without initial data.

Proposal: evaluate immutable, CPU-inaccessible buffers only, initialized via a retained upload operation and existing upload-event dependency. Do not blanket-convert default buffers: update/map/copy/readback behavior differs. Private may improve GPU access/layout but can add staging, initialization latency and memory overlap; no footprint reduction follows automatically. Gate on CPU-access flags and full view/copy compatibility, including buffer-backed texture views. Measure upload bytes, added queue waits, GPU reads, object count and process footprint. This needs a renderer change and device profiling, so is not integrated. Storage-mode rationale is covered by Apple's resource guidance above.

### 4. Theoretical architectural work only: alias translator-owned transient scratch

Only resources proven internal, mutually non-overlapping in GPU lifetime, and not retained for deferred replay qualify. `copy_temp_allocator` is a private, untracked ring; a useful first question is whether overlapping scratch reservations dominate actual allocation. Heap aliasing can share backing, but D3D game resources cannot be declared dead merely because a frame ended. Required last-use tracking across encoders/queues conflicts with this sidecar's no-fence-change scope. Not an implementation candidate here. [Apple heap ownership and aliasing](https://developer.apple.com/library/archive/documentation/Miscellaneous/Conceptual/MetalProgrammingGuide/ResourceHeaps/ResourceHeaps.html), [Apple current heap guidance](https://developer.apple.com/documentation/metal/memory-heaps?changes=__7_8).

## Lifetime/synchronization findings and rejected shortcuts

`CommandQueue::WaitForFinishThread` waits for completion, checks errors, resets retained command state, advances main CPU coherence, then frees staging/scratch/argument blocks (`dxmt_command_queue.cpp:176–199`). Preserve this ownership order. No in-flight release, new trim cap, memory protection, or fence edit is proposed.

Initializer commit calls `reset()` immediately after commit and clears its ref tracker. The native wrapper uses normal retaining `[queue commandBuffer]` (`winemetal_unix.c:212`). Therefore switching to unretained command buffers is not a drop-in optimization: initializer resources need a newly proven completion-held ownership path, and remote retention needs separate confirmation. [Apple command-buffer retained-resource contract](https://developer.apple.com/documentation/metal/mtlcommandbufferdescriptor/retainedreferences?changes=_3%2C_3).

`StagingResource::tryMap` distinguishes CPU read-after-GPU-write from CPU write-after-GPU-use (`dxmt_staging.cpp:43–54`). Immediate map renaming copies the prior staging contents (`d3d11_context_imm.cpp:249`); skipping it under ordinary WRITE is not equivalent to DISCARD. WRITE_DISCARD renames, whereas NO_OVERWRITE returns existing memory under the application's non-overlap promise. Preserve these distinctions and feature gating; no per-resource triple-buffer replacement. [Microsoft D3D11 map semantics](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ne-d3d11-d3d11_map).

Reject memoryless conversion of general D3D textures, lossy BC→ASTC transcoding, mip/quality changes, purgeability of game-owned or replay-visible resources, speculative cache growth, and any assumption that process termination is proven jetsam. None meets the current semantic/scope constraints.

## Observability and validation handoff

1. Use existing low-rate diagnostic timestamps to correlate footprint, compressed bytes, Metal allocation, upload/main sequence progress, and frame pacing. Avoid a synchronous allocation census while holding allocator/decoder locks; main owns that optimization.
2. In a separately authorized diagnostic build, label/tag resources by actual storage mode, physical extent, owner, creation stack and last-use domain. Gather CPU allocations/VM and Metal capture at menu, after streaming, and after return-to-menu. Distinguish live allocations, allocator-retained capacity and backing shared by views. Apple's Game Memory Instruments template and Metal Debugger are the primary tools; tracing itself has overhead.
3. Gather decoder-path hits/bytes separately for creation, streamed updates and staging copies; distinguish original BC storage, decoded temporaries and upload reservations. Do not multiply all BC copy operations by texture size.
4. For an isolated future candidate, require host byte/lifetime tests, sanitizers where supported, target build, local/remote protocol coverage, Metal API validation, then at least three matched baseline/candidate device runs with unchanged game settings. Include a long streaming/replay run; compare footprint trajectory and p95/p99 pacing, not average FPS alone. Keep instrumentation equal; disable costly validation for performance runs.
5. On another termination, correlate an actual timestamp/process-matched OS report and command-buffer error/status logs before naming the cause. Success requires unchanged rendering/semantics and measured improvement without increased contention, errors or upload stalls; no FPS promise.

Cache/provenance verification is read-only and re-runnable after integration:

```sh
bash verify.sh /absolute/path/to/main/renderer/source /absolute/path/to/git/repository-containing-pinned-commit
```

It hashes pinned Git objects as authority and accepts either both pristine target files (forward apply check) or both exported candidate target files (reverse apply check). It does not demand that an edited supplied source still equals the pristine baseline, nor demand a clean full worktree. Its default supplied source is the own candidate copy. If review changes either target beyond this exported candidate, regenerate the exact patch/manifest before using it as cache authority. Own newline-normalized baseline copies are not the hash authority.

Changed paths within this directory: `REPORT.md`, `EVIDENCE.json`, `patch-manifest.json`, `upload-watermark-experiment.patch`, `verify.sh`, `test_upload_watermark.cpp`, baseline/candidate copies of the two initializer files, and the two host-test binaries. Integration status: exported experiment only; host build/test passed, Apple renderer build/GPU validation pending. No shared source, IPA or CI modification.
