#!/usr/bin/env bash
set -euo pipefail
# Read-only verification. The pinned Git objects, not an edited working tree,
# are baseline authority. Supplied targets may be pristine OR fully patched.
research_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
supplied_source="${1:-$research_dir/candidate}"
object_repository="${2:-/tmp/madeira-release-dxmt}"
manifest="$research_dir/patch-manifest.json"
revision="$(jq -er '.base_commit' "$manifest")"
expected_patch="$(jq -er '.patch_sha256' "$manifest")"
actual_patch="$(sha256sum "$research_dir/upload-watermark-experiment.patch" | awk '{print $1}')"
[[ "$actual_patch" == "$expected_patch" ]] || { echo 'FAIL: exported patch checksum'; exit 1; }
source_state=''
for relative in src/dxmt/dxmt_resource_initializer.cpp src/dxmt/dxmt_resource_initializer.hpp; do
  expected_before="$(jq -er --arg f "$relative" '.files[$f].before_pinned_git_bytes' "$manifest")"
  expected_after="$(jq -er --arg f "$relative" '.files[$f].after' "$manifest")"
  object_hash="$(git -C "$object_repository" show "$revision:$relative" | sha256sum | awk '{print $1}')"
  [[ "$object_hash" == "$expected_before" ]] || { echo "FAIL: pinned object $relative"; exit 1; }
  supplied_hash="$(sha256sum "$supplied_source/$relative" | awk '{print $1}')"
  if [[ "$supplied_hash" == "$expected_before" ]]; then
    this_state='pristine'
  elif [[ "$supplied_hash" == "$expected_after" ]]; then
    this_state='patched'
  else
    echo "FAIL: target differs from both pinned baseline and exported candidate: $relative"
    exit 1
  fi
  [[ -z "$source_state" || "$source_state" == "$this_state" ]] || { echo 'FAIL: partially applied patch'; exit 1; }
  source_state="$this_state"
done
if [[ "$source_state" == 'pristine' ]]; then
  git -C "$supplied_source" apply --check "$research_dir/upload-watermark-experiment.patch"
else
  git -C "$supplied_source" apply --reverse --check "$research_dir/upload-watermark-experiment.patch"
fi
echo "PASS: pinned Git-object provenance, exact patch checksum, targets=$source_state, applicable/reversible. No files modified."
