// Host model: actual copied allocation method and unchanged ring template.
// No Metal driver, protocol, or Apple SDK validation is implied.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <map>
#include <mutex>
#include <queue>
#include <random>
namespace WMT { struct Buffer { uint64_t id=0; explicit operator bool() const {return id!=0;} }; }
#define WARN(...) ((void)0)
namespace dxmt {
using mutex=std::mutex;
constexpr size_t kStagingBlockSize=32;
constexpr size_t kStagingBlockLifetime=300;
constexpr size_t kResourceInitializerGpuUploadHeapAlignment=8;
template<typename T> T align(T value,size_t alignment) {
 return (value+alignment-1)&~T(alignment-1);
}
template <typename Allocator, size_t BlockSize = kStagingBlockSize, class mutex = dxmt::mutex> class RingBumpState {

public:

  static constexpr size_t block_size = BlockSize;

  RingBumpState(Allocator &&allocator) : allocator_(std::move(allocator)) {}

  std::pair<typename Allocator::Block &, uint64_t>
  allocate(uint64_t seq_id, uint64_t coherent_id, size_t size, size_t alignment);

  void free_blocks(uint64_t coherent_id);

private:
  struct Allocation {
    size_t allocated_size;
    size_t total_size;
    uint64_t last_used_seq_id;
    uint64_t inc_time_to_live;
    Allocator::Block block;
  };

  Allocation &allocate_or_reuse_block(uint64_t seq_id, uint64_t coherent_id, size_t block_size);

  std::pair<typename Allocator::Block &, uint64_t>
  suballocate(Allocation &allocation, size_t size, size_t alignment) {
    auto offset = align(allocation.allocated_size, alignment);
    allocation.allocated_size = offset + size;
    return {allocation.block, offset};
  };

  std::queue<Allocation> fifo;
  mutex mutex_;
  Allocator allocator_;
};


template <typename Allocator, size_t BlockSize, class mutex>
std::pair<typename Allocator::Block &, uint64_t>
RingBumpState<Allocator, BlockSize, mutex>::allocate(
    uint64_t seq_id, uint64_t coherent_id, size_t size, size_t alignment
) {
  std::lock_guard<mutex> lock(mutex_);
  while (!fifo.empty()) {
    auto &latest = fifo.back();
    if ((align(latest.allocated_size, alignment) + size) > latest.total_size) {
      break;
    }
    latest.last_used_seq_id = seq_id;
    return suballocate(latest, size, alignment);
  }
  return suballocate(
      allocate_or_reuse_block(
          seq_id, coherent_id, std::max(size, BlockSize) // in case required size is larger than block size
      ),
      size, alignment
  );
};

template <typename Allocator, size_t BlockSize, class mutex>
void
RingBumpState<Allocator, BlockSize, mutex>::free_blocks(uint64_t coherent_id) {
  std::lock_guard<mutex> lock(mutex_);
  while (!fifo.empty()) {
    auto &front = fifo.front();
    if (front.last_used_seq_id > coherent_id)
      break;
    auto expired = (coherent_id - front.last_used_seq_id) > kStagingBlockLifetime ||
                   front.inc_time_to_live > kStagingBlockLifetime || coherent_id == -1ull;
    auto adhoc = front.total_size != BlockSize;
    if (expired || adhoc) {
      // can be deallocated
      fifo.pop();
      continue;
    }
    front.inc_time_to_live++;
    break;
  }
};

template <typename Allocator, size_t BlockSize, class mutex>
RingBumpState<Allocator, BlockSize, mutex>::Allocation &
RingBumpState<Allocator, BlockSize, mutex>::allocate_or_reuse_block(
    uint64_t seq_id, uint64_t coherent_id, size_t block_size
) {
  while (!fifo.empty()) {
    auto &front = fifo.front();
    if (front.last_used_seq_id < coherent_id) {
      if (front.total_size != BlockSize) {
        fifo.pop();
        continue;
      } else if (front.total_size >= block_size) {
        front.last_used_seq_id = seq_id;
        front.allocated_size = 0;
        front.inc_time_to_live = 0;
        fifo.push(std::move(front));
        fifo.pop();
        return fifo.back();
      }
      WARN("forced to allocate new block of size ", block_size);
    }
    break;
  }
  fifo.push({
      .allocated_size = 0,
      .total_size = block_size,
      .last_used_seq_id = seq_id,
      .inc_time_to_live = 0,
      .block = allocator_.allocate(block_size),
  });
  return fifo.back();
};


struct FakeAllocator {
 struct Block { WMT::Buffer buffer; };
 uint64_t next=1;
 Block allocate(size_t) { return {{next++}}; }
};
struct Event {
 uint64_t actual=0, polls=0;
 uint64_t signaledValue() { ++polls; return actual; }
};
struct State {
 uint64_t current_seq_id_=1, cached_coherent_seq_id=0;
 bool experimental_upload_watermark_refresh_=false;
 uint32_t upload_watermark_poll_countdown_=0;
 Event upload_queue_event_;
 RingBumpState<FakeAllocator,32> gpu_command_heap_allocator{FakeAllocator{}};
 WMT::Buffer allocateGpuHeap(size_t,size_t&);
};
struct Baseline:State { WMT::Buffer allocateGpuHeap(size_t,size_t&); };
WMT::Buffer
State::allocateGpuHeap(size_t size, size_t &offset) {
  // Called under mutex_. Poll only our upload event, never main-queue coherence.
  // Default off; at most one additional query per 64 upload allocations.
  if (experimental_upload_watermark_refresh_) {
    if (upload_watermark_poll_countdown_ == 0) {
      const auto observed = upload_queue_event_.signaledValue();
      // Never include the current, uncommitted upload sequence or regress.
      const auto completed = std::min(observed, current_seq_id_ - 1);
      cached_coherent_seq_id = std::max(cached_coherent_seq_id, completed);
      upload_watermark_poll_countdown_ = 64;
    }
    --upload_watermark_poll_countdown_;
  }
  auto [block, offset_] = gpu_command_heap_allocator.allocate(
      current_seq_id_, cached_coherent_seq_id, size, kResourceInitializerGpuUploadHeapAlignment
  );
  offset = offset_;
  return block.buffer;
}

WMT::Buffer
Baseline::allocateGpuHeap(size_t size, size_t &offset) {
  auto [block, offset_] = gpu_command_heap_allocator.allocate(
      current_seq_id_, cached_coherent_seq_id, size, kResourceInitializerGpuUploadHeapAlignment
  );
  offset = offset_;
  return block.buffer;
}

}
int main() {
 using namespace dxmt;
 uint64_t cases=0, reuse=0;
 std::mt19937_64 rng(0xb4b89f0a);
 // Default-off differential equivalence against the original method.
 for(unsigned trial=0;trial<1000;++trial) {
  Baseline a; State b;
  for(unsigned i=0;i<100;++i) {
   if(rng()%3==0) { ++a.current_seq_id_; b.current_seq_id_=a.current_seq_id_; }
   uint64_t c=rng()%a.current_seq_id_;
   a.cached_coherent_seq_id=b.cached_coherent_seq_id=c;
   size_t size=1+rng()%97, x=0,y=0;
   auto ax=a.allocateGpuHeap(size,x), by=b.allocateGpuHeap(size,y);
   assert(ax.id==by.id && x==y);
   assert(a.cached_coherent_seq_id==b.cached_coherent_seq_id);
   assert(b.upload_queue_event_.polls==0);
   ++cases;
  }
 }
 // Actual ring lifetime assertions under stale cached completion knowledge.
 for(unsigned trial=0;trial<1000;++trial) {
  State s; s.experimental_upload_watermark_refresh_=true;
  struct Last { uint64_t seq; size_t end; };
  std::map<uint64_t,Last> last;
  for(unsigned i=0;i<256;++i) {
   if(rng()%4==0) {
    ++s.current_seq_id_;
    // Original flush path may sample completion, including a delayed event.
    if(rng()%2==0) s.cached_coherent_seq_id=s.upload_queue_event_.actual;
   }
   const uint64_t committed=s.current_seq_id_-1;
   if(rng()%3==0)
    s.upload_queue_event_.actual += rng()%(committed-s.upload_queue_event_.actual+1);
   size_t size=1+rng()%97, offset=0;
   auto b=s.allocateGpuHeap(size,offset);
   assert(s.cached_coherent_seq_id<=s.upload_queue_event_.actual);
   assert(s.cached_coherent_seq_id<s.current_seq_id_);
   if(auto it=last.find(b.id);it!=last.end()) {
    if(offset==0) {
     assert(it->second.seq<s.cached_coherent_seq_id); // source keeps strict <.
     assert(it->second.seq<s.upload_queue_event_.actual);
     ++reuse;
    } else {
     assert(offset>=it->second.end); // no overlapping overwrite of live bytes.
    }
   }
   last[b.id]={s.current_seq_id_,offset+size};
   s.gpu_command_heap_allocator.free_blocks(s.cached_coherent_seq_id);
   assert(s.upload_queue_event_.polls==(i/64+1));
   ++cases;
  }
 }
 // Clamp even a future-valued event; stale query must not regress cached value.
 {
  State s; s.experimental_upload_watermark_refresh_=true;
  s.current_seq_id_=10; s.cached_coherent_seq_id=4; s.upload_queue_event_.actual=100;
  size_t offset; s.allocateGpuHeap(32,offset);
  assert(s.cached_coherent_seq_id==9);
  s.upload_watermark_poll_countdown_=0; s.upload_queue_event_.actual=0;
  s.allocateGpuHeap(32,offset);
  assert(s.cached_coherent_seq_id==9);
  ++cases;
 }
 // Boundary equality is NOT made reusable; a later completed sequence is.
 {
  State s; s.experimental_upload_watermark_refresh_=true;
  size_t offset;
  const auto first=s.allocateGpuHeap(32,offset);
  s.current_seq_id_=2; s.upload_queue_event_.actual=1;
  s.upload_watermark_poll_countdown_=0;
  const auto second=s.allocateGpuHeap(32,offset);
  assert(first.id!=second.id);
  s.current_seq_id_=3; s.upload_queue_event_.actual=2;
  s.upload_watermark_poll_countdown_=0;
  const auto third=s.allocateGpuHeap(32,offset);
  assert(first.id==third.id);
  ++cases;
 }
 assert(reuse>0);
 std::printf("PASS: %llu host cases; %llu completion-safe reuse events; default-off equivalence; polling bound; current-sequence clamp; strict boundary. Not GPU evidence.\n",
  (unsigned long long)cases,(unsigned long long)reuse);
}
