"""Synthetic bounds/versions + actual rejected build78 embedded metallib.

Run from any directory: python3 -B work/dx11-opt/test_metallib.py.
No files, archives, DLLs, shader sources, or packaging controls are changed.
"""
import hashlib
import runpy
import struct
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
API = runpy.run_path(str(ROOT / 'control/.github/dx11-opt/verify_metallib.py'))
verify, inspect = API['verify'], API['inspect']


def tag(name, payload):
    return name + struct.pack('<H', len(payload)) + payload


def function(index, language=(3, 1), omit=None, duplicate=None, extra=b''):
    values = [(b'NAME', ('kernel_%d' % index).encode() + b'\0'),
              (b'TYPE', b'\2'), (b'HASH', b'\0' * 32),
              (b'MDSZ', struct.pack('<Q', 4)),
              (b'OFFT', struct.pack('<3Q', index * 8, index * 8, 0)),
              (b'VERS', struct.pack('<4H', 2, 6, *language))]
    result = b''.join(tag(name, payload) for name, payload in values if name != omit)
    if duplicate:
        result += next(tag(name, payload) for name, payload in values if name == duplicate)
    return result + extra + b'ENDT'


def fixture(versions=((3, 1),), grouped=False, header=(2, 7), **kwargs):
    functions = [function(i, version, **kwargs) for i, version in enumerate(versions)]
    if grouped:
        content = b''.join(functions)
        records = struct.pack('<I', 4 + len(content)) + content
    else:
        records = b''.join(struct.pack('<I', 4 + len(f)) + f for f in functions)
    table = struct.pack('<I', len(functions)) + records + b'ENDT'
    metadata = (struct.pack('<I', 4) + b'ENDT') * len(functions)
    bitcode = b'BC\xc0\xde'  # Range fixture only; no claim of executable LLVM.
    public = 88 + len(table)
    private = public + len(metadata)
    bc = private + len(metadata)
    size = bc + len(bitcode)
    packed = struct.pack('<4sHHHBBHH9Q', b'MTLB', 0x8001, *header, 0, 0x82, 17, 0,
                         size, 88, len(records), public, len(metadata), private,
                         len(metadata), bc, len(bitcode))
    assert len(packed) == 88
    return packed + table + metadata + metadata + bitcode


def change(data, offset, fmt, value):
    result = bytearray(data)
    struct.pack_into(fmt, result, offset, value)
    return bytes(result)


class MetallibTests(unittest.TestCase):
    def rejected(self, data, message=None):
        context = self.assertRaisesRegex(ValueError, message) if message else self.assertRaises(ValueError)
        with context:
            verify(data)

    def test_known_layouts_and_byteslike(self):
        for header in ((2, 7), (2, 9)):
            for grouped in (False, True):
                for wrapper in (bytes, bytearray, memoryview):
                    with self.subTest(header=header, grouped=grouped, wrapper=wrapper):
                        info = verify(wrapper(fixture(((2, 4), (3, 1)), grouped, header)))
                        self.assertEqual(info['language'], '3.1')
                        self.assertEqual(info['function_count'], 2)
                        self.assertEqual([f['name'] for f in info['functions']], ['kernel_0', 'kernel_1'])
                        self.assertEqual(info['functions'][1]['language_version'], [3, 1])

    def test_every_function_language(self):
        for version in ((3, 2), (4, 0), (4, 1), (5, 0), (65535, 65535)):
            for grouped in (False, True):
                with self.subTest(version=version, grouped=grouped):
                    data = fixture(((3, 1), version), grouped=grouped)
                    self.assertEqual(inspect(data)['functions'][1]['language_version'], list(version))
                    self.rejected(data, 'kernel_1 requires Metal')
        self.rejected(fixture(((0, 1),)), 'zero VERS')

    def test_header_magic_version_type_exact_size(self):
        data = fixture()
        self.rejected(b'nope' + data[4:], 'magic')
        self.rejected(fixture(header=(3, 0)), 'unsupported header')
        self.rejected(fixture(header=(2, 8)), 'unsupported header')
        self.rejected(change(data, 10, '<B', 1), 'non-executable')
        self.rejected(change(data, 16, '<Q', len(data) + 1), 'file size')
        self.rejected(data + b'padding', 'file size')
        self.rejected('MTLB', 'bytes-like')

    def test_all_truncation_prefixes(self):
        data = fixture(((3, 1), (3, 1)))
        for length in range(len(data)):
            with self.subTest(length=length):
                self.rejected(data[:length])

    def test_sections_and_counts(self):
        data = fixture()
        for at in (24, 32, 40, 48, 56, 64, 72, 80):
            with self.subTest(offset=at):
                self.rejected(change(data, at, '<Q', 0xffffffffffffffff))
        self.rejected(change(data, 24, '<Q', 80), 'boundary')
        self.rejected(change(data, 88, '<I', 0), 'count')
        self.rejected(change(data, 88, '<I', 4097), 'count')
        self.rejected(change(data, 88, '<I', 2), 'count mismatch')
        self.rejected(change(data, 92, '<I', 0), 'record length')
        self.rejected(change(data, 92, '<I', 0xffffffff), 'record length')
        size, = struct.unpack_from('<Q', data, 32)
        at = 92 + size
        self.rejected(data[:at] + b'NOPE' + data[at + 4:], 'extended-header')

    def test_function_tag_bounds_and_required_versions(self):
        for required in (b'NAME', b'TYPE', b'HASH', b'MDSZ', b'OFFT', b'VERS'):
            self.rejected(fixture(omit=required), 'missing required')
            self.rejected(fixture(duplicate=required), 'duplicate tag')
        data = fixture()
        at = data.index(b'VERS')
        self.rejected(change(data, at + 4, '<H', 7), 'invalid VERS|missing/truncated|FourCC')
        self.rejected(change(data, at + 4, '<H', 0xffff), 'tag payload')
        self.rejected(change(data, at + 6, '<H', 0), 'zero VERS')
        at = data.index(b'NAME')
        self.rejected(change(data, at + 4, '<H', 0xffff), 'tag payload')
        terminator = data.index(b'kernel_0\0') + len(b'kernel_0')
        self.rejected(change(data, terminator, '<B', 65), 'NAME')
        self.rejected(change(data, data.index(b'TYPE') + 6, '<B', 255), 'TYPE')
        self.rejected(fixture(extra=tag(b'bad!', b'')), 'FourCC')
        self.rejected(fixture(extra=tag(b'EXTR', b'')), 'unsupported function tag')
        # Hash payload resembling VERS is opaque data, not a function version.
        fake = b'VERS\x08\x00\x02\x00\x09\x00\x04\x00\x01\x00'
        data = fixture().replace(tag(b'HASH', b'\0' * 32), tag(b'HASH', fake.ljust(32, b'\0')))
        info = verify(data)
        self.assertEqual(info['language'], '3.1')
        verify(fixture(extra=tag(b'TESS', b'\1')))
        self.rejected(fixture(extra=tag(b'LAYR', b'\0\0')), 'LAYR length')

    def test_metadata_and_function_bitcode_bounds(self):
        data = fixture()
        public, = struct.unpack_from('<Q', data, 40)
        self.rejected(change(data, public, '<I', 0), 'metadata block')
        self.rejected(change(data, public, '<I', 0xffffffff), 'metadata block')
        self.rejected(data[:public + 4] + b'FAIL' + data[public + 8:])
        at = data.index(b'OFFT') + 6
        self.rejected(change(data, at, '<Q', 1), 'metadata block starts')
        self.rejected(change(data, at + 8, '<Q', 0xffffffffffffffff), 'metadata block starts')
        self.rejected(change(data, at + 16, '<Q', 4), 'bitcode range')
        at = data.index(b'MDSZ') + 6
        self.rejected(change(data, at, '<Q', 0), 'bitcode range')
        self.rejected(change(data, at, '<Q', 0xffffffffffffffff), 'bitcode range')

    def test_actual_build78_bad_embedded_library(self):
        ipa = ROOT.parents[1] / 'outputs/release-build78/Madeira.ipa'
        with zipfile.ZipFile(ipa) as archive:
            dll = archive.read('Payload/Madeira.app/arm64ec-windows/d3d11.dll')
        self.assertEqual(hashlib.sha256(dll).hexdigest(),
                         '29bfa0f460d2bb5f8aa0e95ca7603920fe8c8f8d92ac20c17cfc262e299e0ec9')
        # Exact known helper bytes; other MTLB hits are import/debug symbol text.
        offset = 2773000
        size, = struct.unpack_from('<Q', dll, offset + 16)
        self.assertEqual(size, 150497)
        data = dll[offset:offset + size]
        self.assertEqual(hashlib.sha256(data).hexdigest(),
                         'b7adb9ee81645ca165688330d35ddf48d3d459729e31b9d03806fb6176d67327')
        info = inspect(data)
        self.assertEqual(info['header_version'], [2, 9])
        self.assertEqual(info['language'], '4.1')
        self.assertEqual(info['function_count'], 35)
        self.assertTrue(all(f['language_version'] == [4, 1] for f in info['functions']))
        self.rejected(data, 'requires Metal 4.1')


if __name__ == '__main__':
    unittest.main(verbosity=2)
