# Madeira DX11 / Metal optimization candidate

This is a renderer experiment, not a verified performance or crash fix. Game
settings, resolution, saves, JIT pool size, fences, resource retention, texture
quality and the native WineMetal provider are not changed.

## Included in candidate source

- Compile all guest renderer objects with `-O2` instead of cached `-O0`; retain
  assertions/debug information, with no fast-math or LTO. Cached unoptimized
  objects are not merely relinked.
- Hash every shader-variant equality field instead of only its variant kind;
  reuse the successful shader-cache iterator rather than looking up twice.
- Avoid temporary reference-count operations on recycled dynamic buffers.
  Default-off covered memory-census/statistics work no longer performs the
  heavy hot-path scans, without changing the 64-completed-entry reserve.
- Batch five initial Metal vertex/fragment buffer-binding bridge calls into one.
  All five native Metal operations, slots, values and order are preserved.
- Optional, default-off upload-watermark experiment polls completed upload work
  every 64 allocations, bounded to prior submitted sequences, to permit earlier
  eligible reuse. No GPU waits, event signaling or lifetime rules are removed.
- Separate app controls for renderer diagnostics and upload reuse. Save and
  fully reopen Madeira to apply these process/device-construction settings.
  Runtime/audio diagnostics remain separately controllable and off at startup.

Host tests use actual extracted methods/headers with mocked platform/GPU
boundaries: 6,162 allocator cases, 356,002 watermark cases, 80,000 binding cases,
shader hash/equality/cache race coverage and ASan/UBSan runs. These do not prove
GPU correctness, FPS improvements, absence of leaks or a fix for the crash.

## Researched but not included

- Metal PSO binary archives: read-only prototype has no compatible archive and
  cannot create persistence. Reliable harvesting needs native error reporting,
  bounded cache identity/lifetime and device validation; remote transport also
  needs archive protocol support. Existing AIR shader caching is not a PSO
  binary cache. See `../dx11-metal-pipeline-research/FINDINGS.md`.
- Direct BC decode into reserved upload storage: potentially avoids a decoded
  temporary/copy, but needs a safe publish/mapping contract, pitch/alignment,
  write-combined access and remote support.
- Translator-owned scratch aliasing/private immutable backing: only justified
  with measured lifetime/residency evidence; not a generic memory reduction.
- Pass/submission merging, indirect command buffers or Metal 4 argument tables:
  require larger native/translator changes and proofs for D3D visibility,
  attachment actions, queries, UAV hazards and synchronization boundaries.
- Bounded shader-cache database batching/per-worker readers and PSO prewarming:
  require concurrency, I/O and memory-budget validation.

No archive prototype, unretained command-buffer switch, removed barrier/fence,
private API or game-quality change is included merely because it is theoretical.
Experimental upload polling may regress CPU/bridge cost and can be disabled.

## Build and device validation

Pinned DXMT: `b4b89f0a5a1752da3982a7b6c5575506024bf253`.
Private CI uses an isolated branch, read-only existing compiler/runtime caches
and export-derived import libraries for the preserved provider. Both AArch64
and ARM64EC must compile and pass PE/export/import compatibility checks before
IPA assembly. Full corresponding modified renderer source and build/test
controls are included with the candidate.

## Build checkpoints

The isolated CI workflow restores/saves guest compilation stages under new
`dx11-guest-v1-*` keys, including on a failed build. Each successful object has
an atomic checkpoint recording the effective command and output SHA-256.
Reuse also requires identical pinned source patch, compiler-cache identity,
provider exports, build/validation policy and architecture. Missing/corrupt
objects or changed commands are rebuilt; unidentified/mismatched stages are
rejected. Debug `-O0` objects from the baseline cache have no valid checkpoint
and cannot be mistaken for freshly compiled `-O2` objects.

After an architecture completes, its DLL hashes are recorded in the stage.
Retries reuse valid objects, then rebuild archives and links to refresh import
libraries and rerun binary validation. Cache saves use per-run suffixes, so a
partial immutable checkpoint does not prevent a later complete checkpoint.
Public build caches are never overwritten. Host tests cover restore, changed
source/flags, corrupted/missing objects, path guards and concurrent writes.

Raw ARM64EC PE machine `0x8664` plus CHPE metadata is the same form as the
installed baseline. Validation checks executable native EC code ranges and
does not rewrite the machine tag. Ordinary x64 DLLs without native EC metadata
are rejected; original ARM64/EC DLLs and nine rejection cases pass host tests.

Target compilation and final IPA assembly passed for both architectures. CI run
`35165674471`, control commit `eea5eea8b91352f7e3a4148dd8b5831b993694ea`,
saved an isolated 33,972,293-byte compilation checkpoint. The IPA package checks
export ordinals/names, provider imports, native UI linking and ZIP integrity,
and preserves all other baseline resources, executable, controller and prefix.
The package is unsigned/signable; not installed or device-benchmarked yet.

Device comparison is pending. Before
promotion, compare matched game scenes/settings/saves on baseline and candidate
with diagnostics equally configured: frame p95/p99, sustained memory, image
correctness, audio/controller behavior and crashes. No device gain is claimed.
Rollback is the prior app artifact, not deletion of game files or saves.
