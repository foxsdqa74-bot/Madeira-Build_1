#pragma once
#include <cstdint>
#include <cstring>
#include <functional>
#include <type_traits>
#include <variant>
#include "source/src/util/util_hash.hpp"
namespace dxmt { struct InputLayout {}; struct Shader {}; }
using ManagedInputLayout = dxmt::InputLayout *;
using ManagedShader = dxmt::Shader *;
enum SM50_INDEX_BUFFER_FORAMT {
  SM50_INDEX_BUFFER_FORMAT_NONE = 0,
  SM50_INDEX_BUFFER_FORMAT_UINT16 = 1,
  SM50_INDEX_BUFFER_FORMAT_UINT32 = 2,
};
namespace dxmt {
struct ShaderVariantVertex {
  using this_type = ShaderVariantVertex;
  ManagedInputLayout input_layout_handle;
  uint32_t gs_passthrough;
  bool rasterization_disabled;
  bool operator==(const this_type &rhs) const {
    return input_layout_handle == rhs.input_layout_handle &&
           gs_passthrough == rhs.gs_passthrough &&
           rasterization_disabled == rhs.rasterization_disabled;
  }
};

struct ShaderVariantPixel {
  using this_type = ShaderVariantPixel;
  uint32_t sample_mask;
  bool dual_source_blending;
  bool disable_depth_output;
  uint32_t unorm_output_reg_mask;
  bool operator==(const this_type &rhs) const {
    return sample_mask == rhs.sample_mask &&
           dual_source_blending == rhs.dual_source_blending &&
           disable_depth_output == rhs.disable_depth_output &&
           unorm_output_reg_mask == rhs.unorm_output_reg_mask;
  }
};

struct ShaderVariantTessellationVertexHull {
  using this_type = ShaderVariantTessellationVertexHull;
  ManagedInputLayout input_layout_handle;
  ManagedShader vertex_shader_handle;
  SM50_INDEX_BUFFER_FORAMT index_buffer_format;
  uint32_t max_potential_tess_factor;
  bool operator==(const this_type &rhs) const {
    return input_layout_handle == rhs.input_layout_handle &&
           vertex_shader_handle == rhs.vertex_shader_handle &&
           index_buffer_format == rhs.index_buffer_format &&
           max_potential_tess_factor == rhs.max_potential_tess_factor;
  }
};

struct ShaderVariantTessellationDomain {
  using this_type = ShaderVariantTessellationDomain;
  ManagedShader hull_shader_handle;
  uint32_t gs_passthrough;
  uint32_t max_potential_tess_factor;
  bool rasterization_disabled;
  bool operator==(const this_type &rhs) const {
    return hull_shader_handle == rhs.hull_shader_handle &&
           gs_passthrough == rhs.gs_passthrough &&
           max_potential_tess_factor == rhs.max_potential_tess_factor &&
           rasterization_disabled == rhs.rasterization_disabled;
  }
};

struct ShaderVariantGeometryVertex {
  using this_type = ShaderVariantGeometryVertex;
  ManagedInputLayout input_layout_handle;
  ManagedShader geometry_shader_handle;
  SM50_INDEX_BUFFER_FORAMT index_buffer_format;
  bool strip_topology;
  bool operator==(const this_type &rhs) const {
    return input_layout_handle == rhs.input_layout_handle &&
           geometry_shader_handle == rhs.geometry_shader_handle &&
           index_buffer_format == rhs.index_buffer_format &&
           strip_topology == rhs.strip_topology;
  }
};

struct ShaderVariantGeometry {
  using this_type = ShaderVariantGeometry;
  ManagedShader vertex_shader_handle;
  bool strip_topology;
  bool operator==(const this_type &rhs) const {
    return vertex_shader_handle == rhs.vertex_shader_handle &&
           strip_topology == rhs.strip_topology;
  }
};

struct ShaderVariantDefault {
  using this_type = ShaderVariantDefault;
  bool operator==(const this_type &rhs) const { return true; }
};

struct ShaderVariantVertexStreamOutput {
  using this_type = ShaderVariantVertexStreamOutput;
  ManagedInputLayout input_layout_handle;
  uint64_t stream_output_layout_handle;
  bool operator==(const this_type &rhs) const {
    return input_layout_handle == rhs.input_layout_handle &&
           stream_output_layout_handle == rhs.stream_output_layout_handle;
  }
};

using ShaderVariant =
    std::variant<ShaderVariantDefault, ShaderVariantVertex, ShaderVariantPixel,
                 ShaderVariantTessellationVertexHull,
                 ShaderVariantTessellationDomain, ShaderVariantVertexStreamOutput,
                 ShaderVariantGeometryVertex, ShaderVariantGeometry>;


}
namespace std {
template <> struct hash<dxmt::ShaderVariant> {
  size_t operator()(const dxmt::ShaderVariant &v) const noexcept {
    dxmt::HashState state;
    state.add(v.index());
    // Hash exactly the fields used by each alternative's equality operator.
    // These process-local handles must not be used for persistent cache keys.
    std::visit([&state](const auto &key) {
      using T = std::decay_t<decltype(key)>;
      if constexpr (std::is_same_v<T, dxmt::ShaderVariantVertex>) {
        state.add(reinterpret_cast<size_t>(key.input_layout_handle));
        state.add(key.gs_passthrough);
        state.add(key.rasterization_disabled);
      } else if constexpr (std::is_same_v<T, dxmt::ShaderVariantPixel>) {
        state.add(key.sample_mask);
        state.add(key.dual_source_blending);
        state.add(key.disable_depth_output);
        state.add(key.unorm_output_reg_mask);
      } else if constexpr (std::is_same_v<T, dxmt::ShaderVariantTessellationVertexHull>) {
        state.add(reinterpret_cast<size_t>(key.input_layout_handle));
        state.add(reinterpret_cast<size_t>(key.vertex_shader_handle));
        state.add(key.index_buffer_format);
        state.add(key.max_potential_tess_factor);
      } else if constexpr (std::is_same_v<T, dxmt::ShaderVariantTessellationDomain>) {
        state.add(reinterpret_cast<size_t>(key.hull_shader_handle));
        state.add(key.gs_passthrough);
        state.add(key.max_potential_tess_factor);
        state.add(key.rasterization_disabled);
      } else if constexpr (std::is_same_v<T, dxmt::ShaderVariantVertexStreamOutput>) {
        state.add(reinterpret_cast<size_t>(key.input_layout_handle));
        state.add(key.stream_output_layout_handle);
      } else if constexpr (std::is_same_v<T, dxmt::ShaderVariantGeometryVertex>) {
        state.add(reinterpret_cast<size_t>(key.input_layout_handle));
        state.add(reinterpret_cast<size_t>(key.geometry_shader_handle));
        state.add(key.index_buffer_format);
        state.add(key.strip_topology);
      } else if constexpr (std::is_same_v<T, dxmt::ShaderVariantGeometry>) {
        state.add(reinterpret_cast<size_t>(key.vertex_shader_handle));
        state.add(key.strip_topology);
      }
    }, v);
    return state;
  };
};
}
struct BaselineHash {
  size_t operator()(const dxmt::ShaderVariant &v) const noexcept {
    return v.index(); // FIXME:
  };
};