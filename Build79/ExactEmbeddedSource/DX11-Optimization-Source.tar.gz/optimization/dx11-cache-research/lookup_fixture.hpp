#pragma once
#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>
#define ERR(...) ((void)0)
using sm50_error_t = int;
using sm50_shader_t = unsigned;
using MTL_SHADER_REFLECTION = unsigned;
struct Sha1HashState {
  static uint64_t compute(const void *p, uint32_t length) {
    assert_length(length); return *static_cast<const unsigned *>(p);
  }
  static void assert_length(uint32_t length) { if (length != sizeof(unsigned)) std::abort(); }
};
inline std::atomic<size_t> live_mock_shaders{0};
struct CachedSM50Shader {
  template<typename Cache>
  CachedSM50Shader(Cache *, unsigned, uint64_t, unsigned &) { ++live_mock_shaders; }
  ~CachedSM50Shader() { --live_mock_shaders; }
};
struct CountHash {
  std::atomic<size_t> *calls;
  size_t operator()(uint64_t key) const noexcept { calls->fetch_add(1); return key; }
};
struct MockCache {
  std::atomic<size_t> hash_calls{0}, initialized{0};
  std::function<void()> before_init;
  std::shared_mutex mutex_shares;
  std::unordered_map<uint64_t, std::unique_ptr<CachedSM50Shader>, CountHash> shaders_;
  MockCache() : shaders_(0, CountHash{&hash_calls}) {}
  int SM50Initialize(const void *p, uint32_t, unsigned *sm50, unsigned *reflection, int *error) {
    ++initialized;
    if (before_init) before_init();
    *sm50 = *static_cast<const unsigned *>(p); *reflection = 0; *error = 0;
    return *sm50 == 0;
  }
  static void SM50FreeError(int) {}
};
struct BaselineCache : MockCache {
CachedSM50Shader *CreateShader(const void *pBytecode,
                                 uint32_t BytecodeLength) {
    auto sha1 = Sha1HashState::compute(pBytecode, BytecodeLength);
    {
      std::shared_lock<std::shared_mutex> lock(mutex_shares);
      auto result = shaders_.find(sha1);
      if (result != shaders_.end()) {
        return shaders_.at(sha1).get();
      }
    }
    sm50_error_t err;
    sm50_shader_t sm50;
    MTL_SHADER_REFLECTION reflection;
    if (SM50Initialize(pBytecode, BytecodeLength, &sm50, &reflection, &err)) {
      ERR("Failed to initialize shader: ", SM50GetErrorMessageString(err));
      SM50FreeError(err);
      return nullptr;
    }
    auto shader = std::make_unique<CachedSM50Shader>(this, sm50, sha1, reflection);
    {
      std::unique_lock<std::shared_mutex> lock(mutex_shares);
      auto result = shaders_.find(sha1);
      if (result != shaders_.end()) {
        return shaders_.at(sha1).get();
      }
#ifdef DXMT_DEBUG
      shader->bytecode = malloc(BytecodeLength);
      shader->bytecode_length = BytecodeLength;
      memcpy(shader->bytecode, pBytecode, BytecodeLength);
#endif
      return shaders_.emplace(sha1, std::move(shader)).first->second.get();
    }
  }
};
struct CandidateCache : MockCache {
CachedSM50Shader *CreateShader(const void *pBytecode,
                                 uint32_t BytecodeLength) {
    auto sha1 = Sha1HashState::compute(pBytecode, BytecodeLength);
    {
      std::shared_lock<std::shared_mutex> lock(mutex_shares);
      auto result = shaders_.find(sha1);
      if (result != shaders_.end()) {
        return result->second.get();
      }
    }
    sm50_error_t err;
    sm50_shader_t sm50;
    MTL_SHADER_REFLECTION reflection;
    if (SM50Initialize(pBytecode, BytecodeLength, &sm50, &reflection, &err)) {
      ERR("Failed to initialize shader: ", SM50GetErrorMessageString(err));
      SM50FreeError(err);
      return nullptr;
    }
    auto shader = std::make_unique<CachedSM50Shader>(this, sm50, sha1, reflection);
    {
      std::unique_lock<std::shared_mutex> lock(mutex_shares);
      auto result = shaders_.find(sha1);
      if (result != shaders_.end()) {
        return result->second.get();
      }
#ifdef DXMT_DEBUG
      shader->bytecode = malloc(BytecodeLength);
      shader->bytecode_length = BytecodeLength;
      memcpy(shader->bytecode, pBytecode, BytecodeLength);
#endif
      return shaders_.emplace(sha1, std::move(shader)).first->second.get();
    }
  }
};
