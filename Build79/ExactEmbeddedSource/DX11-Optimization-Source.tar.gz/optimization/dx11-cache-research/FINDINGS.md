# DX11 cache / CPU submission handoff

One independently host-tested patch exported. Full renderer compilation,
Madeira build/integration and physical GPU testing remain PENDING; main owns CI.
Subagents were explicitly requested but no subagent tool exists in this session.
No substitute tasks were created. All work here was performed by this agent.

## Provenance and scope

Base: DXMT `b4b89f0a5a1752da3982a7b6c5575506024bf253`.
Read the supplied `../dx11-opt/source`; the two affected files match both
`git show <base>:<path>` from `/tmp/madeira-release-dxmt` and our baseline copies
byte-for-byte. Candidate is a SPARSE copied source, not a complete renderer tree.
It does not contain or duplicate the dynamic-buffer/census patch.
The supplied source's whole-file-list SHA256 fingerprint was identical before
and after: `8684cb9beda7ecd1de7569ec24b1a2aa8f432dfa4d6e9166cfcb5f858eaa6fbf`.
No other project, game file/setting, IPA, external pipeline or cache was modified.

## Ranked findings

1. **Implemented: shader-variant collision chains.**
   `src/d3d11/d3d11_shader.hpp` hashes only `v.index()`. Every same-alternative
   key therefore collides, irrespective of its equality fields; enlarging the
   bucket array cannot split these identical hashes. Candidate combines the
   alternative index and all 23 active equality fields using existing HashState.
   Never hashes padding or dereferences handles. Equal keys must have equal
   hashes under the [C++ unordered-container requirements](https://eel.is/c++draft/unord.req#5).
   Guaranteed original collisions and fewer host predicate calls are proven;
   game cardinalities and net renderer CPU benefit are not measured.

2. **Implemented in the same patch: redundant shader lookup.**
   `PipelineCache::CreateShader` uses `find` then `at` on both the shared-lock
   hit and exclusive-lock race-winner hit. Reuse the found iterator without
   changing locks, initialization or loser destruction. Host warm-hit hashing
   calls fall from two to one. This affects shader creation, not every draw.

3. **Unimplemented, theory: graphics-key collision refinement.**
   `d3d11_pipeline.hpp` intentionally omits blend state from hashing while
   equality semantically compares it, and omits RasterizationEnabled from
   hashing although equality includes it. Distinct blend-heavy PSOs may cluster.
   Do NOT add a blend pointer hash: different pointers can compare equal.
   A canonical semantic key requires its own correctness tests and profile.

4. **Unimplemented, documented mechanism; target benefit theoretical:
   public Metal binary archives.** AIR persistence already exists:
   `d3d11_shader.cpp` reads/writes variant bitcode and creates libraries/functions.
   PSO compilation still happens separately in `d3d11_pipeline*.cpp`.
   Winemetal exposes archive lookup/serialization, but those D3D11 callers leave
   archive fields at their default null/zero values. Apple's
   [binary-archive workflow](https://developer.apple.com/videos/play/wwdc2020/10615/)
   can avoid backend compilation on hits; AIR persistence alone is not that.
   A future opt-in experiment would need bounded collection, normal compilation
   fallback, GPU/OS/backend identity and invalidation, synchronized archive
   ownership/serialization, corrupted-file handling, and remote/iOS backend
   validation. Never enable fail-on-miss in gameplay or any private-API/protection
   bypass. No archive patch is included in this handoff.

5. **Unimplemented, theory: reduce persistence/scheduler contention.**
   ShaderCache serializes reader and writer access separately; SQLite uses
   NOMUTEX connections and reusable statements. Those locks cannot simply be
   removed: [SQLite's threading rules](https://www.sqlite.org/threadsafe.html)
   require avoiding concurrent connection/statement use in multi-thread mode.
   Per-worker readers or bounded writer batching require measuring contention,
   defining durability/shutdown behavior, and limiting connection/queue memory.
   Scheduler also locks worker/dependency queues, grows workers to twice reported
   hardware concurrency, and notifies all after completions. No contention or
   oversubscription profile here justifies changing that policy.

6. **Unimplemented, theory: submission batching.** The current renderer already
   uses dirty binding masks, redundant shader-bind rejection, a pipeline-ready
   fast path, asynchronous encoding and completion-driven reclamation.
   [Apple's submission guidance](https://developer.apple.com/library/archive/documentation/3DDrawing/Conceptual/MTLBestPracticesGuide/CommandBuffers.html)
   balances fewer buffers against GPU starvation; it is not a mandate to remove
   Flush/query/Present/event boundaries. Batching or state elision requires a
   trace showing excess commits/commands, preserved ordering, and unchanged
   resource/fence semantics. No broad submission patch is justified yet.

## Verification and risks

Run `python3 verify.py` from this directory. It extracts the actual production
variant declarations/equality/hash and old/new CreateShader bodies. Only platform
types, compiler initialization and shader owners are mocked; real HashState and
host unordered_map implementations execute. Clang 22.1.8 and GCC 16.2.1 optimized
builds pass; Clang ASan/UBSan also passes. Both host compilers use libstdc++, not
the target's libc++; matching target compilation remains required.

Coverage: eight alternatives, all 23 one-field perturbations, equal values with
different padding, null handles, 1/4/16/64/256/1024 generated variants per kind,
duplicate insertion, retrieval, rehash, erase, initialization failure and forced
two-thread cold miss. Old/new racing callers receive the same single owned shader;
explicit mock live-owner counts return to zero. LSan is disabled for sandbox
constraints; this is not a full renderer leak audit or thread-sanitizer audit.
Forward patch checks against both pinned source and the supplied allocator/census
candidate, plus exact reverse check against this candidate, all pass.

Example: 257 pixel keys in a single-stage host map require 33,153 equality calls
for one complete hit sweep before, 391 after (all three test runs). This proves
less synthetic collision work, NOT a timing/FPS speedup. Tiny maps may see a net
regression from extra hash arithmetic or bucket coincidences; pointer-dependent
counts vary across processes. Actual per-shader cardinalities must be profiled.

Risks: future equality-field changes must update hash/tests together; bucket
iteration order changes (cache code does not use that order). Process-local
pointers remain process-local; persistent SHA1 variant keys and cache version 15
are unchanged. No added allocations, cache limits, eviction, scheduling policy,
shader quality changes, GPU fences or resource-lifetime changes.

## Renderer-only cached CI integration / rollback

Apply **only** `dx11-cache.patch` to main's disposable pinned renderer checkout,
after verifying manifest before-hashes for the two files. It is disjoint from
the three-file allocator/census patch and can be applied before or after it.
First run `git apply --check <absolute-patch-path>`, then `git apply` there.
Do not copy this sparse source over a whole project or integrate test fixtures.

Keep the prepared matching toolchain/Wine/Winemetal caches and existing pipeline
configuration; rebuild affected renderer units/DLL for every currently shipped
architecture (including ARM64EC and aarch64 as applicable). Header dependencies
must invalidate old objects; do not reuse a stale cached d3d11.dll. This patch
requires no AIR backend or cache-database rebuild. Verify PE architecture/imports,
changed-file allowlist, and integrate through main's existing build process.

Local full build was not attempted: Linux has no xcrun/Apple Metal SDK, the
snapshot has no prepared toolchains, and the native DirectX submodule directory
is empty. Meson and host compilers being present do not resolve those dependencies.
No Madeira/IPA output has been built or altered by this work.

A/B allocator-only versus allocator-plus-cache patch with identical scenes,
settings and cold/warm conditions. Check CPU/GPU frame times, p95/p99, actual
variant cardinalities, repeated scene transitions, image correctness and memory.
GPU evidence: **none**. Accept only if CI and device checks pass without a
measurable regression. No runtime knob is added to this small semantic patch;
gate the experiment through separate build artifacts. Roll back with the patch's
reverse check/application in that disposable checkout, rebuild only the renderer,
or select the allocator-only artifact. No game/cache deletion is needed.

## Exact deliverables

Only two copied renderer files changed from base:

- `source/src/d3d11/d3d11_shader.hpp`
- `source/src/d3d11/d3d11_pipeline_cache.cpp`

`manifest.json` records their full before/after SHA256 hashes, exact base, compiler
versions and test outputs. Patch SHA256:
`a548a60bcb2e6c7e2807ff24f14f7cf4f50e1798a40f0b705ee563d34c8681d8`.
Other local artifacts: baseline copies of those two files; unchanged
`source/src/util/util_hash.hpp`; `verify.py`; `test_cache.cpp`; generated
`variant_fixture.hpp` and `lookup_fixture.hpp`; and three `test-cache-*` host
executables. None is a replacement renderer DLL.
