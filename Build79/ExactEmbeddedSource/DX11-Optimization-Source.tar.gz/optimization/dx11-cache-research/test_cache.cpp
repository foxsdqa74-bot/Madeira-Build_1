#include "variant_fixture.hpp"
#include "lookup_fixture.hpp"
#include <array>
#include <atomic>
#include <cassert>
#include <chrono>
#include <iostream>
#include <mutex>
#include <random>
#include <shared_mutex>
#include <thread>
#include <unordered_map>
#include <vector>

using namespace dxmt;
static size_t field_cases = 0;
template <typename T, typename M>
void field_test(T seed, M T::*member, M changed) {
  T other = seed;
  other.*member = changed;
  ShaderVariant a = seed, b = other;
  assert(a != b);
  assert(BaselineHash{}(a) == BaselineHash{}(b));
  assert(std::hash<ShaderVariant>{}(a) != std::hash<ShaderVariant>{}(b));
  ++field_cases;
}
template <typename T, typename... M>
void padding_test(T seed, M... members) {
  T other;
  std::memset(&other, 0xa5, sizeof(other));
  ((other.*members = seed.*members), ...);
  ShaderVariant a = seed, b = other;
  assert(a == b);
  assert(std::hash<ShaderVariant>{}(a) == std::hash<ShaderVariant>{}(b));
}

void fields() {
  InputLayout layouts[2]; Shader shaders[2];
  using V = ShaderVariantVertex;
  V v{&layouts[0], 0, false};
  field_test(v, &V::input_layout_handle, &layouts[1]);
  field_test(v, &V::gs_passthrough, uint32_t(1));
  field_test(v, &V::rasterization_disabled, true);
  padding_test(v, &V::input_layout_handle, &V::gs_passthrough, &V::rasterization_disabled);
  using P = ShaderVariantPixel;
  P p{0, false, false, 0};
  field_test(p, &P::sample_mask, uint32_t(1));
  field_test(p, &P::dual_source_blending, true);
  field_test(p, &P::disable_depth_output, true);
  field_test(p, &P::unorm_output_reg_mask, uint32_t(1));
  padding_test(p, &P::sample_mask, &P::dual_source_blending, &P::disable_depth_output, &P::unorm_output_reg_mask);
  using H = ShaderVariantTessellationVertexHull;
  H h{&layouts[0], &shaders[0], SM50_INDEX_BUFFER_FORMAT_NONE, 0};
  field_test(h, &H::input_layout_handle, &layouts[1]);
  field_test(h, &H::vertex_shader_handle, &shaders[1]);
  field_test(h, &H::index_buffer_format, SM50_INDEX_BUFFER_FORMAT_UINT16);
  field_test(h, &H::max_potential_tess_factor, uint32_t(1));
  padding_test(h, &H::input_layout_handle, &H::vertex_shader_handle, &H::index_buffer_format, &H::max_potential_tess_factor);
  using D = ShaderVariantTessellationDomain;
  D d{&shaders[0], 0, 0, false};
  field_test(d, &D::hull_shader_handle, &shaders[1]);
  field_test(d, &D::gs_passthrough, uint32_t(1));
  field_test(d, &D::max_potential_tess_factor, uint32_t(1));
  field_test(d, &D::rasterization_disabled, true);
  padding_test(d, &D::hull_shader_handle, &D::gs_passthrough, &D::max_potential_tess_factor, &D::rasterization_disabled);
  using S = ShaderVariantVertexStreamOutput;
  S s{&layouts[0], 0};
  field_test(s, &S::input_layout_handle, &layouts[1]);
  field_test(s, &S::stream_output_layout_handle, uint64_t(1));
  padding_test(s, &S::input_layout_handle, &S::stream_output_layout_handle);
  using G = ShaderVariantGeometryVertex;
  G g{&layouts[0], &shaders[0], SM50_INDEX_BUFFER_FORMAT_NONE, false};
  field_test(g, &G::input_layout_handle, &layouts[1]);
  field_test(g, &G::geometry_shader_handle, &shaders[1]);
  field_test(g, &G::index_buffer_format, SM50_INDEX_BUFFER_FORMAT_UINT16);
  field_test(g, &G::strip_topology, true);
  padding_test(g, &G::input_layout_handle, &G::geometry_shader_handle, &G::index_buffer_format, &G::strip_topology);
  using F = ShaderVariantGeometry;
  F f{&shaders[0], false};
  field_test(f, &F::vertex_shader_handle, &shaders[1]);
  field_test(f, &F::strip_topology, true);
  padding_test(f, &F::vertex_shader_handle, &F::strip_topology);
  assert(std::hash<ShaderVariant>{}(ShaderVariantDefault{}) == std::hash<ShaderVariant>{}(ShaderVariantDefault{}));
  assert(field_cases == 23);
}

struct CountEqual {
  size_t *count;
  bool operator()(const ShaderVariant &a, const ShaderVariant &b) const {
    ++*count; return a == b;
  }
};
template <typename Hash>
size_t map_test(const std::vector<ShaderVariant> &keys) {
  size_t comparisons = 0;
  std::unordered_map<ShaderVariant, size_t, Hash, CountEqual> map(0, Hash{}, CountEqual{&comparisons});
  for (size_t i = 0; i < keys.size(); ++i) {
    auto [it, inserted] = map.emplace(keys[i], i);
    assert(inserted && it->second == i);
  }
  for (size_t i = 0; i < keys.size(); ++i) {
    auto [it, inserted] = map.emplace(keys[i], 999999);
    assert(!inserted && it->second == i);
  }
  comparisons = 0;
  for (size_t i = 0; i < keys.size(); ++i) {
    assert(map.at(keys[i]) == i);
    assert(Hash{}(keys[i]) == Hash{}(ShaderVariant(keys[i])));
  }
  const size_t hit_comparisons = comparisons;
  map.rehash(map.bucket_count() * 2);
  for (size_t i = 0; i < keys.size(); ++i) assert(map.at(keys[i]) == i);
  for (const auto &key : keys) assert(map.erase(key) == 1);
  assert(map.empty());
  return hit_comparisons;
}

std::vector<ShaderVariant> keys(size_t n, InputLayout *layouts, Shader *shaders) {
  std::mt19937 random(314159);
  std::vector<ShaderVariant> result{
    ShaderVariantDefault{}, ShaderVariantVertex{nullptr, 0, false},
    ShaderVariantPixel{0, false, false, 0},
    ShaderVariantTessellationVertexHull{nullptr, nullptr, SM50_INDEX_BUFFER_FORMAT_NONE, 0},
    ShaderVariantTessellationDomain{nullptr, 0, 0, false},
    ShaderVariantVertexStreamOutput{nullptr, 0},
    ShaderVariantGeometryVertex{nullptr, nullptr, SM50_INDEX_BUFFER_FORMAT_NONE, false},
    ShaderVariantGeometry{nullptr, false}};
  for (size_t i = 0; i < n; ++i) {
    uint32_t r = random();
    const auto index = SM50_INDEX_BUFFER_FORAMT(i % 3);
    result.emplace_back(ShaderVariantVertex{&layouts[i], r, bool(i & 1)});
    result.emplace_back(ShaderVariantPixel{uint32_t(i), bool(i & 1), bool(i & 2), r});
    result.emplace_back(ShaderVariantTessellationVertexHull{&layouts[i], &shaders[i], index, r});
    result.emplace_back(ShaderVariantTessellationDomain{&shaders[i], r, uint32_t(i), bool(i & 1)});
    result.emplace_back(ShaderVariantVertexStreamOutput{&layouts[i], uint64_t(r) << 32 | i});
    result.emplace_back(ShaderVariantGeometryVertex{&layouts[i], &shaders[i], index, bool(i & 1)});
    result.emplace_back(ShaderVariantGeometry{&shaders[i], bool(i & 1)});
  }
  return result;
}

template <typename Cache>
void lookup_test(const char *label) {
  Cache cache;
  const unsigned bytecode = 42;
  auto *first = cache.CreateShader(&bytecode, sizeof(bytecode));
  assert(first && cache.shaders_.size() == 1 && cache.initialized == 1);
  cache.hash_calls = 0;
  assert(cache.CreateShader(&bytecode, sizeof(bytecode)) == first);
  std::cout << label << " warm_hit_hash_calls=" << cache.hash_calls << '\n';
  assert(cache.hash_calls == (std::is_same_v<Cache, CandidateCache> ? 1 : 2));
  const unsigned invalid = 0;
  assert(cache.CreateShader(&invalid, sizeof(invalid)) == nullptr);
  assert(cache.shaders_.size() == 1);

  Cache racing;
  std::atomic<int> entered = 0;
  racing.before_init = [&] {
    entered.fetch_add(1);
    while (entered.load() < 2) std::this_thread::yield();
  };
  CachedSM50Shader *a = nullptr, *b = nullptr;
  std::thread t1([&] { a = racing.CreateShader(&bytecode, sizeof(bytecode)); });
  std::thread t2([&] { b = racing.CreateShader(&bytecode, sizeof(bytecode)); });
  t1.join(); t2.join();
  assert(a && a == b && racing.shaders_.size() == 1 && racing.initialized == 2);
  std::cout << label << " cold_race_single_owner=PASS\n";
}

int main() {
  fields();
  InputLayout layouts[1024]; Shader shaders[1024];
  for (size_t n : {size_t(1), size_t(4), size_t(16), size_t(64), size_t(256), size_t(1024)}) {
    auto samples = keys(n, layouts, shaders);
    size_t old_count = map_test<BaselineHash>(samples);
    size_t new_count = map_test<std::hash<ShaderVariant>>(samples);
    if (n >= 16) assert(new_count < old_count);
    std::cout << "variants_per_kind=" << n << " keys=" << samples.size()
              << " hit_equalities=" << old_count << "->" << new_count << '\n';
  }
  // A real shader's cache generally holds one stage, not all alternatives.
  const auto stage_samples = keys(256, layouts, shaders);
  for (size_t kind = 0; kind < 8; ++kind) {
    std::vector<ShaderVariant> single_stage;
    for (const auto &key : stage_samples) if (key.index() == kind) single_stage.push_back(key);
    const size_t old_count = map_test<BaselineHash>(single_stage);
    const size_t new_count = map_test<std::hash<ShaderVariant>>(single_stage);
    if (kind) assert(new_count < old_count);
    std::cout << "single_kind=" << kind << " keys=" << single_stage.size()
              << " hit_equalities=" << old_count << "->" << new_count << '\n';
  }
  lookup_test<BaselineCache>("baseline");
  assert(live_mock_shaders == 0);
  lookup_test<CandidateCache>("candidate");
  assert(live_mock_shaders == 0);
  std::cout << "PASS: all 8 alternatives, 23 fields, padding, duplicate inserts, rehash, erase, warm hits, initialization failure, cold race\n";
}
