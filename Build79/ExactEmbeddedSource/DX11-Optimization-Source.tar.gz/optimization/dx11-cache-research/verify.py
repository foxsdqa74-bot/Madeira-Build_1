"""Host tests of extracted production code; export a pinned two-file patch.

Writes only below this script's directory. Platform/Metal boundaries are mocked.
"""
from pathlib import Path
import difflib
import hashlib
import json
import os
import re
import subprocess

HERE = Path(__file__).resolve().parent
PINNED = Path('/tmp/madeira-release-dxmt')
SUPPLIED = HERE.parent / 'dx11-opt/source'
REV = 'b4b89f0a5a1752da3982a7b6c5575506024bf253'
FILES = ('src/d3d11/d3d11_shader.hpp', 'src/d3d11/d3d11_pipeline_cache.cpp')

def run(args, **kw):
    return subprocess.run(args, check=True, text=True, capture_output=True, **kw).stdout

def body(text, marker):
    start = text.index(marker)
    opening = text.index('{', start)
    level = 1
    end = opening + 1
    while level:
        level += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[start:end]

def sha(data):
    return hashlib.sha256(data).hexdigest()

manifest = {'base_commit': REV, 'files': {}, 'full_renderer_compilation': 'pending',
            'subagents': 'unavailable in this session', 'gpu_tests': 'not run'}
parts = []
for relative in FILES:
    before = subprocess.check_output(['git', '-C', str(PINNED), 'show', REV + ':' + relative])
    assert (HERE / 'baseline' / relative).read_bytes() == before
    after = (HERE / 'source' / relative).read_bytes()
    assert (SUPPLIED / relative).read_bytes() in (before, after)
    manifest['files'][relative] = {'before_sha256': sha(before), 'after_sha256': sha(after)}
    for line in difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                     fromfile='a/' + relative, tofile='b/' + relative):
        parts.append(line if line.endswith('\n') else line + '\n\\ No newline at end of file\n')
assert (HERE / 'source/src/util/util_hash.hpp').read_bytes() == subprocess.check_output(
    ['git', '-C', str(PINNED), 'show', REV + ':src/util/util_hash.hpp'])

candidate = (HERE / 'source' / FILES[0]).read_text()
baseline = (HERE / 'baseline' / FILES[0]).read_text()
decls = candidate[candidate.index('struct ShaderVariantVertex {'):candidate.index('class ThreadpoolWork {')]
assert decls == baseline[baseline.index('struct ShaderVariantVertex {'):baseline.index('class ThreadpoolWork {')]
enum = body((SUPPLIED / 'src/airconv/airconv_public.h').read_text(), 'enum SM50_INDEX_BUFFER_FORAMT') + ';'
hash_body = body(candidate, 'template <> struct hash<dxmt::ShaderVariant>') + ';'
old_body = body(baseline, 'template <> struct hash<dxmt::ShaderVariant>')
old_body = old_body.replace('template <> struct hash<dxmt::ShaderVariant>', 'struct BaselineHash') + ';'
fixture = '''#pragma once
#include <cstdint>
#include <cstring>
#include <functional>
#include <type_traits>
#include <variant>
#include "source/src/util/util_hash.hpp"
namespace dxmt { struct InputLayout {}; struct Shader {}; }
using ManagedInputLayout = dxmt::InputLayout *;
using ManagedShader = dxmt::Shader *;
'''
fixture += enum + '\nnamespace dxmt {\n' + decls + '\n}\nnamespace std {\n' + hash_body + '\n}\n' + old_body
(HERE / 'variant_fixture.hpp').write_text(fixture)

lookup = '''#pragma once
#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>
#define ERR(...) ((void)0)
using sm50_error_t = int;
using sm50_shader_t = unsigned;
using MTL_SHADER_REFLECTION = unsigned;
struct Sha1HashState {
  static uint64_t compute(const void *p, uint32_t length) {
    assert_length(length); return *static_cast<const unsigned *>(p);
  }
  static void assert_length(uint32_t length) { if (length != sizeof(unsigned)) std::abort(); }
};
inline std::atomic<size_t> live_mock_shaders{0};
struct CachedSM50Shader {
  template<typename Cache>
  CachedSM50Shader(Cache *, unsigned, uint64_t, unsigned &) { ++live_mock_shaders; }
  ~CachedSM50Shader() { --live_mock_shaders; }
};
struct CountHash {
  std::atomic<size_t> *calls;
  size_t operator()(uint64_t key) const noexcept { calls->fetch_add(1); return key; }
};
struct MockCache {
  std::atomic<size_t> hash_calls{0}, initialized{0};
  std::function<void()> before_init;
  std::shared_mutex mutex_shares;
  std::unordered_map<uint64_t, std::unique_ptr<CachedSM50Shader>, CountHash> shaders_;
  MockCache() : shaders_(0, CountHash{&hash_calls}) {}
  int SM50Initialize(const void *p, uint32_t, unsigned *sm50, unsigned *reflection, int *error) {
    ++initialized;
    if (before_init) before_init();
    *sm50 = *static_cast<const unsigned *>(p); *reflection = 0; *error = 0;
    return *sm50 == 0;
  }
  static void SM50FreeError(int) {}
};
'''
for name, tree in [('BaselineCache', 'baseline'), ('CandidateCache', 'source')]:
    function = body((HERE / tree / FILES[1]).read_text(), 'CachedSM50Shader *CreateShader(')
    lookup += 'struct ' + name + ' : MockCache {\n' + function + '\n};\n'
(HERE / 'lookup_fixture.hpp').write_text(lookup)

results = []
env = dict(os.environ, TMPDIR=str(HERE))
for compiler, flags, suffix in [
    ('clang++', ['-O2'], 'clang'),
    ('g++', ['-O2'], 'gcc'),
    ('clang++', ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'], 'sanitized')]:
    binary = HERE / ('test-cache-' + suffix)
    command = [compiler, '-std=c++20', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter', '-pthread', *flags,
               str(HERE / 'test_cache.cpp'), '-o', str(binary)]
    compile_result = subprocess.run(command, text=True, capture_output=True, env=env)
    if compile_result.returncode:
        print(compile_result.stderr)
        compile_result.check_returncode()
    test_env = dict(env, ASAN_OPTIONS='detect_leaks=0') if suffix == 'sanitized' else env
    output = run([str(binary)], env=test_env)
    results.append({'compiler': run([compiler, '--version']).splitlines()[0],
                    'flags': flags, 'stdout': output})
    print(suffix + ':\n' + output)

patch = HERE / 'dx11-cache.patch'
patch.write_text(''.join(parts))
run(['git', '-C', str(PINNED), 'apply', '--check', str(patch)])
run(['git', '-C', str(HERE / 'source'), 'apply', '--reverse', '--check', str(patch)])
manifest['patch_sha256'] = sha(patch.read_bytes())
manifest['tests'] = results
manifest['sanitizer_limit'] = 'ASan/UBSan pass; LSan disabled for sandbox; no Metal/PE integration validation'
(HERE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('PASS: pinned provenance, forward patch check, exact reverse check')
print('PATCH SHA256:', manifest['patch_sha256'])
