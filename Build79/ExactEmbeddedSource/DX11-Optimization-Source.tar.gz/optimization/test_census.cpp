#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <utility>
static unsigned log_calls,metal_queries;
namespace WMT { struct Device { uint64_t currentAllocatedSize() const { metal_queries++; return 0; } }; }
#include "census-host.inc"
namespace dxmt::env {
std::string getEnvVar(const char *name) { auto p=std::getenv(name); return p?p:""; }
}
template<typename... T> static void testLog(T&&...) { log_calls++; }
#define ERR(...) testLog(__VA_ARGS__)
#include "census-code-host.inc"
int main(int argc,char **argv) {
    assert(argc==2);
    bool enabled=argv[1][0]=='1';
    using namespace dxmt;
    assert(dxmt_diagnostics_enabled()==enabled);
    mem_census_set_device(WMT::Device{});
    mem_census_add(MEMOWN_BUFFER,128ull<<20);
    mem_census_buffer_detail(4096,0,0,1);
    buf_site_add(1,4096);
    mem_census_report("test"); dyn_census_report(); buf_site_report();
    if(!enabled) {
        assert(!log_calls&&!metal_queries);
        assert(!g_mem_census.live[MEMOWN_BUFFER].load());
        assert(!g_mem_census.buf_bucket_live[BUFB_LE_4K].load());
        assert(!g_buf_sites[0].ra.load());
    } else {
        assert(log_calls&&metal_queries);
        assert(g_mem_census.live[MEMOWN_BUFFER].load()==128ull<<20);
        assert(g_mem_census.buf_bucket_live[BUFB_LE_4K].load()==4096);
        assert(g_buf_sites[0].live_bytes.load()==4096);
    }
    mem_census_sub(MEMOWN_BUFFER,128ull<<20);
    mem_census_buffer_detail(4096,0,0,0);
    buf_site_sub(1,4096);
    assert(!g_mem_census.live[MEMOWN_BUFFER].load());
    assert(!g_buf_sites[0].live_bytes.load());
    // Session setting cannot be changed midway through accounting lifetimes.
    setenv("DXMT_DIAGNOSTICS",enabled?"0":"1",1);
    assert(dxmt_diagnostics_enabled()==enabled);
    std::puts("PASS: real census module, session opt-in, disabled accounting/reports/Metal queries, enabled accounting and paired refunds");
}
