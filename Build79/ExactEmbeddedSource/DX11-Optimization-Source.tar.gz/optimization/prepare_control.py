"""Generate pinned CI controls/import definitions, never upload game data."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
OUT=HERE/'control/.github/dx11-opt'
SOURCE=HERE.parent/'r6-resolution/audio-build74-signed-app'
OUT.mkdir(parents=True,exist_ok=True)
for name in ('dx11-hotpath.patch','patch-manifest.json'):
    (OUT/name).write_bytes((HERE/name).read_bytes())
providers={}
for arch in ('aarch64','arm64ec'):
    dll=SOURCE/(arch+'-windows')/'winemetal.dll'
    inspection=subprocess.check_output(['llvm-readobj','--coff-exports',str(dll)],text=True)
    pairs=re.findall(r'Ordinal: (\d+)\s+Name: ([^\n]+)',inspection)
    assert len(pairs)>100 and len(set(name for _,name in pairs))==len(pairs)
    assert all(re.fullmatch(r'[A-Za-z0-9_?@$#]+',name) for _,name in pairs),'Unexpected export name'
    definition='LIBRARY winemetal.dll\nEXPORTS\n'+''.join(f'  "{name}" @{ordinal}\n' for ordinal,name in pairs)
    (OUT/(arch+'-winemetal.def')).write_text(definition)
    providers[arch]={'dll_sha256':hashlib.sha256(dll.read_bytes()).hexdigest(),'exports':len(pairs),'def_sha256':hashlib.sha256(definition.encode()).hexdigest()}
(OUT/'providers.json').write_text(json.dumps(providers,indent=2)+'\n')
print('Generated optimization controls and import definitions only; original WineMetal is retained')
