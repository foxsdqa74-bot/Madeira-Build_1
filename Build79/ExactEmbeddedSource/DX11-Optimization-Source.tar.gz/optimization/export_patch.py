"""Export a narrowly scoped patch against the release's pinned DXMT source."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
REV='b4b89f0a5a1752da3982a7b6c5575506024bf253'
PATCH=HERE/'dx11-hotpath.patch'
parts=[]
manifest={'base_commit':REV,'files':{}}
files=('src/dxmt/dxmt_dynamic.cpp','src/dxmt/dxmt_mem_census.cpp','src/dxmt/dxmt_mem_census.hpp',
       'src/d3d11/d3d11_shader.hpp','src/d3d11/d3d11_pipeline_cache.cpp',
       'src/dxmt/dxmt_resource_initializer.cpp','src/dxmt/dxmt_resource_initializer.hpp',
       'src/dxmt/dxmt_context.cpp')
for relative in files:
    before=subprocess.check_output(['git','-C','/tmp/madeira-release-dxmt','show',REV+':'+relative])
    after=(HERE/'source'/relative).read_bytes()
    for line in difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative):
        parts.append(line if line.endswith('\n') else line+'\n\\ No newline at end of file\n')
    manifest['files'][relative]={'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(after).hexdigest()}
PATCH.write_text(''.join(parts))
subprocess.run(['git','-C','/tmp/madeira-release-dxmt','apply','--check',str(PATCH)],check=True)
subprocess.run(['git','-C',str(HERE/'source'),'apply','--reverse','--check',str(PATCH)],check=True)
manifest['patch_sha256']=hashlib.sha256(PATCH.read_bytes()).hexdigest()
(HERE/'patch-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: patch applies to pinned clean source and reverses exactly against candidate')
print(PATCH)
