#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <deque>
#include <mutex>
#include <random>
#include <vector>
#include "source/src/util/rc/util_rc_ptr.hpp"
namespace WMT { struct Device; }
#include "census-host.inc"
namespace dxmt {
using mutex=std::mutex;
MemCensus g_mem_census{};
DynStat g_dyn_stats[DYN_CENSUS_SLOTS]{};
std::atomic<uint64_t> g_trim_total_n{0},g_trim_total_bytes{0},g_trim_regret{0};
static bool diagnostic_flag;
static uint64_t reports,live,inc_calls,dec_calls;
bool dxmt_diagnostics_enabled() { return diagnostic_flag; }
void mem_census_report(const char *) { reports++; }
struct BufferAllocation {
    uint64_t id,census_bytes_=4096;
    std::atomic<uint32_t> refs{0};
    explicit BufferAllocation(uint64_t n):id(n) { live++; }
    ~BufferAllocation() { live--; }
    void incRef() { refs.fetch_add(1); inc_calls++; }
    void decRef() { dec_calls++; if(refs.fetch_sub(1)==1)delete this; }
};
struct Buffer {
    uint64_t next=1000000;
    Rc<BufferAllocation> allocate(int,const char *) { return new BufferAllocation(next++); }
};
struct State {
    struct QueueEntry { Rc<BufferAllocation> allocation; uint64_t will_free_at; };
    Buffer *buffer;
    int flags_=0;
    std::deque<QueueEntry> fifo;
    uint32_t census_id_=0;
    mutex mutex_;
    bool trimmed_last_=false;
    explicit State(Buffer *b):buffer(b) {}
};
struct Original:State { using State::State; Rc<BufferAllocation> allocate(uint64_t); };
struct Candidate:State { using State::State; Rc<BufferAllocation> allocate(uint64_t); };
#include "original-allocate.inc"
#include "candidate-allocate.inc"
static void compare(const std::vector<uint64_t>& seq,bool diagnostics,uint32_t slot,std::mt19937_64& rng) {
    Buffer a,b;
    Original old(&a); Candidate next(&b);
    old.census_id_=next.census_id_=slot;
    for(size_t i=0;i<seq.size();i++) {
        old.fifo.push_back({new BufferAllocation(i),seq[i]});
        next.fifo.push_back({new BufferAllocation(i),seq[i]});
    }
    for(unsigned step=0;step<8;step++) {
        uint64_t fence=rng()%200;
        auto first=old.allocate(fence);
        diagnostic_flag=diagnostics; reports=0;
        auto second=next.allocate(fence);
        assert(first->id==second->id);
        assert(old.trimmed_last_==next.trimmed_last_);
        assert(a.next==b.next);
        assert(old.fifo.size()==next.fifo.size());
        for(size_t i=0;i<old.fifo.size();i++) {
            assert(old.fifo[i].allocation->id==next.fifo[i].allocation->id);
            assert(old.fifo[i].will_free_at==next.fifo[i].will_free_at);
        }
        if(!diagnostics)assert(reports==0);
    }
}
template<typename T> static double bench(unsigned n) {
    Buffer b; T state(&b);
    for(unsigned i=0;i<15;i++)state.fifo.push_back({new BufferAllocation(i),0});
    auto start=std::chrono::steady_clock::now();
    for(unsigned i=0;i<n;i++) {
        auto result=state.allocate(0);
        state.fifo.push_back({std::move(result),0});
    }
    return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
}
} // namespace dxmt
int main() {
    using namespace dxmt;
    std::mt19937_64 rng(0xD311);
    unsigned cases=0;
    for(bool diagnostics:{false,true})for(uint32_t slot:{0u,8191u,8192u}) {
        for(size_t n:{0u,1u,15u,63u,64u,65u,66u,128u,1024u}) {
            for(unsigned pattern=0;pattern<3;pattern++) {
                std::vector<uint64_t> seq(n);
                for(size_t i=0;i<n;i++)seq[i]=pattern==0?0:pattern==1?1000:rng()%200;
                compare(seq,diagnostics,slot,rng); assert(!live); cases++;
            }
        }
        for(unsigned trial=0;trial<1000;trial++) {
            std::vector<uint64_t> seq(rng()%256);
            for(auto& v:seq)v=rng()%200;
            compare(seq,diagnostics,slot,rng); assert(!live); cases++;
        }
    }
    // A reuse performs no temporary Rc increment/decrement in the candidate.
    {
        Buffer b; Candidate c(&b); c.fifo.push_back({new BufferAllocation(1),0});
        diagnostic_flag=false; inc_calls=dec_calls=0;
        auto result=c.allocate(0);
        assert(result->id==1&&inc_calls==0&&dec_calls==0&&result->refs==1);
    }
    assert(!live);
    diagnostic_flag=false;
    double before=bench<Original>(200000),after=bench<Candidate>(200000);
    assert(!live);
    std::printf("PASS: %u baseline-equivalence cases (8 operations each), diagnostics on/off, reserve boundaries, nonmonotonic fences, census overflow, zero temporary Rc operations, no live allocations\n",cases);
    std::printf("Host mocked-allocator microbenchmark only: original %.2fms candidate %.2fms; NOT device FPS or GPU evidence\n",before,after);
}
