"""Host checkpoint tests: source/flags/output integrity and atomic concurrent writes."""
from pathlib import Path
from tempfile import TemporaryDirectory
from concurrent.futures import ThreadPoolExecutor
import json
import sys

sys.path.insert(0,str(Path(__file__).parent/'control/.github/dx11-opt'))
from checkpoint import Checkpoint
with TemporaryDirectory(prefix='madeira-checkpoint-') as directory:
    stage=Path(directory)
    identity={'source':'pinned','flags':'-O2','arch':'arm64ec','compiler':'pinned'}
    store=Checkpoint(stage,identity)
    store.initialize()
    (stage/'test.obj').write_bytes(b'object')
    command=['clang','-O2','-c','source.cpp']
    assert not store.done('test.obj',command)
    store.record('test.obj',command)
    assert store.done('test.obj',command)
    assert Checkpoint(stage,identity).done('test.obj',command)
    assert not store.done('test.obj',['clang','-O0','-c','source.cpp'])
    (stage/'test.obj').write_bytes(b'corrupt')
    assert not store.done('test.obj',command)
    (stage/'test.obj').unlink()
    assert not store.done('test.obj',command)
    try:Checkpoint(stage,{**identity,'source':'changed'})
    except RuntimeError:pass
    else:raise AssertionError('mismatched stage was accepted')
    for target in ('../outside.obj','/tmp/outside.obj'):
        try:store.output(target)
        except ValueError:pass
        else:raise AssertionError('unsafe target was accepted')
    def record(index):
        name=f'object-{index}.obj'
        (stage/name).write_bytes(str(index).encode())
        store.record(name,['clang','-O2',name])
    with ThreadPoolExecutor(max_workers=8) as workers:list(workers.map(record,range(128)))
    state=json.loads((stage/'compile-checkpoints.json').read_text())
    assert len(state['entries'])==129
    restored=Checkpoint(stage,identity)
    for index in range(128):assert restored.done(f'object-{index}.obj',['clang','-O2',f'object-{index}.obj'])
print('PASS: checkpoint restore, changed flags/source, corrupt/missing outputs, path guards and 128 concurrent atomic records')
