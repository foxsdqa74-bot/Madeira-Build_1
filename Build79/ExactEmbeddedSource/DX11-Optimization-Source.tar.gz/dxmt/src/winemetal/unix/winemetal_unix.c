#include <stdatomic.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <TargetConditionals.h>
#if TARGET_OS_IOS
#import <UIKit/UIKit.h>
/* iOS lacks CGDirectDisplay: provide minimal stubs for single-display use. */
typedef uint32_t CGDirectDisplayID;
#define kCGNullDirectDisplay ((CGDirectDisplayID)0)
static inline CGDirectDisplayID CGMainDisplayID(void) { return 1; }
#else
#import <Cocoa/Cocoa.h>
#endif
#if !TARGET_OS_IOS
#import <ColorSync/ColorSync.h>
#endif
#import <CoreFoundation/CFRunLoop.h>
#import <Metal/Metal.h>
#import <MetalFX/MetalFX.h>
#import <QuartzCore/QuartzCore.h>
#if TARGET_OS_IOS
#include <objc/message.h>
#include <objc/runtime.h>
#else
#include "objc/objc-runtime.h"
#endif
#if TARGET_OS_IOS
/* iOS SDK omits bootstrap.h but the functions exist in libsystem. */
typedef char name_t[128];
extern kern_return_t bootstrap_look_up(mach_port_t bp, const char *service_name, mach_port_t *sp);
#else
#include <bootstrap.h>
#endif
#include <mach/mach_port.h>
#define WINEMETAL_API
#include "../winemetal_thunks.h"
#include "../airconv_thunks.h"

/* iOS-Madeira 2026-05-22 draw-call telemetry. Defined further down with
 * the present counter; forward-declared here so the draw command cases
 * (above the definition site in source order) can increment them. */
static _Atomic uint64_t g_madeira_draw_calls;
static _Atomic uint64_t g_madeira_draw_calls_at_last_log;

typedef int NTSTATUS;
#define STATUS_SUCCESS 0
#define STATUS_UNSUCCESSFUL 0xC0000001
#define STATUS_NOT_IMPLEMENTED 0xC0000002

/* ml762: remote backend. Included after the NTSTATUS/STATUS_* defines it uses
 * and before the first routed handler; the packer's include sits much further
 * down, past every handler this routes. */
#include "wmt_remote_client.h"

void
execute_on_main(dispatch_block_t block) {
  if ([NSThread isMainThread]) {
    block();
  } else {
    dispatch_sync(dispatch_get_main_queue(), block);
  }
}

static NTSTATUS
_NSObject_retain(NSObject **obj) {
  /* Dispatch by TAG, not by mode. Guest-local objects legitimately exist in
   * remote mode; only a tagged handle names something on the host. */
  if (wmtr_enabled() && RM_IS_REMOTE((uint64_t)(uintptr_t)*obj)) {
    struct rm_arg_handle a = { (uint64_t)(uintptr_t)*obj };
    struct rm_ret_handle r;
    /* The host returns the SAME handle; identity must not change under retain. */
    wmtr_call(RM_OP_RETAIN, &a, sizeof a, &r, sizeof r, 0);
    return STATUS_SUCCESS;
  }
  [*obj retain];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSObject_release(NSObject **obj) {
  if (wmtr_enabled() && RM_IS_REMOTE((uint64_t)(uintptr_t)*obj)) {
    struct rm_arg_handle a = { (uint64_t)(uintptr_t)*obj };
    wmtr_buf_remove(a.handle);   /* no-op unless it was a registered buffer */
    wmtr_call(RM_OP_RELEASE, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  [*obj release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSArray_object(void *obj) {
  struct unixcall_generic_obj_uint64_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle_u64 a = { params->handle, params->arg };
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_ARRAY_OBJECT, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)[(NSArray *)params->handle objectAtIndex:params->arg];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSArray_count(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_ARRAY_COUNT, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(NSArray *)params->handle count];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCopyAllDevices(void *obj) {
  struct unixcall_generic_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_COPY_ALL_DEVICES, 0, 0, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)MTLCopyAllDevices();
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_recommendedMaxWorkingSetSize(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_DEVICE_MAX_WORKING_SET, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle recommendedMaxWorkingSetSize];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_currentAllocatedSize(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_ALLOCATED_SIZE, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle currentAllocatedSize];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_name(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    char buf[256]; uint32_t got = 0;
    if (wmtr_call(RM_OP_DEVICE_NAME, &a, sizeof a, buf, sizeof buf - 1, &got) == RM_OK) {
      if (got >= sizeof buf) got = sizeof buf - 1;
      buf[got] = 0;
      params->ret = (obj_handle_t)[[NSString alloc] initWithUTF8String:buf];
    } else {
      params->ret = (obj_handle_t)[[NSString alloc] initWithUTF8String:"remote device"];
    }
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)[(id<MTLDevice>)params->handle name];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSString_getCString(void *obj) {
  struct unixcall_nsstring_getcstring *params = obj;
  params->ret = (uint32_t)[(NSString *)params->str getCString:(char *)params->buffer_ptr
                                                    maxLength:params->max_length
                                                     encoding:params->encoding];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newCommandQueue(void *obj) {
  struct unixcall_generic_obj_uint64_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle_u64 a = { params->handle, params->arg };
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_NEW_COMMAND_QUEUE, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)[(id<MTLDevice>)params->handle newCommandQueueWithMaxCommandBufferCount:params->arg];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSAutoreleasePool_alloc_init(void *obj) {
  struct unixcall_generic_obj_ret *params = obj;
  params->ret = (obj_handle_t)[[NSAutoreleasePool alloc] init];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandQueue_commandBuffer(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_COMMAND_BUFFER, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)[(id<MTLCommandQueue>)params->handle commandBuffer];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_commit(void *obj) {
  struct unixcall_generic_obj_noret *params = obj;
  if (wmtr_enabled()) {
    /* Push guest shadows BEFORE the GPU reads them. The app writes into buffer
     * contents with no call of its own, so this is the last point at which the
     * host copy can be made to match. */
    wmtr_flush_buffers();
    struct rm_arg_handle a = { params->handle };
    wmtr_call(RM_OP_COMMIT, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  [(id<MTLCommandBuffer>)params->handle commit];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_waitUntilCompleted(void *obj) {
  struct unixcall_generic_obj_noret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    wmtr_call(RM_OP_WAIT_COMPLETED, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  [(id<MTLCommandBuffer>)params->handle waitUntilCompleted];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_status(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_CMDBUF_STATUS, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLCommandBuffer>)params->handle status];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newSharedEvent(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_NEW_SHARED_EVENT, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)[(id<MTLDevice>)params->handle newSharedEvent];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLSharedEvent_signaledValue(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_SHARED_EVENT_VALUE, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLSharedEvent>)params->handle signaledValue];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_encodeSignalEvent(void *obj) {
  struct unixcall_generic_obj_obj_uint64_noret *params = obj;
  if (wmtr_enabled()) {
    struct rm_encode_sig a = { params->handle, params->arg0, params->arg1 };
    wmtr_call(RM_OP_ENCODE_SIGNAL, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  [(id<MTLCommandBuffer>)params->handle encodeSignalEvent:(id<MTLSharedEvent>)params->arg0 value:params->arg1];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newBuffer(void *obj) {
  struct unixcall_mtldevice_newbuffer *params = obj;
  if (wmtr_enabled()) {
    struct WMTBufferInfo *bi = params->info.ptr;
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTBufferInfo)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->device; w->info_len = sizeof *bi; w->extra_count = 0;
    memcpy(buf + sizeof *w, bi, sizeof *bi);
    struct rm_ret_handle_u64 r;
    params->ret = 0;
    if (wmtr_call(RM_OP_NEW_BUFFER_INFO, buf, sizeof buf, &r, sizeof r, 0) == RM_OK && r.handle) {
      params->ret = r.handle;
      bi->gpu_address = r.value;
      /* Private buffers are never touched by the CPU, so they need no shadow. */
      int cpu = ((bi->options & 0x30) != WMTResourceStorageModePrivate);
      /* CRITICAL: if the caller supplied memory, that IS the buffer's storage
       * and must be preserved. The local path passes it to
       * newBufferWithBytesNoCopy; DXMT's ring allocator hands in
       * block.mapped_address and then keeps writing argument-buffer contents
       * and GPU addresses through that same pointer. Substituting our own
       * allocation here meant the app wrote one block while the flush uploaded
       * another, so the shaders read zeros -- draws executed and produced
       * nothing, which is exactly the flat clear with no geometry. */
      void *shadow = bi->memory.ptr;
      int owned = 0;
      if (cpu && !shadow) {
        shadow = calloc(1, bi->length ? bi->length : 1);
        owned = 1;
        if (!shadow)
          fprintf(stderr, "[wmt-remote] no shadow for a %llu byte buffer -- its writes "
                          "will NOT reach the host\n", (unsigned long long)bi->length);
        bi->memory.ptr = shadow;   /* only when the caller supplied none */
      }
      wmtr_buf_add(r.handle, shadow, bi->length, bi->options,
                   cpu && shadow != NULL, owned);
    } else {
      bi->memory.ptr = NULL;
      bi->gpu_address = 0;
    }
    return STATUS_SUCCESS;
  }
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  struct WMTBufferInfo *info = params->info.ptr;
  id<MTLBuffer> buffer;
  if (info->memory.ptr) {
    buffer = [device newBufferWithBytesNoCopy:info->memory.ptr
                                       length:info->length
                                      options:(enum MTLResourceOptions)info->options
                                  deallocator:NULL];
  } else {
    buffer = [device newBufferWithLength:info->length options:(enum MTLResourceOptions)info->options];
    info->memory.ptr = [buffer storageMode] == MTLStorageModePrivate ? NULL : [buffer contents];
  }
  params->ret = (obj_handle_t)buffer;
  info->gpu_address = [buffer gpuAddress];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newSamplerState(void *obj) {
  struct unixcall_mtldevice_newsamplerstate *params = obj;
  if (wmtr_enabled()) {
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTSamplerInfo)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->device; w->info_len = sizeof(struct WMTSamplerInfo); w->extra_count = 0;
    memcpy(buf + sizeof *w, params->info.ptr, sizeof(struct WMTSamplerInfo));
    struct rm_ret_handle_u64 r;
    if (wmtr_call(RM_OP_NEW_SAMPLER_INFO, buf, sizeof buf, &r, sizeof r, 0) == RM_OK) {
      params->ret = r.handle;
      ((struct WMTSamplerInfo *)params->info.ptr)->gpu_resource_id = r.value;
    } else {
      params->ret = 0;
    }
    return STATUS_SUCCESS;
  }
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  struct WMTSamplerInfo *info = params->info.ptr;

  MTLSamplerDescriptor *sampler_desc = [[MTLSamplerDescriptor alloc] init];
  sampler_desc.borderColor = (MTLSamplerBorderColor)info->border_color;
  sampler_desc.rAddressMode = (MTLSamplerAddressMode)info->r_address_mode;
  sampler_desc.sAddressMode = (MTLSamplerAddressMode)info->s_address_mode;
  sampler_desc.tAddressMode = (MTLSamplerAddressMode)info->t_address_mode;
  sampler_desc.magFilter = (MTLSamplerMinMagFilter)info->mag_filter;
  sampler_desc.minFilter = (MTLSamplerMinMagFilter)info->min_filter;
  sampler_desc.mipFilter = (MTLSamplerMipFilter)info->mip_filter;
  sampler_desc.compareFunction = (MTLCompareFunction)info->compare_function;
  sampler_desc.lodMaxClamp = info->lod_max_clamp;
  sampler_desc.lodMinClamp = info->lod_min_clamp;
  sampler_desc.maxAnisotropy = info->max_anisotroy;
  sampler_desc.lodAverage = info->lod_average;
  sampler_desc.normalizedCoordinates = info->normalized_coords;
  sampler_desc.supportArgumentBuffers = info->support_argument_buffers;

  id<MTLSamplerState> sampler = [device newSamplerStateWithDescriptor:sampler_desc];
  info->gpu_resource_id = info->support_argument_buffers ? [sampler gpuResourceID]._impl : 0;
  params->ret = (obj_handle_t)sampler;
  [sampler_desc release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newDepthStencilState(void *obj) {
  struct unixcall_mtldevice_newdepthstencilstate *params = obj;
  if (wmtr_enabled()) {
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTDepthStencilInfo)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->device; w->info_len = sizeof(struct WMTDepthStencilInfo); w->extra_count = 0;
    memcpy(buf + sizeof *w, params->info.ptr, sizeof(struct WMTDepthStencilInfo));
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_NEW_DSS_INFO, buf, sizeof buf, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  const struct WMTDepthStencilInfo *info = params->info.ptr;

  MTLDepthStencilDescriptor *desc = [[MTLDepthStencilDescriptor alloc] init];
  desc.depthCompareFunction = (MTLCompareFunction)info->depth_compare_function;
  desc.depthWriteEnabled = info->depth_write_enabled;

  if (info->front_stencil.enabled) {
    desc.frontFaceStencil.depthStencilPassOperation = (MTLStencilOperation)info->front_stencil.depth_stencil_pass_op;
    desc.frontFaceStencil.depthFailureOperation = (MTLStencilOperation)info->front_stencil.depth_fail_op;
    desc.frontFaceStencil.stencilFailureOperation = (MTLStencilOperation)info->front_stencil.stencil_fail_op;
    desc.frontFaceStencil.stencilCompareFunction = (MTLCompareFunction)info->front_stencil.stencil_compare_function;
    desc.frontFaceStencil.writeMask = info->front_stencil.write_mask;
    desc.frontFaceStencil.readMask = info->front_stencil.read_mask;
  }

  if (info->back_stencil.enabled) {
    desc.backFaceStencil.depthStencilPassOperation = (MTLStencilOperation)info->back_stencil.depth_stencil_pass_op;
    desc.backFaceStencil.depthFailureOperation = (MTLStencilOperation)info->back_stencil.depth_fail_op;
    desc.backFaceStencil.stencilFailureOperation = (MTLStencilOperation)info->back_stencil.stencil_fail_op;
    desc.backFaceStencil.stencilCompareFunction = (MTLCompareFunction)info->back_stencil.stencil_compare_function;
    desc.backFaceStencil.writeMask = info->back_stencil.write_mask;
    desc.backFaceStencil.readMask = info->back_stencil.read_mask;
  }

  params->ret = (obj_handle_t)[device newDepthStencilStateWithDescriptor:desc];
  [desc release];
  return STATUS_SUCCESS;
}

/* iOS-Madeira 2026-05-13: iPhone GPUs (Apple7/Apple8 = A14/A15) lack native
 * BC (DXT/BPTC) texture support — that's Apple9 / Mac2 only. Games like
 * Thumper unconditionally CreateTexture2D(BC1) on their .pc cache files,
 * which then dies in Metal's MTLTextureDescriptor validateWithDevice.
 *
 * Tier-1 fix: remap BC formats to RGBA8 (or matching narrower format) so
 * the descriptor validates. The uploaded BC blob will be interpreted as
 * RGBA8 garbage — black/noise textures with correct geometry. Acceptable
 * for boot validation; tier-3 CPU decompression will follow once a first
 * frame renders. */
static enum WMTPixelFormat remap_unsupported_bc(enum WMTPixelFormat fmt, bool bc_supported) {
  if (bc_supported)
    return fmt;
  switch (fmt) {
  case WMTPixelFormatBC1_RGBA:
  case WMTPixelFormatBC2_RGBA:
  case WMTPixelFormatBC3_RGBA:
  case WMTPixelFormatBC7_RGBAUnorm:
    return WMTPixelFormatRGBA8Unorm;
  case WMTPixelFormatBC1_RGBA_sRGB:
  case WMTPixelFormatBC2_RGBA_sRGB:
  case WMTPixelFormatBC3_RGBA_sRGB:
  case WMTPixelFormatBC7_RGBAUnorm_sRGB:
    return WMTPixelFormatRGBA8Unorm_sRGB;
  case WMTPixelFormatBC4_RUnorm:
    return WMTPixelFormatR8Unorm;
  case WMTPixelFormatBC4_RSnorm:
    return WMTPixelFormatR8Snorm;
  case WMTPixelFormatBC5_RGUnorm:
    return WMTPixelFormatRG8Unorm;
  case WMTPixelFormatBC5_RGSnorm:
    return WMTPixelFormatRG8Snorm;
  case WMTPixelFormatBC6H_RGBFloat:
  case WMTPixelFormatBC6H_RGBUfloat:
    return WMTPixelFormatRGBA16Float;
  default:
    return fmt;
  }
}

/* Cached per-device check — set on first to_metal_pixel_format call.
 * Safe because Madeira runs a single MTLDevice. */
static int g_bc_supported_cached = -1;
static bool query_bc_support(void) {
  if (__builtin_expect(g_bc_supported_cached >= 0, 1))
    return g_bc_supported_cached != 0;
  /* In remote mode this must describe the HOST gpu. The local probe below
   * creates an MTLDevice directly -- which both answers for the wrong machine
   * and creates a local Metal object in a mode that is supposed to have none. */
  if (wmtr_enabled()) {
    g_bc_supported_cached = wmtr_host_bc();
    return g_bc_supported_cached != 0;
  }
  bool supported = false;
  @autoreleasepool {
    id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    if (dev) {
      if ([dev respondsToSelector:@selector(supportsBCTextureCompression)])
        supported = [dev supportsBCTextureCompression];
      [dev release];
    }
  }
  g_bc_supported_cached = supported ? 1 : 0;
  /* iOS-Madeira 2026-05-18: one-shot log so we can see if A15+ supports BC
   * natively (would skip all the BC decoder work). Fires exactly once
   * per process — first call to to_metal_pixel_format. */
  dprintf(STDERR_FILENO,
          "[iOS DXMT] supportsBCTextureCompression = %s\n",
          supported ? "YES" : "NO");
  return supported;
}

MTLPixelFormat to_metal_pixel_format(enum WMTPixelFormat format) {
  enum WMTPixelFormat stripped = (enum WMTPixelFormat)ORIGINAL_FORMAT(format);
  {
    /* ml678: prove sRGB survives the BC remap instead of reading the switch and
     * assuming. A BC1_sRGB landing in a linear RGBA8 would wash every albedo
     * out -- one candidate for the flat look that remains after the BC6H fix. */
    enum WMTPixelFormat before = stripped;
    stripped = remap_unsupported_bc(stripped, query_bc_support());
    if (before != stripped) {
      static struct { unsigned s, d, n; } tbl[24];
      static unsigned tn;
      unsigned i;
      for (i = 0; i < tn; i++) if (tbl[i].s == before && tbl[i].d == stripped) break;
      if (i == tn && tn < 24) { tbl[tn].s = before; tbl[tn].d = stripped; tbl[tn].n = 0; tn++; }
      if (i < 24) {
        tbl[i].n++;
        if (tbl[i].n == 1 || (tbl[i].n % 512) == 0)
          fprintf(stderr, "[bc-remap] ml678 %u -> %u  n=%u  (sRGB-in=%d sRGB-out=%d)\n",
                  before, stripped, tbl[i].n,
                  (int)(before == WMTPixelFormatBC1_RGBA_sRGB || before == WMTPixelFormatBC2_RGBA_sRGB ||
                        before == WMTPixelFormatBC3_RGBA_sRGB || before == WMTPixelFormatBC7_RGBAUnorm_sRGB),
                  (int)(stripped == WMTPixelFormatRGBA8Unorm_sRGB));
      }
    }
  }
  return (MTLPixelFormat)stripped;
}

/* iOS-Madeira 2026-05-13: When BC textures are remapped to RGBA8 by
 * to_metal_pixel_format, the game continues to upload BC-compressed bytes
 * with BC row pitch. Metal's replaceRegion/copyFromBuffer validators will
 * abort if bytesPerRow < width * bytes_per_pixel for the (now RGBA8)
 * destination. This helper returns false when the upload would trip that
 * check, letting the call site skip rather than abort. The texture stays
 * zero/garbage — fine for boot validation. */
static bool format_bytes_per_pixel(MTLPixelFormat fmt, size_t *bpp_out) {
  switch (fmt) {
  case MTLPixelFormatA8Unorm:
  case MTLPixelFormatR8Unorm:
  case MTLPixelFormatR8Snorm:
  case MTLPixelFormatR8Uint:
  case MTLPixelFormatR8Sint:
  case MTLPixelFormatStencil8:
    *bpp_out = 1; return true;
  case MTLPixelFormatR16Unorm:
  case MTLPixelFormatR16Snorm:
  case MTLPixelFormatR16Uint:
  case MTLPixelFormatR16Sint:
  case MTLPixelFormatR16Float:
  case MTLPixelFormatRG8Unorm:
  case MTLPixelFormatRG8Snorm:
  case MTLPixelFormatRG8Uint:
  case MTLPixelFormatRG8Sint:
  case MTLPixelFormatDepth16Unorm:
    *bpp_out = 2; return true;
  case MTLPixelFormatRGBA8Unorm:
  case MTLPixelFormatRGBA8Unorm_sRGB:
  case MTLPixelFormatRGBA8Snorm:
  case MTLPixelFormatRGBA8Uint:
  case MTLPixelFormatRGBA8Sint:
  case MTLPixelFormatBGRA8Unorm:
  case MTLPixelFormatBGRA8Unorm_sRGB:
  case MTLPixelFormatRG16Unorm:
  case MTLPixelFormatRG16Snorm:
  case MTLPixelFormatRG16Uint:
  case MTLPixelFormatRG16Sint:
  case MTLPixelFormatRG16Float:
  case MTLPixelFormatR32Uint:
  case MTLPixelFormatR32Sint:
  case MTLPixelFormatR32Float:
  case MTLPixelFormatDepth32Float:
  case MTLPixelFormatRGB10A2Unorm:
  case MTLPixelFormatRGB10A2Uint:
  case MTLPixelFormatBGR10A2Unorm:
  case MTLPixelFormatRG11B10Float:
  case MTLPixelFormatRGB9E5Float:
    *bpp_out = 4; return true;
  case MTLPixelFormatRGBA16Unorm:
  case MTLPixelFormatRGBA16Snorm:
  case MTLPixelFormatRGBA16Uint:
  case MTLPixelFormatRGBA16Sint:
  case MTLPixelFormatRGBA16Float:
  case MTLPixelFormatRG32Uint:
  case MTLPixelFormatRG32Sint:
  case MTLPixelFormatRG32Float:
  case MTLPixelFormatDepth32Float_Stencil8:
    *bpp_out = 8; return true;
  case MTLPixelFormatRGBA32Uint:
  case MTLPixelFormatRGBA32Sint:
  case MTLPixelFormatRGBA32Float:
    *bpp_out = 16; return true;
  default:
    return false;
  }
}

static bool texture_upload_pitch_ok(id<MTLTexture> tex, size_t width, size_t bytes_per_row) {
  if (bytes_per_row == 0)
    return true;
  size_t bpp;
  if (!format_bytes_per_pixel([tex pixelFormat], &bpp))
    return true;
  return bytes_per_row >= width * bpp;
}

void
fill_texture_descriptor(MTLTextureDescriptor *desc, struct WMTTextureInfo *info) {
  desc.textureType = (MTLTextureType)info->type;
  desc.pixelFormat = to_metal_pixel_format(info->pixel_format);
  desc.width = info->width;
  desc.height = info->height;
  desc.depth = info->depth;
  desc.arrayLength = info->array_length;
  desc.mipmapLevelCount = info->mipmap_level_count;
  desc.sampleCount = info->sample_count;
  desc.usage = (MTLTextureUsage)info->usage;
  desc.resourceOptions = (MTLResourceOptions)info->options;
};

void
extract_texture_descriptor(id<MTLTexture> desc, struct WMTTextureInfo *info) {
  info->type = desc.textureType;
  info->pixel_format = desc.pixelFormat;
  info->width = desc.width;
  info->height = desc.height;
  info->depth = desc.depth;
  info->array_length = desc.arrayLength;
  info->mipmap_level_count = desc.mipmapLevelCount;
  info->sample_count = desc.sampleCount;
  info->usage = desc.usage;
  info->options = (enum WMTResourceOptions)desc.resourceOptions;
  info->reserved = 0;
};

static NTSTATUS
_MTLDevice_newTexture(void *obj) {
  struct unixcall_mtldevice_newtexture *params = obj;
  if (wmtr_enabled()) {
    struct WMTTextureInfo *ti = params->info.ptr;
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTTextureInfo)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->device; w->info_len = sizeof *ti; w->extra_count = 0;
    memcpy(buf + sizeof *w, ti, sizeof *ti);
    struct rm_ret_handle_u64 r;
    if (wmtr_call(RM_OP_NEW_TEXTURE_FULL, buf, sizeof buf, &r, sizeof r, 0) == RM_OK && r.handle) {
      params->ret = r.handle;
      ti->gpu_resource_id = r.value;
    } else {
      params->ret = 0; ti->gpu_resource_id = 0;
      fprintf(stderr, "[wmt-remote] host could not create a %ux%u texture (format %u)\n",
              ti->width, ti->height, (unsigned)ti->pixel_format);
    }
    /* Mach-port texture sharing cannot work across machines. */
    ti->mach_port = 0;
    return STATUS_SUCCESS;
  }
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  struct WMTTextureInfo *info = params->info.ptr;
  MTLTextureDescriptor *desc = [[MTLTextureDescriptor alloc] init];
  fill_texture_descriptor(desc, info);

  id<MTLTexture> ret = [device newTextureWithDescriptor:desc];
  params->ret = (obj_handle_t)ret;
  info->gpu_resource_id = [ret gpuResourceID]._impl;
  info->mach_port = 0;

  [desc release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLBuffer_newTexture(void *obj) {
  struct unixcall_mtlbuffer_newtexture *params = obj;
  id<MTLBuffer> buffer = (id<MTLBuffer>)params->buffer;
  struct WMTTextureInfo *info = params->info.ptr;
  if (wmtr_enabled()) {
    uint8_t buf[sizeof(struct rm_buf_texture) + sizeof(struct WMTTextureInfo)];
    struct rm_buf_texture *a = (void *)buf;
    a->buffer = params->buffer; a->offset = params->offset;
    a->bytes_per_row = params->bytes_per_row;
    memcpy(buf + sizeof *a, info, sizeof *info);
    struct rm_ret_handle_u64 r;
    if (wmtr_call(RM_OP_BUFFER_NEW_TEXTURE, buf, sizeof buf, &r, sizeof r, 0) == RM_OK && r.handle) {
      params->ret = r.handle;
      info->gpu_resource_id = r.value;
    } else {
      params->ret = 0; info->gpu_resource_id = 0;
      fprintf(stderr, "[wmt-remote] host could not make a buffer-backed %ux%u texture\n",
              info->width, info->height);
    }
    info->mach_port = 0;
    return STATUS_SUCCESS;
  }
  MTLTextureDescriptor *desc = [[MTLTextureDescriptor alloc] init];
  fill_texture_descriptor(desc, info);

  id<MTLTexture> ret = [buffer newTextureWithDescriptor:desc offset:params->offset bytesPerRow:params->bytes_per_row];
  params->ret = (obj_handle_t)ret;
  info->gpu_resource_id = [ret gpuResourceID]._impl;
  info->mach_port = 0;

  [desc release];
  return STATUS_SUCCESS;
}

static inline MTLTextureSwizzleChannels
to_metal_swizzle(struct WMTTextureSwizzleChannels swizzle, enum WMTPixelFormat format) {
  if (format & WMTPixelFormatRGB1Swizzle) {
    return MTLTextureSwizzleChannelsMake(
        (MTLTextureSwizzle)swizzle.r, (MTLTextureSwizzle)swizzle.g, (MTLTextureSwizzle)swizzle.b, MTLTextureSwizzleOne
    );
  }
  if (format & WMTPixelFormatR001Swizzle) {
    return MTLTextureSwizzleChannelsMake(
        (MTLTextureSwizzle)swizzle.r, MTLTextureSwizzleZero, MTLTextureSwizzleZero, MTLTextureSwizzleOne
    );
  }
  if (format & WMTPixelFormat0R01Swizzle) {
    return MTLTextureSwizzleChannelsMake(
        MTLTextureSwizzleOne, (MTLTextureSwizzle)swizzle.r, MTLTextureSwizzleOne, MTLTextureSwizzleOne
    );
  }
  if (format & WMTPixelFormatGBARSwizzle) {
    return MTLTextureSwizzleChannelsMake(
        (MTLTextureSwizzle)swizzle.g, (MTLTextureSwizzle)swizzle.b, (MTLTextureSwizzle)swizzle.a,
        (MTLTextureSwizzle)swizzle.r
    );
  }
  return MTLTextureSwizzleChannelsMake(
      (MTLTextureSwizzle)swizzle.r, (MTLTextureSwizzle)swizzle.g, (MTLTextureSwizzle)swizzle.b,
      (MTLTextureSwizzle)swizzle.a
  );
}

static NTSTATUS
_MTLTexture_newTextureView(void *obj) {
  struct unixcall_mtltexture_newtextureview *params = obj;
  if (wmtr_enabled()) {
    struct rm_tex_view a = { params->texture, (uint32_t)params->format,
                             (uint32_t)params->texture_type,
                             params->level_start, params->level_count,
                             params->slice_start, params->slice_count, 0 };
    struct rm_ret_handle_u64 r;
    if (wmtr_call(RM_OP_NEW_TEXTURE_VIEW, &a, sizeof a, &r, sizeof r, 0) == RM_OK) {
      params->ret = r.handle; params->gpu_resource_id = r.value;
    } else { params->ret = 0; params->gpu_resource_id = 0; }
    return STATUS_SUCCESS;
  }
  id<MTLTexture> texture = (id<MTLTexture>)params->texture;

  id<MTLTexture> ret = [texture
      newTextureViewWithPixelFormat:to_metal_pixel_format(params->format)
                        textureType:(MTLTextureType)params->texture_type
                             levels:NSMakeRange(params->level_start, params->level_count)
                             slices:NSMakeRange(params->slice_start, params->slice_count)
                            swizzle:to_metal_swizzle(params->swizzle, params->format)];
  params->ret = (obj_handle_t)ret;
  params->gpu_resource_id = [ret gpuResourceID]._impl;
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_minimumLinearTextureAlignmentForPixelFormat(void *obj) {
  struct unixcall_generic_obj_uint64_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle_u64 a = { params->handle, params->arg };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_MIN_LINEAR_ALIGN, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 256;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle minimumLinearTextureAlignmentForPixelFormat:to_metal_pixel_format(params->arg)];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newLibrary(void *obj) {
  struct unixcall_mtldevice_newlibrary *params = obj;
  if (wmtr_enabled()) {
    /* DispatchData stays guest-local (it is a byte container, not an identity),
     * so the metallib BYTES are what travel. dispatch_data_create_map hands us
     * one contiguous view even when the data is a composite of regions. */
    const void *bytes = NULL; size_t len = 0;
    dispatch_data_t flat = dispatch_data_create_map((dispatch_data_t)params->data, &bytes, &len);
    params->ret_error = 0;
    params->ret_library = 0;
    if (flat && bytes && len && len <= RM_CHUNK_BYTES) {
      /* The host builds its OWN dispatch_data from these bytes, then the
       * library from that. Two round trips for three libraries is nothing. */
      uint8_t *msg = malloc(len);
      if (msg) {
        memcpy(msg, bytes, len);
        struct rm_ret_handle rd_;
        if (wmtr_call(RM_OP_DISPATCH_DATA, msg, (uint32_t)len, &rd_, sizeof rd_, 0) == RM_OK) {
          struct rm_arg_handle_u64 a = { params->device, rd_.handle };
          struct rm_ret_handle rl;
          if (wmtr_call(RM_OP_NEW_LIBRARY_DATA, &a, sizeof a, &rl, sizeof rl, 0) == RM_OK)
            params->ret_library = rl.handle;
          struct rm_arg_handle da = { rd_.handle };   /* the library holds its own ref */
          wmtr_call(RM_OP_RELEASE, &da, sizeof da, 0, 0, 0);
        }
        free(msg);
      }
    } else if (len > RM_CHUNK_BYTES) {
      fprintf(stderr, "[wmt-remote] metallib is %zu bytes, over the %u cap -- not sent\n",
              len, RM_CHUNK_BYTES);
    }
    if (flat) dispatch_release(flat);
    return STATUS_SUCCESS;
  }
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  NSError *err = NULL;
  params->ret_library = (obj_handle_t)[device newLibraryWithData:(dispatch_data_t)params->data error:&err];
  params->ret_error = (obj_handle_t)err;
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLLibrary_newFunction(void *obj) {
  struct unixcall_generic_obj_uint64_obj_ret *params = obj;
  if (wmtr_enabled()) {
    /* arg is a guest pointer to a C string; the NAME crosses, never the pointer. */
    const char *nm = (const char *)params->arg;
    size_t nlen = nm ? strlen(nm) : 0;
    params->ret = 0;
    if (nlen && nlen < 1024) {
      uint8_t buf[sizeof(struct rm_arg_handle) + 1024];
      struct rm_arg_handle *a = (void *)buf;
      a->handle = params->handle;
      memcpy(buf + sizeof *a, nm, nlen);
      struct rm_ret_handle r;
      if (wmtr_call(RM_OP_NEW_FUNCTION, buf, (uint32_t)(sizeof *a + nlen), &r, sizeof r, 0) == RM_OK)
        params->ret = r.handle;
      if (!params->ret)
        fprintf(stderr, "[wmt-remote] newFunction(\"%s\") returned nothing\n", nm);
    }
    return STATUS_SUCCESS;
  }
  id<MTLLibrary> library = (id<MTLLibrary>)params->handle;
  NSString *name = [[NSString alloc] initWithCString:(char *)params->arg encoding:NSUTF8StringEncoding];
  params->ret = (obj_handle_t)[library newFunctionWithName:name];
  [name release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSString_lengthOfBytesUsingEncoding(void *obj) {
  struct unixcall_generic_obj_uint64_uint64_ret *params = obj;
  params->ret = (uint64_t)[(NSString *)params->handle lengthOfBytesUsingEncoding:(NSStringEncoding)params->arg];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSObject_description(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  params->ret = (obj_handle_t)[(NSObject *)params->handle description];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newComputePipelineState(void *obj) {
  struct unixcall_mtldevice_newcomputepso *params = obj;
  if (wmtr_enabled()) {
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTComputePipelineInfo)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->device; w->info_len = sizeof(struct WMTComputePipelineInfo); w->extra_count = 0;
    memcpy(buf + sizeof *w, params->info.ptr, sizeof(struct WMTComputePipelineInfo));
    struct rm_ret_handle r;
    params->ret_error = 0;
    params->ret_pso = (wmtr_call(RM_OP_NEW_COMPUTE_PSO_INFO, buf, sizeof buf, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  const struct WMTComputePipelineInfo *info = params->info.ptr;
  MTLComputePipelineDescriptor *descriptor = [[MTLComputePipelineDescriptor alloc] init];
  NSError *err = NULL;
  descriptor.computeFunction = (id<MTLFunction>)info->compute_function;
  descriptor.threadGroupSizeIsMultipleOfThreadExecutionWidth = info->tgsize_is_multiple_of_sgwidth;
  for (unsigned i = 0; i < 31; i++) {
    if (info->immutable_buffers & (1 << i))
      descriptor.buffers[i].mutability = MTLMutabilityImmutable;
  }
  if (info->num_binary_archives_for_lookup && info->binary_archives_for_lookup.ptr)
    descriptor.binaryArchives = [NSArray arrayWithObjects:(id<MTLBinaryArchive> *)info->binary_archives_for_lookup.ptr
                                                    count:info->num_binary_archives_for_lookup];
  MTLPipelineOption options =
      info->fail_on_binary_archive_miss ? MTLPipelineOptionFailOnBinaryArchiveMiss : MTLPipelineOptionNone;
  params->ret_pso =
      (obj_handle_t)[device newComputePipelineStateWithDescriptor:descriptor options:options reflection:nil error:&err];
  params->ret_error = (obj_handle_t)err;
  if (!err && info->binary_archive_for_serialization) {
    [(id<MTLBinaryArchive>)info->binary_archive_for_serialization addComputePipelineFunctionsWithDescriptor:descriptor
                                                                                                      error:&err];
  }
  [descriptor release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_blitCommandEncoder(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_BLIT_ENCODER, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)[(id<MTLCommandBuffer>)params->handle blitCommandEncoder];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_computeCommandEncoder(void *obj) {
  struct unixcall_generic_obj_uint64_obj_ret *params = obj;
  params->ret = (obj_handle_t)[(id<MTLCommandBuffer>)params->handle
      computeCommandEncoderWithDispatchType:params->arg ? MTLDispatchTypeConcurrent : MTLDispatchTypeSerial];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_renderCommandEncoder(void *obj) {
  struct unixcall_generic_obj_uint64_obj_ret *params = obj;
  struct WMTRenderPassInfo *info = (struct WMTRenderPassInfo *)params->arg;
  if (wmtr_enabled()) {
    /* The full pass: eight colour attachments with their own load/store
     * actions, levels, slices and resolve targets, plus depth and stencil.
     * The handles inside are already host handles, so they resolve there. */
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTRenderPassInfo)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->handle; w->info_len = sizeof(struct WMTRenderPassInfo); w->extra_count = 0;
    memcpy(buf + sizeof *w, info, sizeof(struct WMTRenderPassInfo));
    struct rm_ret_handle r;
    params->ret = (wmtr_call(RM_OP_RENDER_ENCODER, buf, sizeof buf, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    if (!params->ret) fprintf(stderr, "[wmt-remote] host refused a render encoder\n");
    return STATUS_SUCCESS;
  }
  MTLRenderPassDescriptor *descriptor = [[MTLRenderPassDescriptor alloc] init];
  for (unsigned i = 0; i < 8; i++) {
    descriptor.colorAttachments[i].clearColor = MTLClearColorMake(
        info->colors[i].clear_color.r, info->colors[i].clear_color.g, info->colors[i].clear_color.b,
        info->colors[i].clear_color.a
    );
    descriptor.colorAttachments[i].level = info->colors[i].level;
    descriptor.colorAttachments[i].slice = info->colors[i].slice;
    descriptor.colorAttachments[i].depthPlane = info->colors[i].depth_plane;
    descriptor.colorAttachments[i].texture = (id<MTLTexture>)info->colors[i].texture;
    descriptor.colorAttachments[i].loadAction = (MTLLoadAction)info->colors[i].load_action;
    descriptor.colorAttachments[i].storeAction = (MTLStoreAction)info->colors[i].store_action;
    descriptor.colorAttachments[i].resolveTexture = (id<MTLTexture>)info->colors[i].resolve_texture;
    descriptor.colorAttachments[i].resolveLevel = info->colors[i].resolve_level;
    descriptor.colorAttachments[i].resolveSlice = info->colors[i].resolve_slice;
    descriptor.colorAttachments[i].resolveDepthPlane = info->colors[i].resolve_depth_plane;
  }

  if (info->depth.texture) {
    descriptor.depthAttachment.clearDepth = info->depth.clear_depth;
    descriptor.depthAttachment.depthPlane = info->depth.depth_plane;
    descriptor.depthAttachment.level = info->depth.level;
    descriptor.depthAttachment.slice = info->depth.slice;
    descriptor.depthAttachment.texture = (id<MTLTexture>)info->depth.texture;
    descriptor.depthAttachment.loadAction = (MTLLoadAction)info->depth.load_action;
    descriptor.depthAttachment.storeAction = (MTLStoreAction)info->depth.store_action;
  }

  if (info->stencil.texture) {
    descriptor.stencilAttachment.clearStencil = info->stencil.clear_stencil;
    descriptor.stencilAttachment.depthPlane = info->stencil.depth_plane;
    descriptor.stencilAttachment.level = info->stencil.level;
    descriptor.stencilAttachment.slice = info->stencil.slice;
    descriptor.stencilAttachment.texture = (id<MTLTexture>)info->stencil.texture;
    descriptor.stencilAttachment.loadAction = (MTLLoadAction)info->stencil.load_action;
    descriptor.stencilAttachment.storeAction = (MTLStoreAction)info->stencil.store_action;
  }

  descriptor.defaultRasterSampleCount = info->default_raster_sample_count;
  descriptor.renderTargetArrayLength = info->render_target_array_length;
  descriptor.renderTargetHeight = info->render_target_height;
  descriptor.renderTargetWidth = info->render_target_width;
  descriptor.visibilityResultBuffer = (id<MTLBuffer>)info->visibility_buffer;

  params->ret = (obj_handle_t)[(id<MTLCommandBuffer>)params->handle renderCommandEncoderWithDescriptor:descriptor];

  [descriptor release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandEncoder_endEncoding(void *obj) {
  struct unixcall_generic_obj_noret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    wmtr_call(RM_OP_END_ENCODING, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  [(id<MTLCommandEncoder>)params->handle endEncoding];
  return STATUS_SUCCESS;
}

#ifndef DXMT_NO_PRIVATE_API

typedef NS_ENUM(NSUInteger, MTLLogicOperation) {
  MTLLogicOperationClear,
  MTLLogicOperationSet,
  MTLLogicOperationCopy,
  MTLLogicOperationCopyInverted,
  MTLLogicOperationNoop,
  MTLLogicOperationInvert,
  MTLLogicOperationAnd,
  MTLLogicOperationNand,
  MTLLogicOperationOr,
  MTLLogicOperationNor,
  MTLLogicOperationXor,
  MTLLogicOperationEquivalence,
  MTLLogicOperationAndReverse,
  MTLLogicOperationAndInverted,
  MTLLogicOperationOrReverse,
  MTLLogicOperationOrInverted,
};

@interface
MTLRenderPipelineDescriptor ()

- (void)setLogicOperationEnabled:(BOOL)enable;
- (void)setLogicOperation:(MTLLogicOperation)op;

@end

@interface
MTLMeshRenderPipelineDescriptor ()

- (void)setLogicOperationEnabled:(BOOL)enable;
- (void)setLogicOperation:(MTLLogicOperation)op;

@end

#endif

static NTSTATUS
_MTLDevice_newRenderPipelineState(void *obj) {
  struct unixcall_mtldevice_newrenderpso *params = obj;
  if (wmtr_enabled()) {
    /* The WHOLE descriptor crosses: eight colour attachments, blend factors,
     * write masks, depth/stencil formats, sample count, topology and
     * tessellation. A hand-picked subset is how this became a toy before. */
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTRenderPipelineInfo)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->device; w->info_len = sizeof(struct WMTRenderPipelineInfo); w->extra_count = 0;
    memcpy(buf + sizeof *w, params->info.ptr, sizeof(struct WMTRenderPipelineInfo));
    struct rm_ret_handle r;
    params->ret_error = 0;
    params->ret_pso = (wmtr_call(RM_OP_NEW_RENDER_PSO_INFO, buf, sizeof buf, &r, sizeof r, 0) == RM_OK) ? r.handle : 0;
    return STATUS_SUCCESS;
  }
  const struct WMTRenderPipelineInfo *info = params->info.ptr;
  MTLRenderPipelineDescriptor *descriptor = [[MTLRenderPipelineDescriptor alloc] init];

  for (unsigned i = 0; i < 8; i++) {
    descriptor.colorAttachments[i].pixelFormat = to_metal_pixel_format(info->colors[i].pixel_format);
    descriptor.colorAttachments[i].blendingEnabled = info->colors[i].blending_enabled;
    descriptor.colorAttachments[i].writeMask = (MTLColorWriteMask)info->colors[i].write_mask;

    descriptor.colorAttachments[i].alphaBlendOperation = (MTLBlendOperation)info->colors[i].alpha_blend_operation;
    descriptor.colorAttachments[i].rgbBlendOperation = (MTLBlendOperation)info->colors[i].rgb_blend_operation;

    descriptor.colorAttachments[i].sourceRGBBlendFactor = (MTLBlendFactor)info->colors[i].src_rgb_blend_factor;
    descriptor.colorAttachments[i].sourceAlphaBlendFactor = (MTLBlendFactor)info->colors[i].src_alpha_blend_factor;
    descriptor.colorAttachments[i].destinationRGBBlendFactor = (MTLBlendFactor)info->colors[i].dst_rgb_blend_factor;
    descriptor.colorAttachments[i].destinationAlphaBlendFactor = (MTLBlendFactor)info->colors[i].dst_alpha_blend_factor;
  }

  for (unsigned i = 0; i < 31; i++) {
    if (info->immutable_fragment_buffers & (1 << i))
      descriptor.fragmentBuffers[i].mutability = MTLMutabilityImmutable;
    if (info->immutable_vertex_buffers & (1 << i))
      descriptor.vertexBuffers[i].mutability = MTLMutabilityImmutable;
  }

#ifndef DXMT_NO_PRIVATE_API
  [descriptor setLogicOperationEnabled:info->logic_operation_enabled];
  [descriptor setLogicOperation:(MTLLogicOperation)info->logic_operation];
#endif
  descriptor.depthAttachmentPixelFormat = to_metal_pixel_format(info->depth_pixel_format);
  descriptor.stencilAttachmentPixelFormat = to_metal_pixel_format(info->stencil_pixel_format);
  descriptor.alphaToCoverageEnabled = info->alpha_to_coverage_enabled;
  descriptor.rasterizationEnabled = info->rasterization_enabled;
  descriptor.rasterSampleCount = info->raster_sample_count;
  descriptor.inputPrimitiveTopology = (MTLPrimitiveTopologyClass)info->input_primitive_topology;
  descriptor.tessellationPartitionMode = (MTLTessellationPartitionMode)info->tessellation_partition_mode;
  descriptor.tessellationFactorStepFunction = (MTLTessellationFactorStepFunction)info->tessellation_factor_step;
  descriptor.tessellationOutputWindingOrder = (MTLWinding)info->tessellation_output_winding_order;
  descriptor.maxTessellationFactor = info->max_tessellation_factor;

  descriptor.vertexFunction = (id<MTLFunction>)info->vertex_function;
  descriptor.fragmentFunction = (id<MTLFunction>)info->fragment_function;

  if (info->num_binary_archives_for_lookup && info->binary_archives_for_lookup.ptr)
    descriptor.binaryArchives = [NSArray arrayWithObjects:(id<MTLBinaryArchive> *)info->binary_archives_for_lookup.ptr
                                                    count:info->num_binary_archives_for_lookup];
  NSError *err = NULL;
  MTLPipelineOption options =
      info->fail_on_binary_archive_miss ? MTLPipelineOptionFailOnBinaryArchiveMiss : MTLPipelineOptionNone;
  params->ret_pso = (obj_handle_t)[(id<MTLDevice>)params->device newRenderPipelineStateWithDescriptor:descriptor
                                                                                              options:options
                                                                                           reflection:nil
                                                                                                error:&err];
  params->ret_error = (obj_handle_t)err;
  if (!err && info->binary_archive_for_serialization) {
    [(id<MTLBinaryArchive>)info->binary_archive_for_serialization addRenderPipelineFunctionsWithDescriptor:descriptor
                                                                                                     error:&err];
  }
  [descriptor release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newMeshRenderPipelineState(void *obj) {
  struct unixcall_mtldevice_newmeshrenderpso *params = obj;
  const struct WMTMeshRenderPipelineInfo *info = params->info.ptr;
  MTLMeshRenderPipelineDescriptor *descriptor = [[MTLMeshRenderPipelineDescriptor alloc] init];

  for (unsigned i = 0; i < 8; i++) {
    descriptor.colorAttachments[i].pixelFormat = to_metal_pixel_format(info->colors[i].pixel_format);
    descriptor.colorAttachments[i].blendingEnabled = info->colors[i].blending_enabled;
    descriptor.colorAttachments[i].writeMask = (MTLColorWriteMask)info->colors[i].write_mask;

    descriptor.colorAttachments[i].alphaBlendOperation = (MTLBlendOperation)info->colors[i].alpha_blend_operation;
    descriptor.colorAttachments[i].rgbBlendOperation = (MTLBlendOperation)info->colors[i].rgb_blend_operation;

    descriptor.colorAttachments[i].sourceRGBBlendFactor = (MTLBlendFactor)info->colors[i].src_rgb_blend_factor;
    descriptor.colorAttachments[i].sourceAlphaBlendFactor = (MTLBlendFactor)info->colors[i].src_alpha_blend_factor;
    descriptor.colorAttachments[i].destinationRGBBlendFactor = (MTLBlendFactor)info->colors[i].dst_rgb_blend_factor;
    descriptor.colorAttachments[i].destinationAlphaBlendFactor = (MTLBlendFactor)info->colors[i].dst_alpha_blend_factor;
  }

  for (unsigned i = 0; i < 31; i++) {
    if (info->immutable_fragment_buffers & (1 << i))
      descriptor.fragmentBuffers[i].mutability = MTLMutabilityImmutable;
    if (info->immutable_mesh_buffers & (1 << i))
      descriptor.meshBuffers[i].mutability = MTLMutabilityImmutable;
    if (info->immutable_object_buffers & (1 << i))
      descriptor.objectBuffers[i].mutability = MTLMutabilityImmutable;
  }

#ifndef DXMT_NO_PRIVATE_API
  [descriptor setLogicOperationEnabled:info->logic_operation_enabled];
  [descriptor setLogicOperation:(MTLLogicOperation)info->logic_operation];
#endif
  descriptor.depthAttachmentPixelFormat = to_metal_pixel_format(info->depth_pixel_format);
  descriptor.stencilAttachmentPixelFormat = to_metal_pixel_format(info->stencil_pixel_format);
  descriptor.alphaToCoverageEnabled = info->alpha_to_coverage_enabled;
  descriptor.rasterizationEnabled = info->rasterization_enabled;
  descriptor.rasterSampleCount = info->raster_sample_count;

  descriptor.objectFunction = (id<MTLFunction>)info->object_function;
  descriptor.meshFunction = (id<MTLFunction>)info->mesh_function;
  descriptor.fragmentFunction = (id<MTLFunction>)info->fragment_function;
  descriptor.payloadMemoryLength = info->payload_memory_length;

  descriptor.meshThreadgroupSizeIsMultipleOfThreadExecutionWidth = info->mesh_tgsize_is_multiple_of_sgwidth;
  descriptor.objectThreadgroupSizeIsMultipleOfThreadExecutionWidth = info->object_tgsize_is_multiple_of_sgwidth;

  MTLPipelineOption options = MTLPipelineOptionNone;
#if __MAC_OS_X_VERSION_MAX_ALLOWED >= 150000
  if (@available(macOS 15, *)) {
    if (info->num_binary_archives_for_lookup && info->binary_archives_for_lookup.ptr)
      descriptor.binaryArchives = [NSArray arrayWithObjects:(id<MTLBinaryArchive> *)info->binary_archives_for_lookup.ptr
                                                      count:info->num_binary_archives_for_lookup];
    options = info->fail_on_binary_archive_miss ? MTLPipelineOptionFailOnBinaryArchiveMiss : MTLPipelineOptionNone;
  }
#endif
  NSError *err = NULL;
  params->ret_pso = (obj_handle_t)[(id<MTLDevice>)params->device newRenderPipelineStateWithMeshDescriptor:descriptor
                                                                                                  options:options
                                                                                               reflection:nil
                                                                                                    error:&err];
  params->ret_error = (obj_handle_t)err;
#if __MAC_OS_X_VERSION_MAX_ALLOWED >= 150000
  if (@available(macOS 15, *)) {
    if (!err && info->binary_archive_for_serialization) {
      [(id<MTLBinaryArchive>)info->binary_archive_for_serialization
          addMeshRenderPipelineFunctionsWithDescriptor:descriptor
                                                 error:&err];
    }
  }
#endif
  [descriptor release];
  return STATUS_SUCCESS;
}

/* ---- ml760: shadow mode -------------------------------------------------
 *
 * Pack and validate every real batch, then throw the result away and render
 * locally as usual. The point is to exercise the packer against live traffic
 * where being wrong costs nothing, before anything depends on it.
 *
 * The check that matters is that packed counts equal census counts. If the
 * packer silently skips a command, the two diverge -- which is the failure a
 * remote replay would otherwise show as a subtly wrong frame on another
 * machine, with nothing pointing at the cause.
 */
#include "wmt_remote_pack.h"
#include "../../../../remote-metal/host/wmt_decode.h"

static int wmt_shadow_on = -1;
static unsigned long wmt_sh_ok, wmt_sh_packfail, wmt_sh_valfail, wmt_sh_records;
static unsigned long wmt_sh_max_recbytes, wmt_sh_max_sidebytes, wmt_sh_max_records;
static unsigned wmt_sh_last_packerr, wmt_sh_last_valerr, wmt_sh_last_opcode;

static void wmt_shadow_report(void) {
    if (wmt_shadow_on != 1) return;
    fprintf(stderr, "[shadow] ml760 packed=%lu packfail=%lu valfail=%lu records=%lu\n",
            wmt_sh_ok, wmt_sh_packfail, wmt_sh_valfail, wmt_sh_records);
    fprintf(stderr, "[shadow] max record-bytes=%lu sidecar-bytes=%lu records/batch=%lu\n",
            wmt_sh_max_recbytes, wmt_sh_max_sidebytes, wmt_sh_max_records);
    if (wmt_sh_packfail)
        fprintf(stderr, "[shadow] last pack failure: %s (opcode %u)\n",
                wmtw_pack_strerror((enum wmtw_pack_status)wmt_sh_last_packerr), wmt_sh_last_opcode);
    if (wmt_sh_valfail)
        fprintf(stderr, "[shadow] last validate failure: %s\n",
                wmtw_dec_strerror((enum wmtw_dec_status)wmt_sh_last_valerr));
}

static void wmt_shadow_batch(const struct wmtcmd_base *head) {
    if (__builtin_expect(wmt_shadow_on < 0, 0)) {
        const char *e = getenv("DXMT_SHADOW_PACK");
        wmt_shadow_on = (e && e[0] == '1') ? 1 : 0;
        if (wmt_shadow_on) fprintf(stderr, "[shadow] ml760 armed\n");
    }
    if (__builtin_expect(wmt_shadow_on != 1, 1)) return;

    /* Static: this runs per batch and must not allocate. Single-threaded use
     * is assumed here because it is a diagnostic, not a shipping path. */
    static uint8_t recbuf[WMTW_MAX_BATCH_BYTES];
    static uint8_t sidebuf[WMTW_MAX_SIDECAR_BYTES];
    static uint8_t payload[sizeof(struct wmtw_batch) + WMTW_MAX_BATCH_BYTES + WMTW_MAX_SIDECAR_BYTES];

    struct wmtw_packer p = { recbuf, sizeof recbuf, 0, sidebuf, sizeof sidebuf, 0, 0 };
    struct wmtw_pack_result pr;
    if (wmtw_pack_render(head, &p, &pr) != WMTW_PACK_OK) {
        wmt_sh_packfail++;
        wmt_sh_last_packerr = pr.status; wmt_sh_last_opcode = pr.opcode;
        return;
    }
    struct wmtw_batch *b = (void *)payload;
    b->magic = WMTW_BATCH_MAGIC; b->version = WMTW_VERSION; b->encoder_kind = 0;
    b->record_bytes = p.rec_len; b->record_count = p.count;
    b->sidecar_bytes = p.side_len; b->reserved = 0;
    memcpy(payload + sizeof *b, recbuf, p.rec_len);
    if (p.side_len) memcpy(payload + sizeof *b + p.rec_len, sidebuf, p.side_len);

    struct wmtw_dec_result dr; struct wmtw_view v;
    uint32_t plen = (uint32_t)(sizeof *b + p.rec_len + p.side_len);
    if (wmtw_validate_batch(payload, plen, &v, &dr) != WMTW_DEC_OK) {
        wmt_sh_valfail++; wmt_sh_last_valerr = dr.status;
        return;
    }
    wmt_sh_ok++;
    wmt_sh_records += p.count;
    if (p.rec_len  > wmt_sh_max_recbytes)  wmt_sh_max_recbytes  = p.rec_len;
    if (p.side_len > wmt_sh_max_sidebytes) wmt_sh_max_sidebytes = p.side_len;
    if (p.count    > wmt_sh_max_records)   wmt_sh_max_records   = p.count;
}

/* ---- ml758: wmtcmd census ----------------------------------------------
 *
 * Before wmtcmd_* lists can be serialised for the remote Metal transport, we
 * need to know which of the 59 command types a real workload actually emits,
 * and how large their sidecar data gets. Serialising all 59 on speculation
 * would be weeks of schema work for commands no title may ever issue.
 *
 * Counters only -- logging every command would change the timing of the thing
 * being measured. Enabled with DXMT_CMD_CENSUS=1; costs one predictable branch
 * per command otherwise.
 */
#define WMT_CENSUS_RENDER 40
#define WMT_CENSUS_COMPUTE 16
#define WMT_CENSUS_BLIT 12

static int wmt_census_on = -1;
static unsigned long wmt_c_render[WMT_CENSUS_RENDER];
static unsigned long wmt_c_compute[WMT_CENSUS_COMPUTE];
static unsigned long wmt_c_blit[WMT_CENSUS_BLIT];
static unsigned long wmt_batches_render, wmt_batches_compute, wmt_batches_blit;
static unsigned long wmt_records_total, wmt_records_max;
static unsigned long wmt_setbytes_calls, wmt_setbytes_bytes, wmt_setbytes_max;
static unsigned long wmt_viewport_calls, wmt_viewport_max;
static unsigned long wmt_scissor_calls, wmt_scissor_max;
/* first bounded opcode sequence, to show the SHAPE of a batch */
static unsigned short wmt_first_seq[64];
static unsigned wmt_first_len;
static int wmt_first_kind = -1;

/* Report PERIODICALLY, not only at exit. iOS apps are killed or backgrounded,
 * not cleanly exited, so an atexit-only summary never fires -- the first run
 * armed the census, counted commands, and printed nothing. */
static void wmt_census_report(void);

static void wmt_census_report(void) {
    if (wmt_census_on != 1) return;
    fprintf(stderr, "\n[cmd-census] ml758 batches render=%lu compute=%lu blit=%lu\n",
            wmt_batches_render, wmt_batches_compute, wmt_batches_blit);
    fprintf(stderr, "[cmd-census] records total=%lu max-per-batch=%lu\n",
            wmt_records_total, wmt_records_max);
    fprintf(stderr, "[cmd-census] setBytes calls=%lu bytes=%lu max=%lu\n",
            wmt_setbytes_calls, wmt_setbytes_bytes, wmt_setbytes_max);
    fprintf(stderr, "[cmd-census] viewports calls=%lu max-count=%lu | scissors calls=%lu max-count=%lu\n",
            wmt_viewport_calls, wmt_viewport_max, wmt_scissor_calls, wmt_scissor_max);
    for (int i = 0; i < WMT_CENSUS_RENDER; i++)
        if (wmt_c_render[i]) fprintf(stderr, "[cmd-census]   render[%2d] %lu\n", i, wmt_c_render[i]);
    for (int i = 0; i < WMT_CENSUS_COMPUTE; i++)
        if (wmt_c_compute[i]) fprintf(stderr, "[cmd-census]   compute[%2d] %lu\n", i, wmt_c_compute[i]);
    for (int i = 0; i < WMT_CENSUS_BLIT; i++)
        if (wmt_c_blit[i]) fprintf(stderr, "[cmd-census]   blit[%2d] %lu\n", i, wmt_c_blit[i]);
    wmt_shadow_report();
    if (wmt_first_len) {
        fprintf(stderr, "[cmd-census] first %s batch shape:", 
                wmt_first_kind == 0 ? "render" : wmt_first_kind == 1 ? "compute" : "blit");
        for (unsigned i = 0; i < wmt_first_len; i++) fprintf(stderr, " %u", wmt_first_seq[i]);
        fprintf(stderr, "\n");
    }
}

static void wmt_census_init(void) {
    const char *e = getenv("DXMT_CMD_CENSUS");
    wmt_census_on = (e && e[0] == '1') ? 1 : 0;
    if (wmt_census_on) { fprintf(stderr, "[cmd-census] ml758 armed\n"); atexit(wmt_census_report); }
}

/* kind: 0 render, 1 compute, 2 blit */
static inline void wmt_census_batch(const struct wmtcmd_base *head, int kind) {
    if (__builtin_expect(wmt_census_on < 0, 0)) wmt_census_init();
    if (__builtin_expect(wmt_census_on != 1, 1)) return;
    unsigned long n = 0;
    int capture = (wmt_first_len == 0);
    if (kind == 0) wmt_batches_render++; else if (kind == 1) wmt_batches_compute++; else wmt_batches_blit++;
    for (const struct wmtcmd_base *c = head; c; ) {
        unsigned t = c->type;
        if (kind == 0 && t < WMT_CENSUS_RENDER) wmt_c_render[t]++;
        else if (kind == 1 && t < WMT_CENSUS_COMPUTE) wmt_c_compute[t]++;
        else if (kind == 2 && t < WMT_CENSUS_BLIT) wmt_c_blit[t]++;
        if (capture && n < 64) { wmt_first_seq[n] = (unsigned short)t; wmt_first_kind = kind; }
        n++;
        c = (const struct wmtcmd_base *)c->next.ptr;
    }
    if (capture) wmt_first_len = (unsigned)(n < 64 ? n : 64);
    wmt_records_total += n;
    if (n > wmt_records_max) wmt_records_max = n;

    /* First batch, then every 512, then at exit. The first tells us the census
     * is live and shows a real batch shape immediately; the cadence keeps a
     * long-running app reporting without flooding the log. */
    {
        static unsigned long ticks;
        unsigned long t = ++ticks;
        if (t == 1 || (t & 0x1FF) == 0) wmt_census_report();
    }
}

static inline void wmt_census_sidecar_bytes(unsigned long len) {
    if (wmt_census_on != 1) return;
    wmt_setbytes_calls++; wmt_setbytes_bytes += len;
    if (len > wmt_setbytes_max) wmt_setbytes_max = len;
}
static inline void wmt_census_viewports(unsigned long n) {
    if (wmt_census_on != 1) return;
    wmt_viewport_calls++; if (n > wmt_viewport_max) wmt_viewport_max = n;
}
static inline void wmt_census_scissors(unsigned long n) {
    if (wmt_census_on != 1) return;
    wmt_scissor_calls++; if (n > wmt_scissor_max) wmt_scissor_max = n;
}

/* Size of one blit command struct, by type. Zero for anything unknown: a
 * guessed size would copy the wrong bytes onto the wire, and a blit that
 * silently copies garbage is far worse than one that reports itself missing. */
static uint32_t wmt_blit_cmd_size(unsigned type) {
    switch (type) {
    case WMTBlitCommandNop:                       return sizeof(struct wmtcmd_blit_nop);
    case WMTBlitCommandCopyFromBufferToBuffer:    return sizeof(struct wmtcmd_blit_copy_from_buffer_to_buffer);
    case WMTBlitCommandCopyFromBufferToTexture:   return sizeof(struct wmtcmd_blit_copy_from_buffer_to_texture);
    case WMTBlitCommandCopyFromTextureToBuffer:   return sizeof(struct wmtcmd_blit_copy_from_texture_to_buffer);
    case WMTBlitCommandCopyFromTextureToTexture:  return sizeof(struct wmtcmd_blit_copy_from_texture_to_texture);
    case WMTBlitCommandGenerateMipmaps:           return sizeof(struct wmtcmd_blit_generate_mipmaps);
    case WMTBlitCommandWaitForFence:
    case WMTBlitCommandUpdateFence:               return sizeof(struct wmtcmd_blit_fence_op);
    case WMTBlitCommandFillBuffer:                return sizeof(struct wmtcmd_blit_fillbuffer);
    default:                                      return 0;
    }
}

static NTSTATUS
_MTLBlitCommandEncoder_encodeCommands(void *obj) {
  struct unixcall_generic_obj_cmd_noret *params = obj;
  const struct wmtcmd_base *next = params->cmd_head.ptr;
  if (wmtr_enabled()) {
    /* Blit commands carry only handles and scalars, so each struct travels
     * verbatim as {type, size, bytes}; the guest-pointer `next` is not sent.
     * That keeps this in step with the descriptor path rather than inventing a
     * second serialiser to drift. */
    static _Thread_local uint8_t *bbuf;
    if (!bbuf) bbuf = malloc(WMTW_MAX_BATCH_BYTES);
    if (!bbuf) return STATUS_SUCCESS;
    struct rm_arg_handle *ha = (void *)bbuf;
    ha->handle = params->encoder;
    size_t off = sizeof *ha;
    for (const struct wmtcmd_base *c = next; c; c = c->next.ptr) {
      uint32_t sz = wmt_blit_cmd_size(c->type);
      if (!sz) {
        static unsigned told;
        if (told++ < 8)
          fprintf(stderr, "[wmt-remote] blit command type %u has no known size -- NOT sent, "
                          "its destination will be stale\n", (unsigned)c->type);
        continue;
      }
      if (off + 8 + sz > WMTW_MAX_BATCH_BYTES) break;
      *(uint32_t *)(bbuf + off) = c->type;
      *(uint32_t *)(bbuf + off + 4) = sz;
      memcpy(bbuf + off + 8, c, sz);
      off += 8 + sz;
    }
    if (off > sizeof *ha) {
      struct rm_ret_u64 rr;
      wmtr_call(RM_OP_BLIT_INTO, bbuf, (uint32_t)off, &rr, sizeof rr, 0);
    }
    return STATUS_SUCCESS;
  }
  wmt_census_batch(next, 2);
  id<MTLBlitCommandEncoder> encoder = (id<MTLBlitCommandEncoder>)params->encoder;
  while (next) {
    switch ((enum WMTBlitCommandType)next->type) {
    default:
      assert(!next->type && "unhandled blit command type");
      break;
    case WMTBlitCommandCopyFromBufferToBuffer: {
      struct wmtcmd_blit_copy_from_buffer_to_buffer *body = (struct wmtcmd_blit_copy_from_buffer_to_buffer *)next;
      [encoder copyFromBuffer:(id<MTLBuffer>)body->src
                 sourceOffset:body->src_offset
                     toBuffer:(id<MTLBuffer>)body->dst
            destinationOffset:body->dst_offset
                         size:body->copy_length];
      break;
    }
    case WMTBlitCommandCopyFromBufferToTexture: {
      struct wmtcmd_blit_copy_from_buffer_to_texture *body = (struct wmtcmd_blit_copy_from_buffer_to_texture *)next;
      id<MTLTexture> dst = (id<MTLTexture>)body->dst;
      /* iOS-Madeira: skip BC-pitch uploads to remapped RGBA8 textures. */
      if (!texture_upload_pitch_ok(dst, body->size.width, body->bytes_per_row))
        break;
      [encoder copyFromBuffer:(id<MTLBuffer>)body->src
                 sourceOffset:body->src_offset
            sourceBytesPerRow:body->bytes_per_row
          sourceBytesPerImage:body->bytes_per_image
                   sourceSize:MTLSizeMake(body->size.width, body->size.height, body->size.depth)
                    toTexture:dst
             destinationSlice:body->slice
             destinationLevel:body->level
            destinationOrigin:MTLOriginMake(body->origin.x, body->origin.y, body->origin.z)];
      break;
    }
    case WMTBlitCommandCopyFromTextureToBuffer: {
      struct wmtcmd_blit_copy_from_texture_to_buffer *body = (struct wmtcmd_blit_copy_from_texture_to_buffer *)next;
      id<MTLTexture> src = (id<MTLTexture>)body->src;
      /* iOS-Madeira: skip BC-pitch readback to remapped RGBA8 textures. */
      if (!texture_upload_pitch_ok(src, body->size.width, body->bytes_per_row))
        break;
      [encoder copyFromTexture:src
                       sourceSlice:body->slice
                       sourceLevel:body->level
                      sourceOrigin:MTLOriginMake(body->origin.x, body->origin.y, body->origin.z)
                        sourceSize:MTLSizeMake(body->size.width, body->size.height, body->size.depth)
                          toBuffer:(id<MTLBuffer>)body->dst
                 destinationOffset:body->offset
            destinationBytesPerRow:body->bytes_per_row
          destinationBytesPerImage:body->bytes_per_image];
      break;
    }
    case WMTBlitCommandCopyFromTextureToTexture: {
      struct wmtcmd_blit_copy_from_texture_to_texture *body = (struct wmtcmd_blit_copy_from_texture_to_texture *)next;
      [encoder copyFromTexture:(id<MTLTexture>)body->src
                   sourceSlice:body->src_slice
                   sourceLevel:body->src_level
                  sourceOrigin:MTLOriginMake(body->src_origin.x, body->src_origin.y, body->src_origin.z)
                    sourceSize:MTLSizeMake(body->src_size.width, body->src_size.height, body->src_size.depth)
                     toTexture:(id<MTLTexture>)body->dst
              destinationSlice:body->dst_slice
              destinationLevel:body->dst_level
             destinationOrigin:MTLOriginMake(body->dst_origin.x, body->dst_origin.y, body->dst_origin.z)];
      break;
    }
    case WMTBlitCommandGenerateMipmaps: {
      struct wmtcmd_blit_generate_mipmaps *body = (struct wmtcmd_blit_generate_mipmaps *)next;
      [encoder generateMipmapsForTexture:(id<MTLTexture>)body->texture];
      break;
    }
    case WMTBlitCommandUpdateFence: {
      struct wmtcmd_blit_fence_op *body = (struct wmtcmd_blit_fence_op *)next;
      [encoder updateFence:(id<MTLFence>)body->fence];
      break;
    }
    case WMTBlitCommandWaitForFence: {
      struct wmtcmd_blit_fence_op *body = (struct wmtcmd_blit_fence_op *)next;
      [encoder waitForFence:(id<MTLFence>)body->fence];
      break;
    }
    case WMTBlitCommandFillBuffer: {
      struct wmtcmd_blit_fillbuffer *body = (struct wmtcmd_blit_fillbuffer *)next;
      [encoder fillBuffer:(id<MTLBuffer>)body->buffer range:NSMakeRange(body->offset, body->length) value:body->value];
      break;
    }
    }

    next = next->next.ptr;
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLComputeCommandEncoder_encodeCommands(void *obj) {
  struct unixcall_generic_obj_cmd_noret *params = obj;
  const struct wmtcmd_base *next = params->cmd_head.ptr;
  wmt_census_batch(next, 1);
  id<MTLComputeCommandEncoder> encoder = (id<MTLComputeCommandEncoder>)params->encoder;
  MTLSize threadgroup_size = {0, 0, 0};
  while (next) {
    switch ((enum WMTComputeCommandType)next->type) {
    default:
      assert(!next->type && "unhandled compute command type");
      break;
    case WMTComputeCommandDispatch: {
      struct wmtcmd_compute_dispatch *body = (struct wmtcmd_compute_dispatch *)next;
      [encoder dispatchThreadgroups:MTLSizeMake(body->size.width, body->size.height, body->size.depth)
              threadsPerThreadgroup:threadgroup_size];
      break;
    }
    case WMTComputeCommandDispatchThreads: {
      struct wmtcmd_compute_dispatch *body = (struct wmtcmd_compute_dispatch *)next;
      [encoder dispatchThreads:MTLSizeMake(body->size.width, body->size.height, body->size.depth)
          threadsPerThreadgroup:threadgroup_size];
      break;
    }
    case WMTComputeCommandDispatchIndirect: {
      struct wmtcmd_compute_dispatch_indirect *body = (struct wmtcmd_compute_dispatch_indirect *)next;
      [encoder dispatchThreadgroupsWithIndirectBuffer:(id<MTLBuffer>)body->indirect_args_buffer
                                 indirectBufferOffset:body->indirect_args_offset
                                threadsPerThreadgroup:threadgroup_size];
      break;
    }
    case WMTComputeCommandSetPSO: {
      struct wmtcmd_compute_setpso *body = (struct wmtcmd_compute_setpso *)next;
      [encoder setComputePipelineState:(id<MTLComputePipelineState>)body->pso];
      threadgroup_size.width = body->threadgroup_size.width;
      threadgroup_size.height = body->threadgroup_size.height;
      threadgroup_size.depth = body->threadgroup_size.depth;
      break;
    }
    case WMTComputeCommandSetBuffer: {
      struct wmtcmd_compute_setbuffer *body = (struct wmtcmd_compute_setbuffer *)next;
      [encoder setBuffer:(id<MTLBuffer>)body->buffer offset:body->offset atIndex:body->index];
      break;
    }
    case WMTComputeCommandSetBufferOffset: {
      struct wmtcmd_compute_setbufferoffset *body = (struct wmtcmd_compute_setbufferoffset *)next;
      [encoder setBufferOffset:body->offset atIndex:body->index];
      break;
    }
    case WMTComputeCommandUseResource: {
      struct wmtcmd_compute_useresource *body = (struct wmtcmd_compute_useresource *)next;
      [encoder useResource:(id<MTLResource>)body->resource usage:(MTLResourceUsage)body->usage];
      break;
    }
    case WMTComputeCommandSetBytes: {
      struct wmtcmd_compute_setbytes *body = (struct wmtcmd_compute_setbytes *)next;
      wmt_census_sidecar_bytes(body->length);
      [encoder setBytes:body->bytes.ptr length:body->length atIndex:body->index];
      break;
    }
    case WMTComputeCommandSetTexture: {
      struct wmtcmd_compute_settexture *body = (struct wmtcmd_compute_settexture *)next;
      [encoder setTexture:(id<MTLTexture>)body->texture atIndex:body->index];
      break;
    }
    case WMTComputeCommandUpdateFence: {
      struct wmtcmd_compute_fence_op *body = (struct wmtcmd_compute_fence_op *)next;
      [encoder updateFence:(id<MTLFence>)body->fence];
      break;
    }
    case WMTComputeCommandWaitForFence: {
      struct wmtcmd_compute_fence_op *body = (struct wmtcmd_compute_fence_op *)next;
      [encoder waitForFence:(id<MTLFence>)body->fence];
      break;
    }
    }

    next = next->next.ptr;
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLRenderCommandEncoder_encodeCommands(void *obj) {
  struct unixcall_generic_obj_cmd_noret *params = obj;
  const struct wmtcmd_base *next = params->cmd_head.ptr;
  if (wmtr_enabled()) {
    /* Pack with the SAME packer the wire tests exercise: a second walker here
     * would prove nothing about either. The batch replays into the existing
     * encoder, so Metal state survives across the dozen batches a frame sends. */
    /* Allocated on FIRST USE per thread, not as static thread-local storage.
     * As _Thread_local these two arrays were 1.1MB of TLS in EVERY thread the
     * process creates -- wine and FEX make many, none of which encode -- and
     * the run that introduced them died with a guest allocation returning NULL
     * and DXMT zeroing a structure through it. Only encoding threads pay now. */
    static _Thread_local uint8_t *rec, *side;
    if (!rec) {
      rec = malloc(WMTW_MAX_BATCH_BYTES);
      side = malloc(WMTW_MAX_SIDECAR_BYTES);
      if (!rec || !side) {
        free(rec); free(side); rec = side = NULL;
        static unsigned once;
        if (!once++) fprintf(stderr, "[wmt-remote] no packing buffers -- batches dropped\n");
        return STATUS_SUCCESS;
      }
    }
    struct wmtw_packer pk = { rec, WMTW_MAX_BATCH_BYTES, 0, side, WMTW_MAX_SIDECAR_BYTES, 0, 0 };
    struct wmtw_pack_result pr;
    if (wmtw_pack_render(next, &pk, &pr) != WMTW_PACK_OK) {
      /* Report each MISSING OPCODE once, not the first eight failures.
       * A pack failure drops the whole batch, so one unsupported command
       * removes every draw in it -- and reporting only the first occurrence
       * hides the rest behind it, costing a run per gap. */
      static unsigned seen[64]; static unsigned seen_n; static unsigned long dropped;
      dropped++;
      unsigned k = 0;
      for (; k < seen_n; k++) if (seen[k] == pr.opcode) break;
      if (k == seen_n && seen_n < 64) {
        seen[seen_n++] = pr.opcode;
        fprintf(stderr, "[wmt-remote] pack: UNSUPPORTED render opcode %u (%s) -- batch dropped, "
                        "%u distinct opcode(s) missing so far, %lu batches lost\n",
                pr.opcode, wmtw_pack_strerror(pr.status), seen_n, dropped);
      }
      return STATUS_SUCCESS;
    }
    uint32_t total = (uint32_t)(sizeof(struct rm_arg_handle) + sizeof(struct wmtw_batch)
                                + pk.rec_len + pk.side_len);
    uint8_t *msg = malloc(total);
    if (msg) {
      struct rm_arg_handle *a = (void *)msg;
      a->handle = params->encoder;
      struct wmtw_batch *b = (void *)(msg + sizeof *a);
      b->magic = WMTW_BATCH_MAGIC; b->version = WMTW_VERSION; b->encoder_kind = 0;
      b->record_bytes = pk.rec_len; b->record_count = pk.count;
      b->sidecar_bytes = pk.side_len; b->reserved = 0;
      memcpy((uint8_t *)(b + 1), rec, pk.rec_len);
      memcpy((uint8_t *)(b + 1) + pk.rec_len, side, pk.side_len);
      struct rm_ret_u64 rr;
      if (wmtr_call(RM_OP_ENCODE_INTO, msg, total, &rr, sizeof rr, 0) != RM_OK) {
        static unsigned bad;
        if (bad++ < 8) fprintf(stderr, "[wmt-remote] host rejected a packed batch\n");
      }
      free(msg);
    }
    return STATUS_SUCCESS;
  }
  /* Shadow BEFORE census: the census report is emitted from inside
   * wmt_census_batch, so with the old order it had counted the current batch
   * while shadow had not, and the two totals differed by exactly one batch
   * forever. Ordering it this way makes "packed == batches" an exact equality
   * that either holds or reveals a real skip. */
  wmt_shadow_batch(next);
  wmt_census_batch(next, 0);
  id<MTLRenderCommandEncoder> encoder = (id<MTLRenderCommandEncoder>)params->encoder;
  while (next) {
    switch ((enum WMTRenderCommandType)next->type) {
    default:
      assert(!next->type && "unhandled render command type");
      break;
    case WMTRenderCommandNop:
      break;
    case WMTRenderCommandUseResource: {
      struct wmtcmd_render_useresource *body = (struct wmtcmd_render_useresource *)next;
      [encoder useResource:(id<MTLResource>)body->resource
                     usage:(MTLResourceUsage)body->usage
                    stages:(MTLRenderStages)body->stages];
      break;
    }
    case WMTRenderCommandSetVertexBuffer: {
      struct wmtcmd_render_setbuffer *body = (struct wmtcmd_render_setbuffer *)next;
      [encoder setVertexBuffer:(id<MTLBuffer>)body->buffer offset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetVertexBufferOffset: {
      struct wmtcmd_render_setbufferoffset *body = (struct wmtcmd_render_setbufferoffset *)next;
      [encoder setVertexBufferOffset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetFragmentBuffer: {
      struct wmtcmd_render_setbuffer *body = (struct wmtcmd_render_setbuffer *)next;
      [encoder setFragmentBuffer:(id<MTLBuffer>)body->buffer offset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetFragmentBufferOffset: {
      struct wmtcmd_render_setbufferoffset *body = (struct wmtcmd_render_setbufferoffset *)next;
      [encoder setFragmentBufferOffset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetMeshBuffer: {
      struct wmtcmd_render_setbuffer *body = (struct wmtcmd_render_setbuffer *)next;
      [encoder setMeshBuffer:(id<MTLBuffer>)body->buffer offset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetMeshBufferOffset: {
      struct wmtcmd_render_setbufferoffset *body = (struct wmtcmd_render_setbufferoffset *)next;
      [encoder setMeshBufferOffset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetObjectBuffer: {
      struct wmtcmd_render_setbuffer *body = (struct wmtcmd_render_setbuffer *)next;
      [encoder setObjectBuffer:(id<MTLBuffer>)body->buffer offset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetObjectBufferOffset: {
      struct wmtcmd_render_setbufferoffset *body = (struct wmtcmd_render_setbufferoffset *)next;
      [encoder setObjectBufferOffset:body->offset atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetFragmentBytes: {
      struct wmtcmd_render_setbytes *body = (struct wmtcmd_render_setbytes *)next;
      wmt_census_sidecar_bytes(body->length);
      [encoder setFragmentBytes:body->bytes.ptr length:body->length atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetFragmentTexture: {
      struct wmtcmd_render_settexture *body = (struct wmtcmd_render_settexture *)next;
      [encoder setFragmentTexture:(id<MTLTexture>)body->texture atIndex:body->index];
      break;
    }
    case WMTRenderCommandSetRasterizerState: {
      struct wmtcmd_render_setrasterizerstate *body = (struct wmtcmd_render_setrasterizerstate *)next;
      [encoder setTriangleFillMode:(MTLTriangleFillMode)body->fill_mode];
      [encoder setCullMode:(MTLCullMode)body->cull_mode];
      [encoder setDepthClipMode:(MTLDepthClipMode)body->depth_clip_mode];
      [encoder setDepthBias:body->depth_bias slopeScale:body->scole_scale clamp:body->depth_bias_clamp];
      [encoder setFrontFacingWinding:(MTLWinding)body->winding];
      break;
    }
    case WMTRenderCommandSetViewports: {
      struct wmtcmd_render_setviewports *body = (struct wmtcmd_render_setviewports *)next;
      wmt_census_viewports(body->viewport_count);
      [encoder setViewports:(const MTLViewport *)body->viewports.ptr count:body->viewport_count];
      break;
    }
    case WMTRenderCommandSetScissorRects: {
      struct wmtcmd_render_setscissorrects *body = (struct wmtcmd_render_setscissorrects *)next;
      wmt_census_scissors(body->rect_count);
      [encoder setScissorRects:(const MTLScissorRect *)body->scissor_rects.ptr count:body->rect_count];
      break;
    }
    case WMTRenderCommandSetPSO: {
      struct wmtcmd_render_setpso *body = (struct wmtcmd_render_setpso *)next;
      [encoder setRenderPipelineState:(id<MTLRenderPipelineState>)body->pso];
      break;
    }
    case WMTRenderCommandSetDSSO: {
      struct wmtcmd_render_setdsso *body = (struct wmtcmd_render_setdsso *)next;
      [encoder setDepthStencilState:(id<MTLDepthStencilState>)body->dsso];
      [encoder setStencilReferenceValue:body->stencil_ref];
      break;
    }
    case WMTRenderCommandSetBlendFactorAndStencilRef: {
      struct wmtcmd_render_setblendcolor *body = (struct wmtcmd_render_setblendcolor *)next;
      [encoder setBlendColorRed:body->red green:body->green blue:body->blue alpha:body->alpha];
      [encoder setStencilReferenceValue:body->stencil_ref];
      break;
    }
    case WMTRenderCommandSetVisibilityMode: {
      struct wmtcmd_render_setvisibilitymode *body = (struct wmtcmd_render_setvisibilitymode *)next;
      [encoder setVisibilityResultMode:(MTLVisibilityResultMode)body->mode offset:body->offset];
      break;
    }
    case WMTRenderCommandDraw: {
      struct wmtcmd_render_draw *body = (struct wmtcmd_render_draw *)next;
      atomic_fetch_add_explicit(&g_madeira_draw_calls, 1, memory_order_relaxed);
      [encoder drawPrimitives:(MTLPrimitiveType)body->primitive_type
                  vertexStart:body->vertex_start
                  vertexCount:body->vertex_count
                instanceCount:body->instance_count
                 baseInstance:body->base_instance];
      break;
    }
    case WMTRenderCommandDrawIndexed: {
      struct wmtcmd_render_draw_indexed *body = (struct wmtcmd_render_draw_indexed *)next;
      atomic_fetch_add_explicit(&g_madeira_draw_calls, 1, memory_order_relaxed);
      [encoder drawIndexedPrimitives:(MTLPrimitiveType)body->primitive_type
                          indexCount:body->index_count
                           indexType:(MTLIndexType)body->index_type
                         indexBuffer:(id<MTLBuffer>)body->index_buffer
                   indexBufferOffset:body->index_buffer_offset
                       instanceCount:body->instance_count
                          baseVertex:body->base_vertex
                        baseInstance:body->base_instance];
      break;
    }
    case WMTRenderCommandDrawIndirect: {
      struct wmtcmd_render_draw_indirect *body = (struct wmtcmd_render_draw_indirect *)next;
      atomic_fetch_add_explicit(&g_madeira_draw_calls, 1, memory_order_relaxed);
      [encoder drawPrimitives:(MTLPrimitiveType)body->primitive_type
                indirectBuffer:(id<MTLBuffer>)body->indirect_args_buffer
          indirectBufferOffset:body->indirect_args_offset];
      break;
    }
    case WMTRenderCommandDrawIndexedIndirect: {
      struct wmtcmd_render_draw_indexed_indirect *body = (struct wmtcmd_render_draw_indexed_indirect *)next;
      atomic_fetch_add_explicit(&g_madeira_draw_calls, 1, memory_order_relaxed);
      [encoder drawIndexedPrimitives:(MTLPrimitiveType)body->primitive_type
                           indexType:(MTLIndexType)body->index_type
                         indexBuffer:(id<MTLBuffer>)body->index_buffer
                   indexBufferOffset:body->index_buffer_offset
                      indirectBuffer:(id<MTLBuffer>)body->indirect_args_buffer
                indirectBufferOffset:body->indirect_args_offset];
      break;
    }
    case WMTRenderCommandDrawMeshThreadgroups: {
      struct wmtcmd_render_draw_meshthreadgroups *body = (struct wmtcmd_render_draw_meshthreadgroups *)next;
      [encoder drawMeshThreadgroups:MTLSizeMake(
                                        body->threadgroup_per_grid.width, body->threadgroup_per_grid.height,
                                        body->threadgroup_per_grid.depth
                                    )
          threadsPerObjectThreadgroup:MTLSizeMake(
                                          body->object_threadgroup_size.width, body->object_threadgroup_size.height,
                                          body->object_threadgroup_size.depth
                                      )
            threadsPerMeshThreadgroup:MTLSizeMake(
                                          body->mesh_threadgroup_size.width, body->mesh_threadgroup_size.height,
                                          body->mesh_threadgroup_size.depth
                                      )];
      break;
    }
    case WMTRenderCommandDrawMeshThreadgroupsIndirect: {
      struct wmtcmd_render_draw_meshthreadgroups_indirect *body =
          (struct wmtcmd_render_draw_meshthreadgroups_indirect *)next;
      [encoder drawMeshThreadgroupsWithIndirectBuffer:(id<MTLBuffer>)body->indirect_args_buffer
                                 indirectBufferOffset:body->indirect_args_offset
                          threadsPerObjectThreadgroup:MTLSizeMake(
                                                          body->object_threadgroup_size.width,
                                                          body->object_threadgroup_size.height,
                                                          body->object_threadgroup_size.depth
                                                      )
                            threadsPerMeshThreadgroup:MTLSizeMake(
                                                          body->mesh_threadgroup_size.width,
                                                          body->mesh_threadgroup_size.height,
                                                          body->mesh_threadgroup_size.depth
                                                      )];
      break;
    }
    case WMTRenderCommandMemoryBarrier: {
      struct wmtcmd_render_memory_barrier *body = (struct wmtcmd_render_memory_barrier *)next;
      [encoder memoryBarrierWithScope:(MTLBarrierScope)body->scope
                          afterStages:(MTLRenderStages)body->stages_after
                         beforeStages:(MTLRenderStages)body->stages_before];
      break;
    }
    case WMTRenderCommandDXMTGeometryDraw: {
      struct wmtcmd_render_dxmt_geometry_draw *body = (struct wmtcmd_render_dxmt_geometry_draw *)next;
      [encoder setObjectBufferOffset:body->draw_arguments_offset atIndex:21];
      [encoder drawMeshThreadgroups:MTLSizeMake(body->warp_count, body->instance_count, 1)
          threadsPerObjectThreadgroup:MTLSizeMake(body->vertex_per_warp, 1, 1)
            threadsPerMeshThreadgroup:MTLSizeMake(1, 1, 1)];
      break;
    }
    case WMTRenderCommandDXMTGeometryDrawIndexed: {
      struct wmtcmd_render_dxmt_geometry_draw_indexed *body = (struct wmtcmd_render_dxmt_geometry_draw_indexed *)next;
      [encoder setObjectBuffer:(id<MTLBuffer>)body->index_buffer offset:body->index_buffer_offset atIndex:20];
      [encoder setObjectBufferOffset:body->draw_arguments_offset atIndex:21];
      [encoder drawMeshThreadgroups:MTLSizeMake(body->warp_count, body->instance_count, 1)
          threadsPerObjectThreadgroup:MTLSizeMake(body->vertex_per_warp, 1, 1)
            threadsPerMeshThreadgroup:MTLSizeMake(1, 1, 1)];
      break;
    }
    case WMTRenderCommandDXMTGeometryDrawIndirect: {
      struct wmtcmd_render_dxmt_geometry_draw_indirect *body = (struct wmtcmd_render_dxmt_geometry_draw_indirect *)next;
      [encoder setObjectBuffer:(id<MTLBuffer>)body->indirect_args_buffer offset:body->indirect_args_offset atIndex:21];
      [encoder drawMeshThreadgroupsWithIndirectBuffer:(id<MTLBuffer>)body->dispatch_args_buffer
                                 indirectBufferOffset:body->dispatch_args_offset
                          threadsPerObjectThreadgroup:MTLSizeMake(body->vertex_per_warp, 1, 1)
                            threadsPerMeshThreadgroup:MTLSizeMake(1, 1, 1)];
      [encoder setObjectBuffer:(id<MTLBuffer>)body->imm_draw_arguments offset:0 atIndex:21];
      break;
    }
    case WMTRenderCommandDXMTGeometryDrawIndexedIndirect: {
      struct wmtcmd_render_dxmt_geometry_draw_indexed_indirect *body =
          (struct wmtcmd_render_dxmt_geometry_draw_indexed_indirect *)next;
      [encoder setObjectBuffer:(id<MTLBuffer>)body->index_buffer offset:body->index_buffer_offset atIndex:20];
      [encoder setObjectBuffer:(id<MTLBuffer>)body->indirect_args_buffer offset:body->indirect_args_offset atIndex:21];
      [encoder drawMeshThreadgroupsWithIndirectBuffer:(id<MTLBuffer>)body->dispatch_args_buffer
                                 indirectBufferOffset:body->dispatch_args_offset
                          threadsPerObjectThreadgroup:MTLSizeMake(body->vertex_per_warp, 1, 1)
                            threadsPerMeshThreadgroup:MTLSizeMake(1, 1, 1)];
      [encoder setObjectBuffer:(id<MTLBuffer>)body->imm_draw_arguments offset:0 atIndex:21];
      break;
    }
    case WMTRenderCommandDXMTTessellationMeshDraw: {
      struct wmtcmd_render_dxmt_tessellation_mesh_draw *body = (struct wmtcmd_render_dxmt_tessellation_mesh_draw *)next;
      [encoder setObjectBufferOffset:body->draw_arguments_offset atIndex:21];
      [encoder drawMeshThreadgroups:MTLSizeMake(body->patch_per_mesh_instance, body->instance_count, 1)
          threadsPerObjectThreadgroup:MTLSizeMake(body->threads_per_patch, body->patch_per_group, 1)
            threadsPerMeshThreadgroup:MTLSizeMake(32, 1, 1)];
      break;
    }
    case WMTRenderCommandDXMTTessellationMeshDrawIndexed: {
      struct wmtcmd_render_dxmt_tessellation_mesh_draw_indexed *body = (struct wmtcmd_render_dxmt_tessellation_mesh_draw_indexed *)next;
      [encoder setObjectBuffer:(id<MTLBuffer>)body->index_buffer offset:body->index_buffer_offset atIndex:20];
      [encoder setObjectBufferOffset:body->draw_arguments_offset atIndex:21];
      [encoder drawMeshThreadgroups:MTLSizeMake(body->patch_per_mesh_instance, body->instance_count, 1)
          threadsPerObjectThreadgroup:MTLSizeMake(body->threads_per_patch, body->patch_per_group, 1)
            threadsPerMeshThreadgroup:MTLSizeMake(32, 1, 1)];
      break;
    }

    case WMTRenderCommandDXMTTessellationMeshDrawIndirect: {
      struct wmtcmd_render_dxmt_tessellation_mesh_draw_indirect *body = (struct wmtcmd_render_dxmt_tessellation_mesh_draw_indirect *)next;
      [encoder setObjectBuffer:(id<MTLBuffer>)body->indirect_args_buffer offset:body->indirect_args_offset atIndex:21];
      [encoder drawMeshThreadgroupsWithIndirectBuffer:(id<MTLBuffer>)body->dispatch_args_buffer
                                 indirectBufferOffset:body->dispatch_args_offset
                          threadsPerObjectThreadgroup:MTLSizeMake(body->threads_per_patch, body->patch_per_group, 1)
                            threadsPerMeshThreadgroup:MTLSizeMake(32, 1, 1)];
      [encoder setObjectBuffer:(id<MTLBuffer>)body->imm_draw_arguments offset:0 atIndex:21];
      break;
    }
    case WMTRenderCommandDXMTTessellationMeshDrawIndexedIndirect: {
      struct wmtcmd_render_dxmt_tessellation_mesh_draw_indexed_indirect *body =
          (struct wmtcmd_render_dxmt_tessellation_mesh_draw_indexed_indirect *)next;
      [encoder setObjectBuffer:(id<MTLBuffer>)body->index_buffer offset:body->index_buffer_offset atIndex:20];
      [encoder setObjectBuffer:(id<MTLBuffer>)body->indirect_args_buffer offset:body->indirect_args_offset atIndex:21];
      [encoder drawMeshThreadgroupsWithIndirectBuffer:(id<MTLBuffer>)body->dispatch_args_buffer
                                 indirectBufferOffset:body->dispatch_args_offset
                          threadsPerObjectThreadgroup:MTLSizeMake(body->threads_per_patch, body->patch_per_group, 1)
                            threadsPerMeshThreadgroup:MTLSizeMake(32, 1, 1)];
      [encoder setObjectBuffer:(id<MTLBuffer>)body->imm_draw_arguments offset:0 atIndex:21];
      break;
    }
    case WMTRenderCommandUpdateFence: {
      struct wmtcmd_render_fence_op *body = (struct wmtcmd_render_fence_op *)next;
      [encoder updateFence:(id<MTLFence>)body->fence afterStages:(MTLRenderStages)body->stages];
      break;
    }
    case WMTRenderCommandWaitForFence: {
      struct wmtcmd_render_fence_op *body = (struct wmtcmd_render_fence_op *)next;
      [encoder waitForFence:(id<MTLFence>)body->fence beforeStages:(MTLRenderStages)body->stages];
      break;
    }
    case WMTRenderCommandSetViewport: {
      struct wmtcmd_render_setviewport *body = (struct wmtcmd_render_setviewport *)next;
      union {
        struct WMTViewport src;
        MTLViewport dst;
      } u = {.src = body->viewport};
      [encoder setViewport:u.dst];
      break;
    }
    case WMTRenderCommandSetScissorRect: {
      struct wmtcmd_render_setscissorrect *body = (struct wmtcmd_render_setscissorrect *)next;
      union {
        struct WMTScissorRect src;
        MTLScissorRect dst;
      } u = {.src = body->scissor_rect};
      [encoder setScissorRect:u.dst];
      break;
    }
    }
    next = next->next.ptr;
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLTexture_pixelFormat(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  params->ret = [(id<MTLTexture>)params->handle pixelFormat];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLTexture_width(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    params->ret = wmtr_tex_dim(params->handle, 'w');
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLTexture>)params->handle width];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLTexture_height(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    params->ret = wmtr_tex_dim(params->handle, 'h');
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLTexture>)params->handle height];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLTexture_depth(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  params->ret = [(id<MTLTexture>)params->handle depth];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLTexture_arrayLength(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  params->ret = [(id<MTLTexture>)params->handle arrayLength];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLTexture_mipmapLevelCount(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  params->ret = [(id<MTLTexture>)params->handle mipmapLevelCount];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLTexture_replaceRegion(void *obj) {
  struct unixcall_mtltexture_replaceregion *params = obj;
  if (wmtr_enabled()) {
    uint64_t rows = params->size.height ? params->size.height : 1;
    uint64_t depth = params->size.depth ? params->size.depth : 1;
    uint64_t bytes = params->bytes_per_row * rows * depth;
    if (bytes && bytes <= RM_CHUNK_BYTES - sizeof(struct rm_tex_replace) && params->data.ptr) {
      uint8_t *msg = malloc(sizeof(struct rm_tex_replace) + bytes);
      if (msg) {
        struct rm_tex_replace *a = (void *)msg;
        a->texture = params->texture;
        a->x = params->origin.x; a->y = params->origin.y; a->z = params->origin.z;
        a->w = params->size.width; a->h = params->size.height; a->d = params->size.depth;
        a->level = (uint32_t)params->level; a->slice = (uint32_t)params->slice;
        a->bytes_per_row = (uint32_t)params->bytes_per_row;
        a->bytes_per_image = (uint32_t)params->bytes_per_image;
        memcpy(msg + sizeof *a, params->data.ptr, bytes);
        wmtr_call(RM_OP_TEXTURE_REPLACE, msg, (uint32_t)(sizeof *a + bytes), 0, 0, 0);
        free(msg);
      }
    } else if (bytes > RM_CHUNK_BYTES - sizeof(struct rm_tex_replace)) {
      fprintf(stderr, "[wmt-remote] texture upload of %llu bytes exceeds the message cap"
                      " -- NOT sent\n", (unsigned long long)bytes);
    }
    return STATUS_SUCCESS;
  }
  id<MTLTexture> tex = (id<MTLTexture>)params->texture;
  /* iOS-Madeira: skip BC-pitch uploads to remapped RGBA8 textures. */
  if (!texture_upload_pitch_ok(tex, params->size.width, params->bytes_per_row))
    return STATUS_SUCCESS;
  [tex replaceRegion:MTLRegionMake3D(
                         params->origin.x, params->origin.y, params->origin.z,
                         params->size.width, params->size.height, params->size.depth
                     )
         mipmapLevel:params->level
               slice:params->slice
           withBytes:params->data.ptr
         bytesPerRow:params->bytes_per_row
       bytesPerImage:params->bytes_per_image];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLBuffer_didModifyRange(void *obj) {
  struct unixcall_generic_obj_uint64_uint64_ret *params = obj;
#if !TARGET_OS_IOS
  [(id<MTLBuffer>)params->handle didModifyRange:NSMakeRange(params->arg, params->ret)];
#else
  (void)params; /* iOS unified memory — no range invalidation needed. */
#endif
  return STATUS_SUCCESS;
}

/* iOS-Madeira 2026-05-13: track Present cadence so we can tell whether the
 * game's render loop is alive (continuous Presents → splash sustained via
 * redraw) or wedged on first frame. Prints once per ~60 frames at ~1Hz. */
static _Atomic uint64_t g_madeira_present_count = 0;
/* iOS-Madeira 2026-05-22: draw-call counter, sampled+reset on each present
 * log line. Tells us if the game is issuing draws between Presents or
 * presenting empty frames. Bumped in WMTRenderCommandDraw{,Indexed,Indirect,
 * IndexedIndirect} cases of the render-command processor.
 * Forward-declared near top of file; definition lives here. */

static inline void madeira_log_present_cadence(const char *path, double after) {
  uint64_t n = atomic_fetch_add_explicit(&g_madeira_present_count, 1, memory_order_relaxed) + 1;
  /* iOS-Madeira quiet mode: counter always ticks (FPS overlay reads it);
   * only the log line is suppressed. At RAW rates this line fires 100+
   * times/s — real I/O + heat. */
  {
    static int quiet = -1;
    if (quiet < 0) quiet = getenv("MADEIRA_QUIET") != NULL;
    if (quiet) return;
  }
  /* 2026-07-03: every-16 cadence (was 60) + monotonic timestamp + the
   * `after` min-duration arg — measures the black-phase ~1 FPS pacing
   * directly from the log (game-phase log lines carry no timestamps under
   * the WINEDEBUG perf default). */
  if (n == 1 || (n % 16) == 0) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    /* Sample + reset draw counter delta since last log line. */
    uint64_t cur_draws = atomic_load_explicit(&g_madeira_draw_calls, memory_order_relaxed);
    uint64_t last_draws = atomic_exchange_explicit(&g_madeira_draw_calls_at_last_log, cur_draws, memory_order_relaxed);
    uint64_t draws_since_last = cur_draws - last_draws;
    /* 2026-07-03 Mach-exception storm probe: the PC-sampling profiler put
     * ~25% of game-thread time in the exception-resume trampoline. This
     * counter (signal_arm64_ios.c, same binary) exposes exceptions/present.
     * Thousands per present = steady-state trap storm (suspect: guest CALL
     * pushes into trap-mode-protected callret memory at ~70us each). */
    extern volatile int ios_exc_msg_count;
    static int last_exc_count = 0;
    int cur_exc = ios_exc_msg_count;
    int exc_delta = cur_exc - last_exc_count;
    last_exc_count = cur_exc;
    /* iOS-Madeira 2026-07-05: frame anatomy for the locked-60 push —
     * game-thread server_wait wall time + wait/timeout/request counts
     * (server_ios.c, same binary). Deltas cover the 16 presents since
     * the last line. Answers: is the last ~1.5ms/frame server-request
     * WORK or wait-wake LATENCY? */
    extern volatile long long ios_srv_wait_us, ios_srv_wait_req_us;
    extern volatile int ios_srv_wait_count, ios_srv_wait_timeouts, ios_srv_req_count;
    static long long last_wait_us, last_req_us; static int last_wc, last_wt, last_rq;
    long long cur_wait_us = ios_srv_wait_us, cur_req_us = ios_srv_wait_req_us;
    int cur_wc = ios_srv_wait_count, cur_wt = ios_srv_wait_timeouts, cur_rq = ios_srv_req_count;
    dprintf(STDERR_FILENO, "[iOS DXMT] Present #%llu t=%llu.%03lu after=%.4f (draws_since_last=%llu total_draws=%llu machexc_delta=%d srvw=%d/%d w_ms=%.1f wreq_ms=%.1f reqs=%d) [%s]\n",
            (unsigned long long)n,
            (unsigned long long)ts.tv_sec, (unsigned long)(ts.tv_nsec / 1000000),
            after,
            (unsigned long long)draws_since_last,
            (unsigned long long)cur_draws,
            exc_delta,
            cur_wc - last_wc, cur_wt - last_wt,
            (cur_wait_us - last_wait_us) / 1000.0,
            (cur_req_us - last_req_us) / 1000.0,
            cur_rq - last_rq,
            path);
    last_wait_us = cur_wait_us; last_req_us = cur_req_us;
    last_wc = cur_wc; last_wt = cur_wt; last_rq = cur_rq;
  }
}

/* iOS-Madeira 2026-05-18: exposed for SwiftUI FPS overlay. Reads the
 * atomic counter on the calling thread (typically a 100ms Swift Timer). */
uint64_t madeira_get_present_count(void) {
  return atomic_load_explicit(&g_madeira_present_count, memory_order_relaxed);
}

/* NOTE (2026-07-03): a presented-handler probe lived here during the
 * visibility-stall investigation. Removed — presentedTime reported 0.000
 * even for frames provably on glass (the splash), so it carries no signal
 * for this layer. See project memory for the full postmortem. */

/* iOS-Madeira 2026-07-05: runtime present-pacing mode, read per present
 * (live-flippable from the Swift UI):
 *   1 = LOCKED (default): afterMinimumDuration(1/60) — exact 60.
 *   0 = MAX: present every frame, free-run to the display refresh
 *       (120Hz ProMotion with CADisableMinimumFrameDurationOnPhone +
 *       the app-side CADisplayLink intent; thermal governor may cap 60).
 *   2 = RAW: mailbox/frame-skip — the game runs UNTHROTTLED; a real
 *       drawable present is submitted at most every 8ms, other frames
 *       release their drawable unpresented so the pool never blocks.
 *       Measures raw stack throughput independent of the panel; the
 *       present COUNTER counts every game present (incl. skipped) so
 *       the FPS overlay reads true game rate. */
static volatile int g_madeira_vsync_mode = 1;
void madeira_set_vsync_locked(int mode) {
  g_madeira_vsync_mode = mode;
  dprintf(STDERR_FILENO, "[iOS DXMT] vsync_mode=%d (1=locked60 0=max 2=raw)\n", mode);
}
int madeira_get_vsync_locked(void) { return g_madeira_vsync_mode; }

static NTSTATUS
_MTLCommandBuffer_presentDrawable(void *obj) {
  struct unixcall_generic_obj_obj_noret *params = obj;
  if (wmtr_enabled()) {
    /* Presenting hands the drawable back to the host layer; without this the
     * pool leaks one a frame and acquisition eventually blocks forever. */
    struct rm_present a = { params->handle, params->arg };
    wmtr_call(RM_OP_PRESENT_DRAWABLE, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  int mode = g_madeira_vsync_mode;
  if (mode == 1) {
    madeira_log_present_cadence("presentDrawable60", 0.0);
    [(id<MTLCommandBuffer>)params->handle presentDrawable:(id<MTLDrawable>)params->arg
                                     afterMinimumDuration:(1.0 / 60.0)];
  } else if (mode == 2) {
    /* Frame-skip gating lives in _MetalLayer_nextDrawable (nil return);
     * only real, ≥18ms-spaced frames reach here. */
    madeira_log_present_cadence("presentRaw", 0.0);
    [(id<MTLCommandBuffer>)params->handle presentDrawable:(id<MTLDrawable>)params->arg];
  } else {
    madeira_log_present_cadence("presentDrawable", 0.0);
    [(id<MTLCommandBuffer>)params->handle presentDrawable:(id<MTLDrawable>)params->arg];
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_presentDrawableAfterMinimumDuration(void *obj) {
  struct unixcall_generic_obj_obj_double_noret *params = obj;
  madeira_log_present_cadence("presentDrawableAfterMinDuration", params->arg1);
  [(id<MTLCommandBuffer>)params->handle presentDrawable:(id<MTLDrawable>)params->arg0
                                   afterMinimumDuration:params->arg1];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_supportsFamily(void *obj) {
  struct unixcall_generic_obj_uint64_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle_u64 a = { params->handle, params->arg };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_SUPPORTS_FAMILY, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle supportsFamily:(MTLGPUFamily)params->arg];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_supportsBCTextureCompression(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_SUPPORTS_BC, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle supportsBCTextureCompression];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_supportsTextureSampleCount(void *obj) {
  struct unixcall_generic_obj_uint64_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle_u64 a = { params->handle, params->arg };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_SUPPORTS_SAMPLE_COUNT, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle supportsTextureSampleCount:params->arg];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_hasUnifiedMemory(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_DEVICE_UNIFIED_MEM, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle hasUnifiedMemory];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCaptureManager_sharedCaptureManager(void *obj) {
  struct unixcall_generic_obj_ret *params = obj;
  params->ret = (obj_handle_t)[MTLCaptureManager sharedCaptureManager];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCaptureManager_startCapture(void *obj) {
  struct unixcall_mtlcapturemanager_startcapture *params = obj;
  MTLCaptureDescriptor *desc = [[MTLCaptureDescriptor alloc] init];
  const struct WMTCaptureInfo *info = params->info.ptr;
  desc.destination = (MTLCaptureDestination)info->destination;
  desc.captureObject = (id)info->capture_object;
  NSString *path_str = [[NSString alloc] initWithCString:info->output_url.ptr encoding:NSUTF8StringEncoding];
  NSURL *url = [[NSURL alloc] initFileURLWithPath:path_str];
  desc.outputURL = url;
  [(MTLCaptureManager *)params->capture_manager startCaptureWithDescriptor:desc error:nil];
  [url release];
  [path_str release];
  [desc release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCaptureManager_stopCapture(void *obj) {
  struct unixcall_generic_obj_noret *params = obj;
  [(MTLCaptureManager *)params->handle stopCapture];
  return STATUS_SUCCESS;
}

#include <signal.h>

void
temp_handler(int signum) {
  fprintf(stderr, "received signal %d in temp_handler(), and it may cause problem!\n", signum);
}

static const int SIGNALS[] = {
    SIGHUP,
    SIGINT,
    SIGTERM,
    SIGUSR2,
    SIGILL,
    SIGTRAP,
    SIGABRT,
    SIGFPE,
    SIGBUS,
    SIGSEGV,
    SIGQUIT
#ifdef SIGSYS
    ,
    SIGSYS
#endif
#ifdef SIGXCPU
    ,
    SIGXCPU
#endif
#ifdef SIGXFSZ
    ,
    SIGXFSZ
#endif
#ifdef SIGEMT
    ,
    SIGEMT
#endif
    ,
    SIGUSR1
#ifdef SIGINFO
    ,
    SIGINFO
#endif
};

static NTSTATUS
_MTLDevice_newTemporalScaler(void *obj) {
  struct unixcall_mtldevice_newfxtemporalscaler *params = obj;
  MTLFXTemporalScalerDescriptor *desc = [[MTLFXTemporalScalerDescriptor alloc] init];
  const struct WMTFXTemporalScalerInfo *info = params->info.ptr;
  desc.colorTextureFormat = to_metal_pixel_format(info->color_format);
  desc.outputTextureFormat = to_metal_pixel_format(info->output_format);
  desc.depthTextureFormat = to_metal_pixel_format(info->depth_format);
  desc.motionTextureFormat = to_metal_pixel_format(info->motion_format);
  desc.inputWidth = info->input_width;
  desc.inputHeight = info->input_height;
  desc.outputWidth = info->output_width;
  desc.outputHeight = info->output_height;
  desc.inputContentMaxScale = info->input_content_max_scale;
  desc.inputContentMinScale = info->input_content_min_scale;
  desc.inputContentPropertiesEnabled = info->input_content_properties_enabled;
  #if __MAC_OS_X_VERSION_MAX_ALLOWED >= 150000
  if (@available(macOS 15, *)) {
    desc.requiresSynchronousInitialization = info->requires_synchronous_initialization;
  }
  #endif
  desc.autoExposureEnabled = info->auto_exposure;

  struct sigaction old_action[sizeof(SIGNALS) / sizeof(int)], new_action;
  if (@available(macOS 16, *)) {} else {
    new_action.sa_handler = temp_handler;
    sigemptyset(&new_action.sa_mask);
    new_action.sa_flags = 0;
    for (unsigned int i = 0; i < sizeof(SIGNALS) / sizeof(int); i++)
      sigaction(SIGNALS[i], &new_action, &old_action[i]);
  }

  params->ret = (obj_handle_t)[desc newTemporalScalerWithDevice:(id<MTLDevice>)params->device];

  if (@available(macOS 16, *)) {} else {
    for (unsigned int i = 0; i < sizeof(SIGNALS) / sizeof(int); i++)
      sigaction(SIGNALS[i], &old_action[i], NULL);
  }

  [desc release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newSpatialScaler(void *obj) {
  struct unixcall_mtldevice_newfxspatialscaler *params = obj;
  MTLFXSpatialScalerDescriptor *desc = [[MTLFXSpatialScalerDescriptor alloc] init];
  const struct WMTFXSpatialScalerInfo *info = params->info.ptr;
  desc.colorTextureFormat = to_metal_pixel_format(info->color_format);
  desc.outputTextureFormat = to_metal_pixel_format(info->output_format);
  desc.inputWidth = info->input_width;
  desc.inputHeight = info->input_height;
  desc.outputWidth = info->output_width;
  desc.outputHeight = info->output_height;
  params->ret = (obj_handle_t)[desc newSpatialScalerWithDevice:(id<MTLDevice>)params->device];
  [desc release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_encodeTemporalScale(void *obj) {
  struct unixcall_mtlcommandbuffer_temporal_scale *params = obj;
  id<MTLCommandBuffer> cmdbuf = (id<MTLCommandBuffer>)params->cmdbuf;
  id<MTLFXTemporalScaler> scaler = (id<MTLFXTemporalScaler>)params->scaler;
  scaler.colorTexture = (id<MTLTexture>)params->color;
  scaler.outputTexture = (id<MTLTexture>)params->output;
  scaler.depthTexture = (id<MTLTexture>)params->depth;
  scaler.motionTexture = (id<MTLTexture>)params->motion;
  scaler.exposureTexture = (id<MTLTexture>)params->exposure;
  scaler.fence = (id<MTLFence>)params->fence;
  const struct WMTFXTemporalScalerProps *props = params->props.ptr;
  scaler.inputContentWidth = props->input_content_width;
  scaler.inputContentHeight = props->input_content_height;
  scaler.reset = props->reset;
  scaler.depthReversed = props->depth_reversed;
  scaler.motionVectorScaleX = props->motion_vector_scale_x;
  scaler.motionVectorScaleY = props->motion_vector_scale_y;
  scaler.jitterOffsetX = props->jitter_offset_x;
  scaler.jitterOffsetY = props->jitter_offset_y;
  scaler.preExposure = props->pre_exposure;
  [scaler encodeToCommandBuffer:cmdbuf];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_encodeSpatialScale(void *obj) {
  struct unixcall_mtlcommandbuffer_spatial_scale *params = obj;
  id<MTLCommandBuffer> cmdbuf = (id<MTLCommandBuffer>)params->cmdbuf;
  id<MTLFXSpatialScaler> scaler = (id<MTLFXSpatialScaler>)params->scaler;
  scaler.colorTexture = (id<MTLTexture>)params->color;
  scaler.outputTexture = (id<MTLTexture>)params->output;
  scaler.fence = (id<MTLFence>)params->fence;
  [scaler encodeToCommandBuffer:cmdbuf];
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSString_string(void *obj) {
  struct unixcall_nsstring_string *params = obj;
  NSString *str = [NSString stringWithCString:params->buffer_ptr.ptr encoding:(NSStringEncoding)params->encoding];
  params->ret = (obj_handle_t)str;
  return STATUS_SUCCESS;
}

static NTSTATUS
_NSString_alloc_init(void *obj) {
  struct unixcall_nsstring_string *params = obj;
  NSString *str = [[NSString alloc] initWithCString:params->buffer_ptr.ptr encoding:(NSStringEncoding)params->encoding];
  params->ret = (obj_handle_t)str;
  return STATUS_SUCCESS;
}

static NTSTATUS
_DeveloperHUDProperties_instance(void *obj) {
  struct unixcall_generic_obj_ret *params = obj;
  params->ret =
      (obj_handle_t)((id(*)(id, SEL))objc_msgSend)(objc_lookUpClass("_CADeveloperHUDProperties"), @selector(instance));
  return STATUS_SUCCESS;
}

static NTSTATUS
_DeveloperHUDProperties_addLabel(void *obj) {
  struct unixcall_generic_obj_obj_obj_uint64_ret *params = obj;
  params->ret = ((bool (*)(id, SEL, id, id)
  )objc_msgSend)((id)params->handle, @selector(addLabel:after:), (id)params->arg0, (id)params->arg1);
  return STATUS_SUCCESS;
}

static NTSTATUS
_DeveloperHUDProperties_updateLabel(void *obj) {
  struct unixcall_generic_obj_obj_obj_noret *params = obj;
  ((void (*)(id, SEL, id, id)
  )objc_msgSend)((id)params->handle, @selector(updateLabel:value:), (id)params->arg0, (id)params->arg1);
  return STATUS_SUCCESS;
}

static NTSTATUS
_DeveloperHUDProperties_remove(void *obj) {
  struct unixcall_generic_obj_obj_noret *params = obj;
  ((void (*)(id, SEL, id))objc_msgSend)((id)params->handle, @selector(remove:), (id)params->arg);
  return STATUS_SUCCESS;
}

static NTSTATUS
_MetalDrawable_texture(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  if (wmtr_enabled()) {
    /* Already known from the nextDrawable reply -- no round trip needed. */
    params->ret = wmtr_pair_texture(params->handle);
    if (!params->ret)
      fprintf(stderr, "[wmt-remote] texture asked for an unknown drawable 0x%llx\n",
              (unsigned long long)params->handle);
    return STATUS_SUCCESS;
  }
  params->ret = (obj_handle_t)[(id<CAMetalDrawable>)params->handle texture];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MetalLayer_nextDrawable(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_ret_drawable r;
    params->ret = 0;
    if (wmtr_call(RM_OP_NEXT_DRAWABLE, 0, 0, &r, sizeof r, 0) == RM_OK && r.drawable) {
      wmtr_pair_record(r.drawable, r.texture);
      params->ret = r.drawable;
    } else {
      /* Silent before. A frame with no drawable is drawn nowhere and shows as
       * a black flash, so it has to be counted rather than inferred. */
      static unsigned long missed;
      if (++missed <= 4 || (missed % 256) == 0)
        fprintf(stderr, "[wmt-remote] no drawable from the host (%lu times) -- this frame "
                        "will be blank\n", missed);
    }
    return STATUS_SUCCESS;
  }
  /* iOS-Madeira 2026-07-05 RAW mode (mode 2): the mailbox skip lives HERE,
   * before any drawable is consumed. First attempt gated at the
   * presentDrawable thunk — too late: every game frame had already
   * acquired a drawable, and PRESENTED drawables are held until vsync,
   * so a hot-capped 60Hz panel exhausted the 3-drawable pool and
   * throttled "unlocked" RAW right back to 60 (observed 02:35 run).
   * Returning nil here = no drawable touched, no block anywhere; the
   * PE side (Presenter::encodeCommands / flushCommands) skips the blit
   * and present on nil. Real acquires are spaced ≥18ms so presented
   * drawables can never exhaust the pool even on a 60Hz-capped panel.
   * Skipped frames tick the present counter so the FPS overlay shows
   * TRUE game rate. */
  if (g_madeira_vsync_mode == 2) {
    static struct timespec last_acquire; /* encode-thread only */
    struct timespec now;
    double since;
    clock_gettime(CLOCK_MONOTONIC, &now);
    since = (now.tv_sec - last_acquire.tv_sec) + (now.tv_nsec - last_acquire.tv_nsec) / 1e9;
    if (since < 0.018) {
      params->ret = 0;
      madeira_log_present_cadence("presentSkipped", 0.0);
      return STATUS_SUCCESS;
    }
    last_acquire = now;
  }
  /* 2026-07-03: measure blocking time. When queued presentations never
   * complete (render server not compositing the layer), all 3 pool
   * drawables stay owned by the presentation queue and this call blocks
   * its full 1s timeout — the observed ~1 present/s black-screen pacing. */
  struct timespec t0, t1;
  clock_gettime(CLOCK_MONOTONIC, &t0);
  params->ret = (obj_handle_t)[(CAMetalLayer *)params->handle nextDrawable];
  clock_gettime(CLOCK_MONOTONIC, &t1);
  double ms = (t1.tv_sec - t0.tv_sec) * 1000.0 + (t1.tv_nsec - t0.tv_nsec) / 1e6;
  static _Atomic uint64_t nd_total = 0, nd_slow = 0;
  uint64_t n = atomic_fetch_add_explicit(&nd_total, 1, memory_order_relaxed) + 1;
  if (ms > 50.0) {
    uint64_t s = atomic_fetch_add_explicit(&nd_slow, 1, memory_order_relaxed) + 1;
    if (s <= 16 || (s % 64) == 0)
      dprintf(STDERR_FILENO, "[iOS DXMT] nextDrawable #%llu BLOCKED %.0fms (nil=%d slow_total=%llu)\n",
              (unsigned long long)n, ms, params->ret == 0, (unsigned long long)s);
  } else if (n <= 8) {
    dprintf(STDERR_FILENO, "[iOS DXMT] nextDrawable #%llu took %.2fms\n", (unsigned long long)n, ms);
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_supportsFXSpatialScaler(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  params->ret = [MTLFXSpatialScalerDescriptor supportsDevice:(id<MTLDevice>)params->handle];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_supportsFXTemporalScaler(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  params->ret = [MTLFXTemporalScalerDescriptor supportsDevice:(id<MTLDevice>)params->handle];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MetalLayer_setProps(void *obj) {
  struct unixcall_generic_obj_constptr_noret *params = obj;
  if (wmtr_enabled()) {
    uint8_t buf[sizeof(struct rm_wmt_info) + sizeof(struct WMTLayerProps)];
    struct rm_wmt_info *w = (void *)buf;
    w->owner = params->handle; w->info_len = sizeof(struct WMTLayerProps); w->extra_count = 0;
    memcpy(buf + sizeof *w, params->arg.ptr, sizeof(struct WMTLayerProps));
    wmtr_call(RM_OP_LAYER_SET_PROPS, buf, sizeof buf, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  CAMetalLayer *layer = (CAMetalLayer *)params->handle;
  const struct WMTLayerProps *props = params->arg.ptr;
  execute_on_main(^{
    layer.device = (id<MTLDevice>)props->device;
    layer.opaque = props->opaque;
    layer.framebufferOnly = props->framebuffer_only;
    layer.contentsScale = props->contents_scale;
#if !TARGET_OS_IOS
    layer.displaySyncEnabled = props->display_sync_enabled;
#endif
    layer.drawableSize = CGSizeMake(props->drawable_width, props->drawable_height);
    layer.pixelFormat = to_metal_pixel_format(props->pixel_format);
  });
  return STATUS_SUCCESS;
}

static NTSTATUS
_MetalLayer_getProps(void *obj) {
  struct unixcall_generic_obj_ptr_noret *params = obj;
  if (wmtr_enabled()) {
    struct WMTLayerProps got;
    if (wmtr_call(RM_OP_LAYER_GET_PROPS, 0, 0, &got, sizeof got, 0) == RM_OK) {
      /* The device stays the guest's own handle: the host's layer.device is a
       * host object and returning it would put an untagged id in guest hands. */
      obj_handle_t keep = ((struct WMTLayerProps *)params->arg.ptr)->device;
      memcpy(params->arg.ptr, &got, sizeof got);
      ((struct WMTLayerProps *)params->arg.ptr)->device = keep;
    }
    return STATUS_SUCCESS;
  }
  CAMetalLayer *layer = (CAMetalLayer *)params->handle;
  struct WMTLayerProps *props = params->arg.ptr;
  props->device = (obj_handle_t)layer.device;
  props->opaque = layer.opaque;
  props->framebuffer_only = layer.framebufferOnly;
  props->contents_scale = layer.contentsScale;
#if TARGET_OS_IOS
  props->display_sync_enabled = true; /* iOS always syncs to display refresh. */
#else
  props->display_sync_enabled = layer.displaySyncEnabled;
#endif
  props->drawable_height = layer.drawableSize.height;
  props->drawable_width = layer.drawableSize.width;
  props->pixel_format = layer.pixelFormat;
  return STATUS_SUCCESS;
}

typedef struct macdrv_opaque_metal_device *macdrv_metal_device;
typedef struct macdrv_opaque_metal_view *macdrv_metal_view;
typedef struct macdrv_opaque_metal_layer *macdrv_metal_layer;
typedef struct macdrv_opaque_view *macdrv_view;
typedef struct macdrv_opaque_window *macdrv_window;
typedef struct macdrv_opaque_window_data *macdrv_window_data;
typedef struct opaque_window_surface *window_surface;
typedef struct opaque_HWND *HWND;
struct macdrv_win_data {
  HWND hwnd; /* hwnd that this private data belongs to */
  macdrv_window cocoa_window;
  macdrv_view cocoa_view;
  macdrv_view client_cocoa_view;
};

struct macdrv_functions_t {
  void (*macdrv_init_display_devices)(BOOL);
  struct macdrv_win_data *(*get_win_data)(HWND hwnd);
  void (*release_win_data)(struct macdrv_win_data *data);
  macdrv_window (*macdrv_get_cocoa_window)(HWND hwnd, BOOL require_on_screen);
  macdrv_metal_device (*macdrv_create_metal_device)(void);
  void (*macdrv_release_metal_device)(macdrv_metal_device d);
  macdrv_metal_view (*macdrv_view_create_metal_view)(macdrv_view v, macdrv_metal_device d);
  macdrv_metal_layer (*macdrv_view_get_metal_layer)(macdrv_metal_view v);
  void (*macdrv_view_release_metal_view)(macdrv_metal_view v);
  void (*on_main_thread)(dispatch_block_t b);
};

static NTSTATUS
_CreateMetalViewFromHWND(void *obj) {
  struct unixcall_create_metal_view_from_hwnd *params = obj;
  if (wmtr_enabled()) {
    /* The HWND names a window in the GUEST's windowing system and is not sent.
     * The surface that gets presented is the host's own layer, which is what
     * the guest actually needs in order to acquire drawables. */
    struct rm_arg_handle a = { params->device };
    struct rm_ret_view r;
    if (wmtr_call(RM_OP_CREATE_VIEW, &a, sizeof a, &r, sizeof r, 0) == RM_OK) {
      params->ret_view = r.view;
      params->ret_layer = r.layer;
    } else {
      params->ret_view = 0; params->ret_layer = 0;
      fprintf(stderr, "[wmt-remote] host refused to bind a view\n");
    }
    return STATUS_SUCCESS;
  }

  struct macdrv_win_data *(*pfn_get_win_data)(HWND hwnd) = NULL;
  void (*pfn_release_win_data)(struct macdrv_win_data *data) = NULL;
  macdrv_metal_view (*pfn_macdrv_view_create_metal_view)(macdrv_view v, macdrv_metal_device d) = NULL;
  macdrv_metal_layer (*pfn_macdrv_view_get_metal_layer)(macdrv_metal_view v) = NULL;

  struct macdrv_functions_t *macdrv_functions;
  if ((macdrv_functions = dlsym(RTLD_DEFAULT, "macdrv_functions"))) {
    pfn_get_win_data = macdrv_functions->get_win_data;
    pfn_release_win_data = macdrv_functions->release_win_data;
    pfn_macdrv_view_create_metal_view = macdrv_functions->macdrv_view_create_metal_view;
    pfn_macdrv_view_get_metal_layer = macdrv_functions->macdrv_view_get_metal_layer;
  } else {
    pfn_get_win_data = dlsym(RTLD_DEFAULT, "get_win_data");
    pfn_release_win_data = dlsym(RTLD_DEFAULT, "release_win_data");
    pfn_macdrv_view_create_metal_view = dlsym(RTLD_DEFAULT, "macdrv_view_create_metal_view");
    pfn_macdrv_view_get_metal_layer = dlsym(RTLD_DEFAULT, "macdrv_view_get_metal_layer");
  }

  if (pfn_get_win_data && pfn_release_win_data && pfn_macdrv_view_create_metal_view &&
      pfn_macdrv_view_get_metal_layer) {
    struct macdrv_win_data *win_data = pfn_get_win_data((HWND)params->hwnd);
    macdrv_metal_view view =
        pfn_macdrv_view_create_metal_view(win_data->client_cocoa_view, (macdrv_metal_device)params->device);
    params->ret_view = (obj_handle_t)view;
    if (view) {
      params->ret_layer = (obj_handle_t)pfn_macdrv_view_get_metal_layer(view);
    }
    pfn_release_win_data(win_data);
  }

  return STATUS_SUCCESS;
}

static NTSTATUS
_ReleaseMetalView(void *obj) {
  struct unixcall_generic_obj_noret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    wmtr_call(RM_OP_RELEASE_VIEW, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }

  void (*pfn_macdrv_view_release_metal_view)(macdrv_metal_view v) = NULL;

  struct macdrv_functions_t *macdrv_functions;
  if ((macdrv_functions = dlsym(RTLD_DEFAULT, "macdrv_functions"))) {
    pfn_macdrv_view_release_metal_view = macdrv_functions->macdrv_view_release_metal_view;
  } else {
    pfn_macdrv_view_release_metal_view = dlsym(RTLD_DEFAULT, "macdrv_view_release_metal_view");
  }

  if (pfn_macdrv_view_release_metal_view)
    pfn_macdrv_view_release_metal_view((macdrv_metal_view)params->handle);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50Initialize(void *args) {
  struct sm50_initialize_params *params = args;

  params->ret =
      SM50Initialize(params->bytecode, params->bytecode_size, params->shader, params->reflection, params->error);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50Destroy(void *args) {
  struct sm50_destroy_params *params = args;

  SM50Destroy(params->shader);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50Compile(void *args) {
  struct sm50_compile_params *params = args;

  params->ret = SM50Compile(params->shader, params->args, params->func_name, params->bitcode, params->error);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50GetCompiledBitcode(void *args) {
  struct sm50_get_compiled_bitcode_params *params = args;

  SM50GetCompiledBitcode(params->bitcode, params->data_out);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50DestroyBitcode(void *args) {
  struct sm50_destroy_bitcode_params *params = args;

  SM50DestroyBitcode(params->bitcode);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50GetErrorMessage(void *args) {
  struct sm50_get_error_message_params *params = args;

  params->ret_size = SM50GetErrorMessage(params->error, params->buffer, params->buffer_size);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50FreeError(void *args) {
  struct sm50_free_error_params *params = args;

  SM50FreeError(params->error);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50CompileTessellationPipelineHull(void *args) {
  struct sm50_compile_tessellation_pipeline_hull_params *params = args;

  params->ret = SM50CompileTessellationPipelineHull(
      params->vertex, params->hull, params->hull_args, params->func_name, params->bitcode, params->error
  );

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50CompileTessellationPipelineDomain(void *args) {
  struct sm50_compile_tessellation_pipeline_domain_params *params = args;

  params->ret = SM50CompileTessellationPipelineDomain(
      params->hull, params->domain, params->domain_args, params->func_name, params->bitcode, params->error
  );

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50CompileGeometryPipelineVertex(void *args) {
  struct sm50_compile_geometry_pipeline_vertex_params *params = args;

  params->ret = SM50CompileGeometryPipelineVertex(
      params->vertex, params->geometry, params->vertex_args, params->func_name, params->bitcode, params->error
  );

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50CompileGeometryPipelineGeometry(void *args) {
  struct sm50_compile_geometry_pipeline_geometry_params *params = args;

  params->ret = SM50CompileGeometryPipelineGeometry(
      params->vertex, params->geometry, params->geometry_args, params->func_name, params->bitcode, params->error
  );

  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandEncoder_setLabel(void *args) {
  struct unixcall_generic_obj_obj_noret *params = args;
  if (wmtr_enabled()) {
    /* The label is a GUEST-LOCAL NSString (NSString_* stays local), so its
     * bytes travel; the encoder handle is already a host handle. */
    const char *lbl = params->arg ? [(NSString *)params->arg UTF8String] : NULL;
    size_t n = lbl ? strlen(lbl) : 0;
    if (n && n < 512) {
      uint8_t buf[sizeof(struct rm_arg_handle) + 512];
      struct rm_arg_handle *a = (void *)buf;
      a->handle = params->handle;
      memcpy(buf + sizeof *a, lbl, n);
      wmtr_call(RM_OP_SET_LABEL, buf, (uint32_t)(sizeof *a + n), 0, 0, 0);
    }
    return STATUS_SUCCESS;
  }
  [(id<MTLCommandEncoder>)params->handle setLabel:(NSString *)params->arg];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_setShouldMaximizeConcurrentCompilation(void *args) {
  struct unixcall_generic_obj_uint64_noret *params = args;
  /* Skipped on iOS below because the selector raises there -- but in remote
   * mode the device lives on macOS, where it is both valid and useful. */
  if (wmtr_enabled()) {
    struct rm_arg_handle_u64 a = { params->handle, params->arg };
    wmtr_call(RM_OP_DEVICE_SET_MAXCC, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
#if !TARGET_OS_IOS
  [(id<MTLDevice>)params->handle setShouldMaximizeConcurrentCompilation:(BOOL)params->arg];
#else
  /* setShouldMaximizeConcurrentCompilation: is macOS-only — iOS MTLDevice
   * raises an ObjC exception if we call it. Skip. */
  (void)params;
#endif
  return STATUS_SUCCESS;
}

static NTSTATUS
thunk_SM50GetArgumentsInfo(void *args) {
  struct sm50_get_arguments_info_params *params = args;
  SM50GetArgumentsInfo(params->shader, params->constant_buffers, params->arguments);
  return STATUS_SUCCESS;
}

static inline void *
UInt32ToPtr(uint32_t v) {
  return (void *)(uint64_t)v;
}

#ifndef DXMT_NATIVE

static NTSTATUS
thunk32_SM50Initialize(void *args) {
  struct sm50_initialize_params32 *params = args;

  params->ret = SM50Initialize(
      UInt32ToPtr(params->bytecode), params->bytecode_size, UInt32ToPtr(params->shader),
      UInt32ToPtr(params->reflection), UInt32ToPtr(params->error)
  );

  return STATUS_SUCCESS;
}

struct SM50_SHADER_EMULATE_VERTEX_STREAM_OUTPUT_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
  uint32_t num_output_slots;
  uint32_t num_elements;
  uint32_t strides[4];
  uint32_t elements;
};

struct SM50_SHADER_COMMON_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
  enum SM50_SHADER_METAL_VERSION metal_version;
};

struct SM50_SHADER_COMPILATION_ARGUMENT_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
};

struct SM50_SHADER_IA_INPUT_LAYOUT_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
  enum SM50_INDEX_BUFFER_FORAMT index_buffer_format;
  uint32_t slot_mask;
  uint32_t num_elements;
  uint32_t elements;
};

struct SM50_SHADER_PSO_PIXEL_SHADER_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
  uint32_t sample_mask;
  bool dual_source_blending;
  bool disable_depth_output;
  uint32_t unorm_output_reg_mask;
};

struct SM50_SHADER_GS_PASS_THROUGH_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
  union {
    struct MTL_GEOMETRY_SHADER_PASS_THROUGH Data;
    uint32_t DataEncoded;
  };
  bool RasterizationDisabled;
};

struct SM50_SHADER_PSO_GEOMETRY_SHADER_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
  bool strip_topology;
};

struct SM50_SHADER_PSO_TESSELLATOR_DATA32 {
  uint32_t next;
  enum SM50_SHADER_COMPILATION_ARGUMENT_TYPE type;
  uint32_t max_potential_tess_factor;
};

void
sm50_compilation_argument32_convert(
    struct SM50_SHADER_COMPILATION_ARGUMENT_DATA *first_arg, struct SM50_SHADER_COMPILATION_ARGUMENT_DATA32 *args32
) {
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA *last_arg = first_arg;

  first_arg->type = SM50_SHADER_ARGUMENT_TYPE_MAX;
  first_arg->next = NULL;

  while (args32) {
    switch (args32->type) {
    case SM50_SHADER_EMULATE_VERTEX_STREAM_OUTPUT: {
      struct SM50_SHADER_EMULATE_VERTEX_STREAM_OUTPUT_DATA32 *src = (void *)args32;
      struct SM50_SHADER_EMULATE_VERTEX_STREAM_OUTPUT_DATA *data =
          malloc(sizeof(struct SM50_SHADER_EMULATE_VERTEX_STREAM_OUTPUT_DATA));
      last_arg->next = data;
      last_arg = (void *)data;
      last_arg->next = NULL;
      data->type = src->type;
      data->num_output_slots = src->num_output_slots;
      data->num_elements = src->num_elements;
      data->strides[0] = src->strides[0];
      data->strides[1] = src->strides[1];
      data->strides[2] = src->strides[2];
      data->strides[3] = src->strides[3];
      data->elements = UInt32ToPtr(src->elements);
      break;
    }
    case SM50_SHADER_COMMON: {
      struct SM50_SHADER_COMMON_DATA32 *src = (void *)args32;
      struct SM50_SHADER_COMMON_DATA *data = malloc(sizeof(struct SM50_SHADER_COMMON_DATA));
      last_arg->next = data;
      last_arg = (void *)data;
      last_arg->next = NULL;
      data->type = src->type;
      data->metal_version = src->metal_version;
      break;
    }
    case SM50_SHADER_PSO_PIXEL_SHADER: {
      struct SM50_SHADER_PSO_PIXEL_SHADER_DATA32 *src = (void *)args32;
      struct SM50_SHADER_PSO_PIXEL_SHADER_DATA *data = malloc(sizeof(struct SM50_SHADER_PSO_PIXEL_SHADER_DATA));
      last_arg->next = data;
      last_arg = (void *)data;
      last_arg->next = NULL;
      data->type = src->type;
      data->unorm_output_reg_mask = src->unorm_output_reg_mask;
      data->disable_depth_output = src->disable_depth_output;
      data->sample_mask = src->sample_mask;
      data->dual_source_blending = src->dual_source_blending;
      break;
    }
    case SM50_SHADER_IA_INPUT_LAYOUT: {
      struct SM50_SHADER_IA_INPUT_LAYOUT_DATA32 *src = (void *)args32;
      struct SM50_SHADER_IA_INPUT_LAYOUT_DATA *data = malloc(sizeof(struct SM50_SHADER_IA_INPUT_LAYOUT_DATA));
      last_arg->next = data;
      last_arg = (void *)data;
      last_arg->next = NULL;
      data->type = src->type;
      data->slot_mask = src->slot_mask;
      data->index_buffer_format = src->index_buffer_format;
      data->num_elements = src->num_elements;
      data->elements = UInt32ToPtr(src->elements);
      break;
    }
    case SM50_SHADER_GS_PASS_THROUGH: {
      struct SM50_SHADER_GS_PASS_THROUGH_DATA32 *src = (void *)args32;
      struct SM50_SHADER_GS_PASS_THROUGH_DATA *data = malloc(sizeof(struct SM50_SHADER_GS_PASS_THROUGH_DATA));
      last_arg->next = data;
      last_arg = (void *)data;
      last_arg->next = NULL;
      data->type = src->type;
      data->Data = src->Data;
      data->RasterizationDisabled = src->RasterizationDisabled;
      break;
    }
    case SM50_SHADER_PSO_GEOMETRY_SHADER: {
      struct SM50_SHADER_PSO_GEOMETRY_SHADER_DATA32 *src = (void *)args32;
      struct SM50_SHADER_PSO_GEOMETRY_SHADER_DATA *data = malloc(sizeof(struct SM50_SHADER_PSO_GEOMETRY_SHADER_DATA));
      last_arg->next = data;
      last_arg = (void *)data;
      last_arg->next = NULL;
      data->type = src->type;
      data->strip_topology = src->strip_topology;
      break;
    }
    case SM50_SHADER_PSO_TESSELLATOR: {
      struct SM50_SHADER_PSO_TESSELLATOR_DATA32 *src = (void *)args32;
      struct SM50_SHADER_PSO_TESSELLATOR_DATA *data = malloc(sizeof(struct SM50_SHADER_PSO_TESSELLATOR_DATA));
      last_arg->next = data;
      last_arg = (void *)data;
      last_arg->next = NULL;
      data->type = src->type;
      data->max_potential_tess_factor = src->max_potential_tess_factor;
      break;
    }
    case SM50_SHADER_ARGUMENT_TYPE_MAX:
      break;
    }
    args32 = UInt32ToPtr(args32->next);
  }
}

void
sm50_compilation_argument32_free(struct SM50_SHADER_COMPILATION_ARGUMENT_DATA *first_arg) {
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA *arg = first_arg->next;

  while (arg) {
    struct SM50_SHADER_COMPILATION_ARGUMENT_DATA *next = arg->next;
    free(arg);
    arg = next;
  }
}

static NTSTATUS
thunk32_SM50Compile(void *args) {
  struct sm50_compile_params32 *params = args;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA first_arg;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA32 *args32 = UInt32ToPtr(params->args);
  sm50_compilation_argument32_convert(&first_arg, args32);

  params->ret = SM50Compile(
      params->shader, &first_arg, UInt32ToPtr(params->func_name), UInt32ToPtr(params->bitcode),
      UInt32ToPtr(params->error)
  );

  sm50_compilation_argument32_free(&first_arg);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk32_SM50GetCompiledBitcode(void *args) {
  struct sm50_get_compiled_bitcode_params32 *params = args;

  SM50GetCompiledBitcode(params->bitcode, UInt32ToPtr(params->data_out));

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk32_SM50GetErrorMessage(void *args) {
  struct sm50_get_error_message_params32 *params = args;

  params->ret_size = SM50GetErrorMessage(params->error, UInt32ToPtr(params->buffer), params->buffer_size);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk32_SM50CompileTessellationPipelineHull(void *args) {
  struct sm50_compile_tessellation_pipeline_hull_params32 *params = args;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA first_arg;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA32 *args32 = UInt32ToPtr(params->hull_args);
  sm50_compilation_argument32_convert(&first_arg, args32);

  params->ret = SM50CompileTessellationPipelineHull(
      params->vertex, params->hull, &first_arg, UInt32ToPtr(params->func_name), UInt32ToPtr(params->bitcode),
      UInt32ToPtr(params->error)
  );

  sm50_compilation_argument32_free(&first_arg);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk32_SM50CompileTessellationPipelineDomain(void *args) {
  struct sm50_compile_tessellation_pipeline_domain_params32 *params = args;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA first_arg;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA32 *args32 = UInt32ToPtr(params->domain_args);
  sm50_compilation_argument32_convert(&first_arg, args32);

  params->ret = SM50CompileTessellationPipelineDomain(
      params->hull, params->domain, &first_arg, UInt32ToPtr(params->func_name), UInt32ToPtr(params->bitcode),
      UInt32ToPtr(params->error)
  );

  sm50_compilation_argument32_free(&first_arg);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk32_SM50CompileGeometryPipelineVertex(void *args) {
  struct sm50_compile_geometry_pipeline_vertex_params32 *params = args;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA first_arg;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA32 *args32 = UInt32ToPtr(params->vertex_args);
  sm50_compilation_argument32_convert(&first_arg, args32);

  params->ret = SM50CompileGeometryPipelineVertex(
      params->vertex, params->geometry, &first_arg, UInt32ToPtr(params->func_name), UInt32ToPtr(params->bitcode),
      UInt32ToPtr(params->error)
  );

  sm50_compilation_argument32_free(&first_arg);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk32_SM50CompileGeometryPipelineGeometry(void *args) {
  struct sm50_compile_geometry_pipeline_geometry_params32 *params = args;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA first_arg;
  struct SM50_SHADER_COMPILATION_ARGUMENT_DATA32 *args32 = UInt32ToPtr(params->geometry_args);
  sm50_compilation_argument32_convert(&first_arg, args32);

  params->ret = SM50CompileGeometryPipelineGeometry(
      params->vertex, params->geometry, &first_arg, UInt32ToPtr(params->func_name), UInt32ToPtr(params->bitcode),
      UInt32ToPtr(params->error)
  );

  sm50_compilation_argument32_free(&first_arg);

  return STATUS_SUCCESS;
}

static NTSTATUS
thunk32_SM50GetArgumentsInfo(void *args) {
  struct sm50_get_arguments_info_params32 *params = args;

  SM50GetArgumentsInfo(params->shader, UInt32ToPtr(params->constant_buffers), UInt32ToPtr(params->arguments));

  return STATUS_SUCCESS;
}
#endif /* DXMT_NATIVE */

static NTSTATUS
_MTLCommandBuffer_error(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  params->ret = (obj_handle_t)[(id<MTLCommandBuffer>)params->handle error];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLCommandBuffer_logs(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  params->ret = (obj_handle_t)[(id<MTLCommandBuffer>)params->handle logs];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLLogContainer_enumerate(void *obj) {
  struct unixcall_enumerate *params = obj;
  uint64_t count = 0;
  uint64_t read = 0;
  id *buffer = params->buffer.ptr;
  for (id _ in (id<MTLLogContainer>)params->enumeratable) {
    if (count >= params->start) {
      if (count < params->start + params->buffer_size) {
        buffer[count - params->start] = _;
        read++;
      } else {
        break;
      }
    }
    count++;
  }
  params->ret_read = read;
  return STATUS_SUCCESS;
}

CFStringRef
GetColorSpaceName(enum WMTColorSpace colorspace) {
  switch (colorspace) {
  case WMTColorSpaceSRGB:
    return kCGColorSpaceSRGB;
  case WMTColorSpaceSRGBLinear:
  case WMTColorSpaceHDR_scRGB:
    return kCGColorSpaceExtendedLinearSRGB;
  case WMTColorSpaceBT2020:
    return kCGColorSpaceITUR_2020_sRGBGamma;
  case WMTColorSpaceHDR_PQ:
    return kCGColorSpaceITUR_2100_PQ;
  default:
    return nil;
  }
}

static NTSTATUS
_CGColorSpace_checkColorSpaceSupported(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  params->ret = false;
  CFStringRef name = GetColorSpaceName((enum WMTColorSpace)params->handle);
  if (!name)
    return STATUS_SUCCESS;
  CGColorSpaceRef ref = CGColorSpaceCreateWithName(name);
  if (!ref)
    return STATUS_SUCCESS;
  CGColorSpaceRelease(ref);
  params->ret = true;
  return STATUS_SUCCESS;
}

static NTSTATUS
_MetalLayer_setColorSpace(void *obj) {
  struct unixcall_generic_obj_uint64_uint64_ret *params = obj;
  CAMetalLayer *layer = (CAMetalLayer *)params->handle;
  enum WMTColorSpace colorspace = params->arg;
  CFStringRef name = GetColorSpaceName(colorspace);
  params->ret = false;
  if (!name)
    return STATUS_SUCCESS;
  CGColorSpaceRef ref = CGColorSpaceCreateWithName(name);
  if (!ref)
    return STATUS_SUCCESS;
  execute_on_main(^{
    layer.colorspace = ref;
    layer.wantsExtendedDynamicRangeContent = WMT_COLORSPACE_IS_HDR(colorspace);
    CGColorSpaceRelease(ref);
  });
  params->ret = true;
  return STATUS_SUCCESS;
}

static NTSTATUS
_WMTGetPrimaryDisplayId(void *obj) {
  struct unixcall_generic_obj_ret *params = obj;
  params->ret = CGMainDisplayID();
  return STATUS_SUCCESS;
}

static NTSTATUS
_WMTGetSecondaryDisplayId(void *obj) {
  struct unixcall_generic_obj_ret *params = obj;
  params->ret = kCGNullDirectDisplay;

#if !TARGET_OS_IOS
  uint32_t count = 0;
  CGGetOnlineDisplayList(0, NULL, &count);

  if (count == 0)
    return STATUS_SUCCESS;

  CGDirectDisplayID main_display = CGMainDisplayID();
  CGDirectDisplayID displays[count];
  CGGetOnlineDisplayList(count, displays, &count);

  for (uint32_t i = 0; i < count; i++) {
    CGDirectDisplayID id = displays[i];
    if (id == main_display)
      continue;
    if (CGDisplayMirrorsDisplay(id) != kCGNullDirectDisplay)
      continue;
    params->ret = id;
    break;
  }
#endif

  return STATUS_SUCCESS;
}

#if !TARGET_OS_IOS
typedef struct icc_XYZ_t {
  uint32_t sig;      // 0x205a5958
  uint32_t reserved; // 0
  int32_t x;
  int32_t y;
  int32_t z;
} icc_XYZ_t;

bool
GetChromaticity_xy(ColorSyncProfileRef profile, CFStringRef tag, float *out_x, float *out_y) {
  CFDataRef tag_data = ColorSyncProfileCopyTag(profile, tag);
  if (!tag_data)
    return false;
  if (CFDataGetLength(tag_data) != sizeof(icc_XYZ_t))
    return false;
  icc_XYZ_t *data = (icc_XYZ_t *)CFDataGetBytePtr(tag_data);
  if (data->sig != 0x205a5958)
    return false;
  double X = (int32_t)__builtin_bswap32(data->x) / 65536.0;
  double Y = (int32_t)__builtin_bswap32(data->y) / 65536.0;
  double Z = (int32_t)__builtin_bswap32(data->z) / 65536.0;
  *out_x = X / (X + Y + Z);
  *out_y = Y / (X + Y + Z);
  return true;
}

bool
GetDisplayColorGamut(ColorSyncProfileRef profile, struct WMTDisplayDescription *desc_out) {
  return GetChromaticity_xy(
             profile, kColorSyncSigMediaWhitePointTag, &desc_out->white_points[0], &desc_out->white_points[1]
         ) &&
         GetChromaticity_xy(
             profile, kColorSyncSigRedColorantTag, &desc_out->red_primaries[0], &desc_out->red_primaries[1]
         ) &&
         GetChromaticity_xy(
             profile, kColorSyncSigGreenColorantTag, &desc_out->green_primaries[0], &desc_out->green_primaries[1]
         ) &&
         GetChromaticity_xy(
             profile, kColorSyncSigBlueColorantTag, &desc_out->blue_primaries[0], &desc_out->blue_primaries[1]
         );
}
#endif /* !TARGET_OS_IOS — end of ColorSync/NSScreen block */

#if !TARGET_OS_IOS
NSScreen *
GetNSScreenForDisplayID(CGDirectDisplayID display_id) {
  for (NSScreen *screen in [NSScreen screens]) {
    CGDirectDisplayID id = [[[screen deviceDescription] objectForKey:@"NSScreenNumber"] unsignedIntValue];
    if (id == display_id) {
      return screen;
    }
  }
  return nil;
}
#endif

static NTSTATUS
_WMTGetDisplayDescription(void *obj) {
  struct unixcall_generic_obj_ptr_noret *params = obj;
  struct WMTDisplayDescription *desc_out = params->arg.ptr;
#if TARGET_OS_IOS
  (void)params;
  desc_out->maximum_edr_color_component_value = 1.0;
  desc_out->maximum_reference_edr_color_component_value = 0.0;
  desc_out->maximum_potential_edr_color_component_value = 1.0;
#else
  CGDirectDisplayID display_id = params->handle;
  ColorSyncProfileRef profile = ColorSyncProfileCreateWithDisplayID(display_id);
  if (!profile || !GetDisplayColorGamut(profile, desc_out))
    GetDisplayColorGamut(ColorSyncProfileCreateWithName(kColorSyncGenericRGBProfile), desc_out);
  NSScreen *screen = GetNSScreenForDisplayID(display_id);
  if (screen) {
    desc_out->maximum_edr_color_component_value = [screen maximumExtendedDynamicRangeColorComponentValue];
    desc_out->maximum_reference_edr_color_component_value =
        [screen maximumReferenceExtendedDynamicRangeColorComponentValue];
    desc_out->maximum_potential_edr_color_component_value =
        [screen maximumPotentialExtendedDynamicRangeColorComponentValue];
  } else {
    desc_out->maximum_edr_color_component_value = 1.0;
    desc_out->maximum_reference_edr_color_component_value = 0.0;
    desc_out->maximum_potential_edr_color_component_value = 1.0;
  }
#endif
  return STATUS_SUCCESS;
}

struct DisplaySetting {
  uint64_t version;
  enum WMTColorSpace colorspace;
  struct WMTHDRMetadata hdr_metadata;
};

struct DisplaySetting g_display_settings[2] = {{0, 0, {}}, {0, 0, {}}};

static NTSTATUS
_MetalLayer_getEDRValue(void *obj) {
  struct unixcall_generic_obj_ptr_noret *params = obj;
  CAMetalLayer *layer = (CAMetalLayer *)params->handle;
  struct WMTEDRValue *value = params->arg.ptr;
  value->maximum_edr_color_component_value = 1.0;
  value->maximum_potential_edr_color_component_value = 1.0;

#if !TARGET_OS_IOS
  if (![layer.delegate isKindOfClass:NSView.class])
    return STATUS_SUCCESS;

  NSView *view = (NSView *)layer.delegate;
  if (!view.window)
    return STATUS_SUCCESS;

  if (!view.window.screen)
    return STATUS_SUCCESS;

  NSScreen *screen = view.window.screen;

  value->maximum_edr_color_component_value =
      layer.wantsExtendedDynamicRangeContent ? screen.maximumExtendedDynamicRangeColorComponentValue : 1.0;
  value->maximum_potential_edr_color_component_value = screen.maximumPotentialExtendedDynamicRangeColorComponentValue;
#endif

  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLLibrary_newFunctionWithConstants(void *obj) {
  struct unixcall_mtllibrary_newfunction_with_constants *params = obj;
  if (wmtr_enabled()) {
    /* Each constant's VALUE is inlined; the pointer inside WMTFunctionConstant
     * is a guest address and cannot cross. */
    const char *nm = (const char *)params->name.ptr;
    size_t nlen = nm ? strlen(nm) : 0;
    const struct WMTFunctionConstant *cs = params->constants.ptr;
    uint8_t buf[4096];
    struct rm_wmt_info *w = (void *)buf;
    size_t off = sizeof *w;
    params->ret = 0; params->ret_error = 0;
    if (nlen && off + nlen < sizeof buf) {
      memcpy(buf + off, nm, nlen); off += nlen;
      w->owner = params->library; w->info_len = (uint32_t)nlen; w->extra_count = 0;
      for (uint64_t k = 0; k < params->num_constants && cs; k++) {
        uint32_t vlen = wmt_const_size(cs[k].type);
        if (!vlen) { fprintf(stderr, "[wmt-remote] unknown function-constant type %u at index %u"
                                     " -- not sent\n", (unsigned)cs[k].type, cs[k].index); continue; }
        if (off + sizeof(struct rm_fn_const) + vlen > sizeof buf) break;
        struct rm_fn_const fc = { (uint16_t)cs[k].type, cs[k].index, vlen };
        memcpy(buf + off, &fc, sizeof fc); off += sizeof fc;
        memcpy(buf + off, cs[k].data.ptr, vlen); off += vlen;
        w->extra_count++;
      }
      struct rm_ret_handle r;
      if (wmtr_call(RM_OP_NEW_FUNCTION_CONSTS, buf, (uint32_t)off, &r, sizeof r, 0) == RM_OK)
        params->ret = r.handle;
    }
    return STATUS_SUCCESS;
  }
  id<MTLLibrary> library = (id<MTLLibrary>)params->library;
  NSString *name = [[NSString alloc] initWithCString:(char *)params->name.ptr encoding:NSUTF8StringEncoding];
  struct WMTFunctionConstant *constants = (struct WMTFunctionConstant *)params->constants.ptr;
  NSError *err = NULL;
  MTLFunctionConstantValues *values = [[MTLFunctionConstantValues alloc] init];
  for (uint64_t i = 0; i < params->num_constants; i++)
    [values setConstantValue:constants[i].data.ptr type:(MTLDataType)constants[i].type atIndex:constants[i].index];

  params->ret = (obj_handle_t)[library newFunctionWithName:name constantValues:values error:&err];
  params->ret_error = (obj_handle_t)err;
  [name release];
  [values release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_WMTQueryDisplaySetting(void *obj) {
  struct unixcall_query_display_setting *params = obj;
  CGDirectDisplayID display_id = params->display_id;
  struct WMTHDRMetadata *value = params->hdr_metadata.ptr;
  params->ret = false;
  struct DisplaySetting *setting = &g_display_settings[display_id == CGMainDisplayID()];
  if (setting->version) {
    *value = setting->hdr_metadata;
    params->colorspace = setting->colorspace;
    params->ret = true;
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_WMTUpdateDisplaySetting(void *obj) {
  struct unixcall_update_display_setting *params = obj;
  CGDirectDisplayID display_id = params->display_id;
  const struct WMTHDRMetadata *value = params->hdr_metadata.ptr;
  struct DisplaySetting *setting = &g_display_settings[display_id == CGMainDisplayID()];
  if (value) {
    setting->hdr_metadata = *value;
    setting->colorspace = params->colorspace;
    setting->version++;
  } else {
    setting->version = 0;
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_WMTQueryDisplaySettingForLayer(void *obj) {
  struct unixcall_query_display_setting_for_layer *params = obj;
  CAMetalLayer *layer = (CAMetalLayer *)params->layer;
  struct WMTHDRMetadata *hdr_metadata_out = params->hdr_metadata.ptr;

  params->version = 0;
#if TARGET_OS_IOS
  (void)layer;
  return STATUS_SUCCESS;
#else
  if (![layer.delegate isKindOfClass:NSView.class])
    return STATUS_SUCCESS;

  NSView *view = (NSView *)layer.delegate;
  if (!view.window)
    return STATUS_SUCCESS;

  if (!view.window.screen)
    return STATUS_SUCCESS;

  NSScreen *screen = view.window.screen;
  CGDirectDisplayID id = [[[screen deviceDescription] objectForKey:@"NSScreenNumber"] unsignedIntValue];

  struct DisplaySetting *setting = &g_display_settings[id == CGMainDisplayID()];
  *hdr_metadata_out = setting->hdr_metadata;
  params->version = setting->version;
  params->colorspace = setting->colorspace;
  params->edr_value.maximum_edr_color_component_value =
      layer.wantsExtendedDynamicRangeContent ? screen.maximumExtendedDynamicRangeColorComponentValue : 1.0;
  params->edr_value.maximum_potential_edr_color_component_value =
      screen.maximumPotentialExtendedDynamicRangeColorComponentValue;

  return STATUS_SUCCESS;
#endif
}

static NTSTATUS
_MTLCommandBuffer_encodeWaitForEvent(void *obj) {
  struct unixcall_generic_obj_obj_uint64_noret *params = obj;
  if (wmtr_enabled()) {
    struct rm_encode_sig a = { params->handle, params->arg0, params->arg1 };
    wmtr_call(RM_OP_ENCODE_WAIT, &a, sizeof a, 0, 0, 0);
    return STATUS_SUCCESS;
  }
  [(id<MTLCommandBuffer>)params->handle encodeWaitForEvent:(id<MTLSharedEvent>)params->arg0 value:params->arg1];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLSharedEvent_signalValue(void *obj) {
  struct unixcall_generic_obj_uint64_noret *params = obj;
  [(id<MTLSharedEvent>)params->handle setSignaledValue:params->arg];
  return STATUS_SUCCESS;
}

#ifndef DXMT_NATIVE

typedef struct {
  _Atomic(CFRunLoopRef) runloop_ref;
  MTLSharedEventListener *shared_listener;
} *shared_event_listener_t;

extern NTSTATUS NtSetEvent(void *handle, void *prev_state);

static NTSTATUS
_MTLSharedEvent_setWin32EventAtValue(void *obj) {
  struct unixcall_mtlsharedevent_setevent *params = obj;
  void *nt_event_handle = (shared_event_listener_t)params->event_handle;
  shared_event_listener_t q = (shared_event_listener_t)params->shared_event_listener;
  [(id<MTLSharedEvent>)params->shared_event
      notifyListener:q->shared_listener
             atValue:params->value
               block:^(id<MTLSharedEvent> _e, uint64_t _v) {
                 // NOTE: must ensure no more notification comes after listener been destroyed.
                 while (!atomic_load_explicit(&q->runloop_ref, memory_order_acquire)) {
#if defined(__x86_64__)
                   _mm_pause();
#elif defined(__aarch64__)
          __asm__ __volatile__("yield");
#endif
                 }
                 CFRunLoopPerformBlock(q->runloop_ref, kCFRunLoopCommonModes, ^{
                   NtSetEvent(nt_event_handle, NULL);
                 });
                 CFRunLoopWakeUp(q->runloop_ref);
               }];
  return STATUS_SUCCESS;
}

static NTSTATUS
_SharedEventListener_start(void *obj) {
  struct unixcall_generic_obj_noret *params = obj;
  shared_event_listener_t q = (shared_event_listener_t)params->handle;
  CFRunLoopRef uninited = NULL;
  if (q && atomic_compare_exchange_strong(&q->runloop_ref, &uninited, CFRunLoopGetCurrent())) {
    /* Add a dummy source so the runloop stays running */
    CFRunLoopSourceContext source_context = {0};
    CFRunLoopSourceRef source = CFRunLoopSourceCreate(NULL, 0, &source_context);
    CFRunLoopAddSource(q->runloop_ref, source, kCFRunLoopCommonModes);
    CFRunLoopRun();
  }
  return STATUS_SUCCESS;
}

static NTSTATUS
_SharedEventListener_create(void *obj) {
  struct unixcall_generic_obj_ret *params = obj;
  shared_event_listener_t q = malloc(sizeof(*q));
  if (q) {
    q->runloop_ref = NULL;
    q->shared_listener = [[MTLSharedEventListener alloc] init];
  }
  params->ret = (obj_handle_t)q;
  return STATUS_SUCCESS;
}

static NTSTATUS
_SharedEventListener_destroy(void *obj) {
  struct unixcall_generic_obj_noret *params = obj;
  shared_event_listener_t q = (shared_event_listener_t)params->handle;
  if (q && q->runloop_ref) {
    CFRunLoopStop(q->runloop_ref);
    q->runloop_ref = NULL;
    [q->shared_listener release];
    q->shared_listener = nil;
    free(q);
  }
  return STATUS_SUCCESS;
}

#else
static NTSTATUS
_MTLSharedEvent_setWin32EventAtValue(void *obj) {
  // nop
  return STATUS_SUCCESS;
}

static NTSTATUS
_SharedEventListener_start(void *obj) {
  return STATUS_SUCCESS;
}

static NTSTATUS
_SharedEventListener_create(void *obj) {
  return STATUS_SUCCESS;
}

static NTSTATUS
_SharedEventListener_destroy(void *obj) {
  return STATUS_SUCCESS;
}

#endif

static NTSTATUS
_MTLDevice_newFence(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  params->ret = (obj_handle_t)[(id<MTLDevice>)params->handle newFence];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newEvent(void *obj) {
  struct unixcall_generic_obj_obj_ret *params = obj;
  params->ret = (obj_handle_t)[(id<MTLDevice>)params->handle newEvent];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLBuffer_updateContents(void *obj) {
  struct unixcall_mtlbuffer_updatecontents *params = obj;
  if (wmtr_enabled()) {
    struct wmtr_buf *b = wmtr_buf_find(params->buffer);
    if (b && b->shadow && params->offset + params->length <= b->length) {
      memcpy((char *)b->shadow + params->offset, params->data.ptr, params->length);
      wmtr_buf_upload(params->buffer, (const char *)b->shadow + params->offset,
                      params->offset, params->length);
    } else if (!b) {
      fprintf(stderr, "[wmt-remote] updateContents on an unregistered buffer 0x%llx\n",
              (unsigned long long)params->buffer);
    }
    return STATUS_SUCCESS;
  }
  memcpy((void *)((char *)[(id<MTLBuffer>)params->buffer contents] + params->offset), params->data.ptr, params->length);
#if !TARGET_OS_IOS
  /* Managed storage mode doesn't exist on iOS (unified memory). */
  if ([(id<MTLBuffer>)params->buffer storageMode] == MTLStorageModeManaged)
    [(id<MTLBuffer>)params->buffer didModifyRange:NSMakeRange(params->offset, params->length)];
#endif
  return STATUS_SUCCESS;
}

static NTSTATUS
_WMTGetOSVersion(void *obj) {
  struct unixcall_get_os_version *params = obj;
  if (wmtr_enabled()) {
    struct rm_os_version v;
    if (wmtr_call(RM_OP_OS_VERSION, 0, 0, &v, sizeof v, 0) == RM_OK) {
      params->ret_major = v.major; params->ret_minor = v.minor; params->ret_patch = v.patch;
    } else {
      params->ret_major = params->ret_minor = params->ret_patch = 0;
    }
    return STATUS_SUCCESS;
  }
  NSOperatingSystemVersion version = [NSProcessInfo processInfo].operatingSystemVersion;
  params->ret_major = version.majorVersion;
  params->ret_minor = version.minorVersion;
  params->ret_patch = version.patchVersion;
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newBinaryArchive(void *obj) {
  struct unixcall_mtldevice_newbinaryarchive *params = obj;
  NSString *path_str = NULL;
  NSURL *url = NULL;
  MTLBinaryArchiveDescriptor *desc = [[MTLBinaryArchiveDescriptor alloc] init];
  if (params->url.ptr != NULL) {
    path_str = [[NSString alloc] initWithCString:params->url.ptr encoding:NSUTF8StringEncoding];
    url = [[NSURL alloc] initFileURLWithPath:path_str];
    desc.url = url;
  }
  NSError *err = NULL;
  params->ret_archive = (obj_handle_t)[(id<MTLDevice>)params->device newBinaryArchiveWithDescriptor:desc error:&err];
  params->ret_error = (obj_handle_t)err;
  [desc release];
  if (url)
    [url release];
  if (path_str)
    [path_str release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLBinaryArchive_serialize(void *obj) {
  struct unixcall_mtlbinaryarchive_serialize *params = obj;
  NSString *path_str = [[NSString alloc] initWithCString:params->url.ptr encoding:NSUTF8StringEncoding];
  NSURL *url = [[NSURL alloc] initFileURLWithPath:path_str];
  NSError *err = NULL;
  [(id<MTLBinaryArchive>)params->archive serializeToURL:url error:&err];
  params->ret_error = (obj_handle_t)err;
  [url release];
  [path_str release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_DispatchData_alloc_init(void *obj) {
  struct unixcall_generic_obj_uint64_obj_ret *params = obj;
  params->ret = (obj_handle_t)dispatch_data_create((void *)params->handle, params->arg, NULL, NULL);
  return STATUS_SUCCESS;
}

@interface MTLSharedTextureHandle ()

- (MTLSharedTextureHandle *)initWithMachPort:(mach_port_t)port;
- (mach_port_t)createMachPort;

@end

static NTSTATUS
_MTLDevice_newSharedTexture(void *obj) {
  struct unixcall_mtldevice_newtexture *params = obj;
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  struct WMTTextureInfo *info = params->info.ptr;

  if (info->mach_port) {
    MTLSharedTextureHandle *handle = [[MTLSharedTextureHandle alloc] initWithMachPort:info->mach_port];
    id<MTLTexture> ret = [device newSharedTextureWithHandle:handle];
    extract_texture_descriptor(ret, info);
    params->ret = (obj_handle_t)ret;
    info->gpu_resource_id = [ret gpuResourceID]._impl;
    [handle release];
  } else {
    MTLTextureDescriptor *desc = [[MTLTextureDescriptor alloc] init];
    fill_texture_descriptor(desc, info);
    id<MTLTexture> ret = [device newSharedTextureWithDescriptor:desc];
    MTLSharedTextureHandle *handle = [ret newSharedTextureHandle];
    params->ret = (obj_handle_t)ret;
    info->gpu_resource_id = [ret gpuResourceID]._impl;
    info->mach_port = [handle createMachPort]; // implicitly add ref to underlying IOSurface
    [handle release];
    [desc release];
  }

  return STATUS_SUCCESS;
}

/* Private API to register a mach port with the bootstrap server */
extern kern_return_t bootstrap_register2(mach_port_t bp, name_t service_name, mach_port_t sp, int flags);

static NTSTATUS
_WMTBootstrapRegister(void *obj) {
  struct unixcall_bootstrap *params = obj;
  mach_port_t rp = params->mach_port;
  mach_port_t bp;

  if (task_get_bootstrap_port(mach_task_self(), &bp) != KERN_SUCCESS)
    return STATUS_UNSUCCESSFUL;
  NTSTATUS ret = bootstrap_register2(bp, params->name, rp, 0) != KERN_SUCCESS ? STATUS_UNSUCCESSFUL : STATUS_SUCCESS;
  mach_port_deallocate(mach_task_self(), bp);
  return ret;
}

static NTSTATUS
_WMTBootstrapLookUp(void *obj) {
  struct unixcall_bootstrap *params = obj;
  mach_port_t rp = 0;
  mach_port_t bp;

  if (task_get_bootstrap_port(mach_task_self(), &bp) != KERN_SUCCESS)
    return STATUS_UNSUCCESSFUL;
  NTSTATUS ret = bootstrap_look_up(bp, params->name, &rp) != KERN_SUCCESS ? STATUS_UNSUCCESSFUL : STATUS_SUCCESS;
  mach_port_deallocate(mach_task_self(), bp);
  params->mach_port = rp;
  return ret;
}

@protocol MTLDeviceSPI <MTLDevice>

- (id<MTLSharedEvent>)newSharedEventWithMachPort:(mach_port_t)machPort;

@end

@interface MTLSharedEventHandle ()

- (mach_port_t)eventPort;

@end

static NTSTATUS
_MTLSharedEvent_createMachPort(void *obj) {
  struct unixcall_mtlsharedevent_createmachport *params = obj;
  id<MTLSharedEvent> event = (id<MTLSharedEvent>)params->event;
  MTLSharedEventHandle *handle = [event newSharedEventHandle];
  mach_port_t port = [handle eventPort];
  
  // The eventPort method returns a send right that's owned by the handle.
  // We need to add our own send right since we're keeping the port but releasing the handle.
  // This increments the send right count so the port remains valid.
  mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_SEND, 1);
  
  params->ret_mach_port = port;
  [handle release];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_newSharedEventWithMachPort(void *obj) {
  struct unixcall_mtldevice_newsharedeventwithmachport *params = obj;
  id<MTLDevice> device = (id<MTLDevice>)params->device;
  id<MTLDeviceSPI> deviceSPI = (id<MTLDeviceSPI>)device;
  params->ret_event = (obj_handle_t)[deviceSPI newSharedEventWithMachPort:params->mach_port];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLDevice_registryID(void *obj) {
  struct unixcall_generic_obj_uint64_ret *params = obj;
  if (wmtr_enabled()) {
    struct rm_arg_handle a = { params->handle };
    struct rm_ret_u64 r;
    params->ret = (wmtr_call(RM_OP_DEVICE_REGISTRY_ID, &a, sizeof a, &r, sizeof r, 0) == RM_OK) ? r.value : 0;
    return STATUS_SUCCESS;
  }
  params->ret = [(id<MTLDevice>)params->handle registryID];
  return STATUS_SUCCESS;
}

static NTSTATUS
_MTLSharedEvent_waitUntilSignaledValue(void *obj) {
  struct unixcall_mtlsharedevent_waituntilsignaledvalue *params = obj;
  bool timeout = [(id<MTLSharedEvent>)params->event waitUntilSignaledValue:params->value timeoutMS:params->timeout_ms];
  params->ret_timeout = timeout;
  return STATUS_SUCCESS;
}

/*
 * Definition from cache.c
 */

NTSTATUS _CacheReader_alloc_init(void *obj);
NTSTATUS _CacheReader_get(void *obj);
NTSTATUS _CacheWriter_alloc_init(void *obj);
NTSTATUS _CacheWriter_set(void *obj);
NTSTATUS _WMTSetMetalShaderCachePath(void *obj);

#if TARGET_OS_IOS
/* On iOS we statically link DXMT's unix side into the host app (Madeira.app),
 * alongside ntdll's own __wine_unix_call_funcs. Rename ours so the linker
 * doesn't get a duplicate symbol; our ntdll's load_builtin_unixlib picks
 * it up by name when a DLL registers winemetal.so as its unix path.        */
#define __wine_unix_call_funcs dxmt_winemetal_unix_call_funcs
#endif

#include "wmt_remote_guard.h"

const void *__wine_unix_call_funcs[] = {
    &_NSObject_retain,
    &_NSObject_release,
    &_NSArray_object,
    &_NSArray_count,
    &_MTLCopyAllDevices,
    &_MTLDevice_recommendedMaxWorkingSetSize,
    &_MTLDevice_currentAllocatedSize,
    &_MTLDevice_name,
    &_NSString_getCString,
    &_MTLDevice_newCommandQueue,
    &_NSAutoreleasePool_alloc_init,
    &_MTLCommandQueue_commandBuffer,
    &_MTLCommandBuffer_commit,
    &_MTLCommandBuffer_waitUntilCompleted,
    &_MTLCommandBuffer_status,
    &_MTLDevice_newSharedEvent,
    &_MTLSharedEvent_signaledValue,
    &_MTLCommandBuffer_encodeSignalEvent,
    &_MTLDevice_newBuffer,
    &_MTLDevice_newSamplerState,
    &_MTLDevice_newDepthStencilState,
    &_MTLDevice_newTexture,
    &_MTLBuffer_newTexture,
    &_MTLTexture_newTextureView,
    &_MTLDevice_minimumLinearTextureAlignmentForPixelFormat,
    &_MTLDevice_newLibrary,
    &_MTLLibrary_newFunction,
    &_NSString_lengthOfBytesUsingEncoding,
    &_rmg_NSObject_description,
    &_MTLDevice_newComputePipelineState,
    &_MTLCommandBuffer_blitCommandEncoder,
    &_rmg_MTLCommandBuffer_computeCommandEncoder,
    &_MTLCommandBuffer_renderCommandEncoder,
    &_MTLCommandEncoder_endEncoding,
    &_MTLDevice_newRenderPipelineState,
    &_rmg_MTLDevice_newMeshRenderPipelineState,
    &_MTLBlitCommandEncoder_encodeCommands,
    &_rmg_MTLComputeCommandEncoder_encodeCommands,
    &_MTLRenderCommandEncoder_encodeCommands,
    &_rmg_MTLTexture_pixelFormat,
    &_MTLTexture_width,
    &_MTLTexture_height,
    &_rmg_MTLTexture_depth,
    &_rmg_MTLTexture_arrayLength,
    &_rmg_MTLTexture_mipmapLevelCount,
    &_MTLTexture_replaceRegion,
    &_rmg_MTLBuffer_didModifyRange,
    &_MTLCommandBuffer_presentDrawable,
    &_rmg_MTLCommandBuffer_presentDrawableAfterMinimumDuration,
    &_MTLDevice_supportsFamily,
    &_MTLDevice_supportsBCTextureCompression,
    &_MTLDevice_supportsTextureSampleCount,
    &_MTLDevice_hasUnifiedMemory,
    &_rmg_MTLCaptureManager_sharedCaptureManager,
    &_rmg_MTLCaptureManager_startCapture,
    &_rmg_MTLCaptureManager_stopCapture,
    &_rmg_MTLDevice_newTemporalScaler,
    &_rmg_MTLDevice_newSpatialScaler,
    &_rmg_MTLCommandBuffer_encodeTemporalScale,
    &_rmg_MTLCommandBuffer_encodeSpatialScale,
    &_NSString_string,
    &_NSString_alloc_init,
    &_DeveloperHUDProperties_instance,
    &_DeveloperHUDProperties_addLabel,
    &_DeveloperHUDProperties_updateLabel,
    &_DeveloperHUDProperties_remove,
    &_MetalDrawable_texture,
    &_MetalLayer_nextDrawable,
    &_rmg_MTLDevice_supportsFXSpatialScaler,
    &_rmg_MTLDevice_supportsFXTemporalScaler,
    &_MetalLayer_setProps,
    &_MetalLayer_getProps,
    &_CreateMetalViewFromHWND,
    &_ReleaseMetalView,
    &thunk_SM50Initialize,
    &thunk_SM50Destroy,
    &thunk_SM50Compile,
    &thunk_SM50GetCompiledBitcode,
    &thunk_SM50DestroyBitcode,
    &thunk_SM50GetErrorMessage,
    &thunk_SM50FreeError,
    &thunk_SM50CompileGeometryPipelineVertex,
    &thunk_SM50CompileGeometryPipelineGeometry,
    NULL,
    &thunk_SM50CompileTessellationPipelineHull,
    &thunk_SM50CompileTessellationPipelineDomain,
    &_MTLCommandEncoder_setLabel,
    &_MTLDevice_setShouldMaximizeConcurrentCompilation,
    &thunk_SM50GetArgumentsInfo,
    &_rmg_MTLCommandBuffer_error,
    &_rmg_MTLCommandBuffer_logs,
    &_rmg_MTLLogContainer_enumerate,
    &_rmg_CGColorSpace_checkColorSpaceSupported,
    &_rmg_MetalLayer_setColorSpace,
    &_WMTGetPrimaryDisplayId,
    &_rmg_WMTGetSecondaryDisplayId,
    &_WMTGetDisplayDescription,
    &_MetalLayer_getEDRValue,
    &_MTLLibrary_newFunctionWithConstants,
    &_rmg_WMTQueryDisplaySetting,
    &_rmg_WMTUpdateDisplaySetting,
    &_WMTQueryDisplaySettingForLayer,
    &_MTLCommandBuffer_encodeWaitForEvent,
    &_rmg_MTLSharedEvent_signalValue,
    &_rmg_MTLSharedEvent_setWin32EventAtValue,
    &_rmg_MTLDevice_newFence,
    &_rmg_MTLDevice_newEvent,
    &_MTLBuffer_updateContents,
    &_SharedEventListener_create,
    &_SharedEventListener_start,
    &_SharedEventListener_destroy,
    &_WMTGetOSVersion,
    &_rmg_MTLDevice_newBinaryArchive,
    &_rmg_MTLBinaryArchive_serialize,
    &_DispatchData_alloc_init,
    &_CacheReader_alloc_init,
    &_CacheReader_get,
    &_CacheWriter_alloc_init,
    &_CacheWriter_set,
    &_WMTSetMetalShaderCachePath,
    &_rmg_MTLDevice_newSharedTexture,
    &_rmg_WMTBootstrapRegister,
    &_rmg_WMTBootstrapLookUp,
    &_rmg_MTLSharedEvent_createMachPort,
    &_rmg_MTLDevice_newSharedEventWithMachPort,
    &_MTLDevice_registryID,
    &_rmg_MTLSharedEvent_waitUntilSignaledValue,
};

#ifndef DXMT_NATIVE
const void *__wine_unix_call_wow64_funcs[] = {
    &_NSObject_retain,
    &_NSObject_release,
    &_NSArray_object,
    &_NSArray_count,
    &_MTLCopyAllDevices,
    &_MTLDevice_recommendedMaxWorkingSetSize,
    &_MTLDevice_currentAllocatedSize,
    &_MTLDevice_name,
    &_NSString_getCString,
    &_MTLDevice_newCommandQueue,
    &_NSAutoreleasePool_alloc_init,
    &_MTLCommandQueue_commandBuffer,
    &_MTLCommandBuffer_commit,
    &_MTLCommandBuffer_waitUntilCompleted,
    &_MTLCommandBuffer_status,
    &_MTLDevice_newSharedEvent,
    &_MTLSharedEvent_signaledValue,
    &_MTLCommandBuffer_encodeSignalEvent,
    &_MTLDevice_newBuffer,
    &_MTLDevice_newSamplerState,
    &_MTLDevice_newDepthStencilState,
    &_MTLDevice_newTexture,
    &_MTLBuffer_newTexture,
    &_MTLTexture_newTextureView,
    &_MTLDevice_minimumLinearTextureAlignmentForPixelFormat,
    &_MTLDevice_newLibrary,
    &_MTLLibrary_newFunction,
    &_NSString_lengthOfBytesUsingEncoding,
    &_rmg_NSObject_description,
    &_MTLDevice_newComputePipelineState,
    &_MTLCommandBuffer_blitCommandEncoder,
    &_rmg_MTLCommandBuffer_computeCommandEncoder,
    &_MTLCommandBuffer_renderCommandEncoder,
    &_MTLCommandEncoder_endEncoding,
    &_MTLDevice_newRenderPipelineState,
    &_rmg_MTLDevice_newMeshRenderPipelineState,
    &_MTLBlitCommandEncoder_encodeCommands,
    &_rmg_MTLComputeCommandEncoder_encodeCommands,
    &_MTLRenderCommandEncoder_encodeCommands,
    &_rmg_MTLTexture_pixelFormat,
    &_MTLTexture_width,
    &_MTLTexture_height,
    &_rmg_MTLTexture_depth,
    &_rmg_MTLTexture_arrayLength,
    &_rmg_MTLTexture_mipmapLevelCount,
    &_MTLTexture_replaceRegion,
    &_rmg_MTLBuffer_didModifyRange,
    &_MTLCommandBuffer_presentDrawable,
    &_rmg_MTLCommandBuffer_presentDrawableAfterMinimumDuration,
    &_MTLDevice_supportsFamily,
    &_MTLDevice_supportsBCTextureCompression,
    &_MTLDevice_supportsTextureSampleCount,
    &_MTLDevice_hasUnifiedMemory,
    &_rmg_MTLCaptureManager_sharedCaptureManager,
    &_rmg_MTLCaptureManager_startCapture,
    &_rmg_MTLCaptureManager_stopCapture,
    &_rmg_MTLDevice_newTemporalScaler,
    &_rmg_MTLDevice_newSpatialScaler,
    &_rmg_MTLCommandBuffer_encodeTemporalScale,
    &_rmg_MTLCommandBuffer_encodeSpatialScale,
    &_NSString_string,
    &_NSString_alloc_init,
    &_DeveloperHUDProperties_instance,
    &_DeveloperHUDProperties_addLabel,
    &_DeveloperHUDProperties_updateLabel,
    &_DeveloperHUDProperties_remove,
    &_MetalDrawable_texture,
    &_MetalLayer_nextDrawable,
    &_rmg_MTLDevice_supportsFXSpatialScaler,
    &_rmg_MTLDevice_supportsFXTemporalScaler,
    &_MetalLayer_setProps,
    &_MetalLayer_getProps,
    &_CreateMetalViewFromHWND,
    &_ReleaseMetalView,
    &thunk32_SM50Initialize,
    &thunk_SM50Destroy,
    &thunk32_SM50Compile,
    &thunk32_SM50GetCompiledBitcode,
    &thunk_SM50DestroyBitcode,
    &thunk32_SM50GetErrorMessage,
    &thunk_SM50FreeError,
    &thunk32_SM50CompileGeometryPipelineVertex,
    &thunk32_SM50CompileGeometryPipelineGeometry,
    NULL,
    &thunk32_SM50CompileTessellationPipelineHull,
    &thunk32_SM50CompileTessellationPipelineDomain,
    &_MTLCommandEncoder_setLabel,
    &_MTLDevice_setShouldMaximizeConcurrentCompilation,
    &thunk32_SM50GetArgumentsInfo,
    &_rmg_MTLCommandBuffer_error,
    &_rmg_MTLCommandBuffer_logs,
    &_rmg_MTLLogContainer_enumerate,
    &_rmg_CGColorSpace_checkColorSpaceSupported,
    &_rmg_MetalLayer_setColorSpace,
    &_WMTGetPrimaryDisplayId,
    &_rmg_WMTGetSecondaryDisplayId,
    &_WMTGetDisplayDescription,
    &_MetalLayer_getEDRValue,
    &_MTLLibrary_newFunctionWithConstants,
    &_rmg_WMTQueryDisplaySetting,
    &_rmg_WMTUpdateDisplaySetting,
    &_WMTQueryDisplaySettingForLayer,
    &_MTLCommandBuffer_encodeWaitForEvent,
    &_rmg_MTLSharedEvent_signalValue,
    &_rmg_MTLSharedEvent_setWin32EventAtValue,
    &_rmg_MTLDevice_newFence,
    &_rmg_MTLDevice_newEvent,
    &_MTLBuffer_updateContents,
    &_SharedEventListener_create,
    &_SharedEventListener_start,
    &_SharedEventListener_destroy,
    &_WMTGetOSVersion,
    &_rmg_MTLDevice_newBinaryArchive,
    &_rmg_MTLBinaryArchive_serialize,
    &_DispatchData_alloc_init,
    &_CacheReader_alloc_init,
    &_CacheReader_get,
    &_CacheWriter_alloc_init,
    &_CacheWriter_set,
    &_WMTSetMetalShaderCachePath,
    &_rmg_MTLDevice_newSharedTexture,
    &_rmg_WMTBootstrapRegister,
    &_rmg_WMTBootstrapLookUp,
    &_rmg_MTLSharedEvent_createMachPort,
    &_rmg_MTLDevice_newSharedEventWithMachPort,
    &_MTLDevice_registryID,
    &_rmg_MTLSharedEvent_waitUntilSignaledValue,
};
#endif
